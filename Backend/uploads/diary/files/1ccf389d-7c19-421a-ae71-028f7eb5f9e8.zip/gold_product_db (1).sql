-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2026 at 01:02 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gold_product_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(200) NOT NULL DEFAULT '',
  `subtitle` varchar(300) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `image` varchar(500) NOT NULL,
  `mobile_image` varchar(500) DEFAULT NULL,
  `link` varchar(1000) NOT NULL DEFAULT '',
  `type` enum('hero','offer') NOT NULL DEFAULT 'hero',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `title`, `subtitle`, `description`, `image`, `mobile_image`, `link`, `type`, `active`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Silver that speaks elegance', 'ELEGANCE ✦ PURITY ✦ TIMELESS BEAUTY', 'Discover the beauty of timeless silver.', '/uploads/banners/1d5308a8-4d4e-4038-b0ae-10f907e7ef44.png', NULL, '', 'hero', 1, 1, '2026-10-17 11:23:47', '2026-10-17 11:23:47'),
(2, 'Jewellery that tells your story', 'TRADITION  ✦  CRAFTSMANSHIP  ✦  FOREVER YOURS', 'Timeless gold. Unforgettable moments.', '/uploads/banners/7ccf1cbd-cd40-482a-8b61-faf9b83ed319.png', NULL, '', 'hero', 1, 1, '2026-10-17 11:24:32', '2026-10-17 11:24:32'),
(3, 'Designed to shine forever', 'BEAUTY  ✦  HERITAGE  ✦  EVERYDAY LUXURY', 'Discover jewellery made for every occasion.', '/uploads/banners/a5897af1-7c16-4a01-a5f3-991be6e8a350.png', NULL, '', 'hero', 1, 1, '2026-10-17 11:25:09', '2026-10-17 11:25:09'),
(4, 'Every jewel has a story', 'CRAFTED WITH LOVE  ✦  MADE TO TREASURE', 'Find the perfect piece for your special moments.', '/uploads/banners/96e84a17-ab8b-49e7-a3bb-71f716e00b1b.png', NULL, '', 'hero', 1, 1, '2026-10-17 11:25:48', '2026-10-17 11:25:48');

-- --------------------------------------------------------

--
-- Table structure for table `billings`
--

CREATE TABLE `billings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `invoice_no` varchar(50) NOT NULL,
  `customers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`customers`)),
  `products` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`products`)),
  `exchanges` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`exchanges`)),
  `payment_type` enum('FULL_PAYMENT','EXCHANGE_GOLD') NOT NULL,
  `sub_total` decimal(12,2) NOT NULL,
  `discount_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `gst_amount` decimal(12,2) NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `paid_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `balance_due` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `billings`
--

INSERT INTO `billings` (`id`, `invoice_no`, `customers`, `products`, `exchanges`, `payment_type`, `sub_total`, `discount_amount`, `gst_amount`, `total_amount`, `paid_amount`, `balance_due`, `created_at`) VALUES
(1, 'BILL-20261019-0B0C174D', '[{\"name\":\"DHIVAKAR P\",\"phone\":\"08940450960\",\"email\":\"dhivakarp305@gmail.com\",\"address\":\"Sollaikkolaimedu ,Nayakkaneri(po),Ambur(Tk)\"}]', '[{\"product_name\":\"Gold Mangalsutra\",\"category\":\"Mangalsutra\",\"purity\":\"22K / 916\",\"price\":85025}]', '[]', 'FULL_PAYMENT', 85025.00, 25.00, 1700.00, 86700.00, 0.00, 86700.00, '2026-10-19 05:44:12'),
(2, 'BILL-20261019-42A1553E', '[{\"name\":\"Sathya\",\"phone\":\"1234567890\",\"email\":\"sathya@gmail.com\",\"address\":\"Tirupattur – Singarapet Road, Tirupattur, Tirupathur, Tirupattur, Tamil Nadu, 635600, India\"}]', '[{\"product_name\":\"Gold Mangalsutra\",\"category\":\"Mangalsutra\",\"purity\":\"22K / 916\",\"price\":85025}]', '[{\"product_name\":\"Silver 999 exchange item\",\"category\":\"Bracelets\",\"purity\":\"999\",\"metal_type\":\"Silver\",\"weight\":500,\"wastage_weight\":100,\"net_weight\":400,\"weight_unit\":\"gram\",\"rate_per_unit\":200,\"rate_unit\":\"gram\",\"credit_amount\":80000}]', 'EXCHANGE_GOLD', 85025.00, 0.00, 150.75, 5175.75, 0.00, 5175.75, '2026-10-19 06:05:03'),
(3, 'BILL-20261019-11C6D144', '[{\"name\":\"Rajesh\",\"phone\":\"1234567890\",\"email\":\"rajesh@gmail.com\",\"address\":\"Tirupattur – Singarapet Road, Tirupattur, Tirupathur, Tirupattur, Tamil Nadu, 635600, India\"}]', '[{\"product_name\":\"Traditional Gold Haram\",\"category\":\"Necklace\",\"purity\":\"22K / 916\",\"price\":220500}]', '[{\"product_name\":\"Silver 999 exchange item\",\"category\":\"Chain\",\"purity\":\"999\",\"metal_type\":\"Silver\",\"weight\":500,\"wastage_weight\":100,\"net_weight\":400,\"weight_unit\":\"gram\",\"rate_per_unit\":250,\"rate_unit\":\"gram\",\"credit_amount\":100000}]', 'EXCHANGE_GOLD', 220500.00, 500.00, 3600.00, 123600.00, 0.00, 123600.00, '2026-10-19 07:35:38'),
(4, 'BILL-20261019-ABDC281B', '[{\"name\":\"Saravana\",\"phone\":\"08940450960\",\"email\":\"dhivakarp@gmail.com\",\"address\":\"Tirupattur – Singarapet Road, Tirupattur, Tirupathur, Tirupattur, Tamil Nadu, 635600, India\"}]', '[{\"product_name\":\"Traditional Gold Haram\",\"category\":\"Necklace\",\"purity\":\"22K / 916\",\"price\":220500}]', '[]', 'FULL_PAYMENT', 220500.00, 5000.00, 4310.00, 219810.00, 0.00, 219810.00, '2026-10-19 07:41:20');

-- --------------------------------------------------------

--
-- Table structure for table `billing_payments`
--

CREATE TABLE `billing_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `billing_id` bigint(20) UNSIGNED NOT NULL,
  `account_id` bigint(20) UNSIGNED NOT NULL,
  `payment_kind` enum('PAYMENT','REFUND') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_method` varchar(40) NOT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `payment_date` datetime NOT NULL,
  `idempotency_key` varchar(150) NOT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `variant_color` varchar(100) NOT NULL DEFAULT '',
  `variant_size` varchar(100) NOT NULL DEFAULT '',
  `image` varchar(1000) DEFAULT NULL,
  `price` decimal(14,2) NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `catId` varchar(32) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `subcategory` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`subcategory`)),
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`images`)),
  `user_id` varchar(255) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `created_by` varchar(255) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `updated_by` varchar(255) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `catId`, `name`, `description`, `subcategory`, `images`, `user_id`, `created_by`, `updated_by`, `status`, `created_at`, `updated_at`) VALUES
(24, 'CAT001', 'Cat', NULL, '[\"fdgdfg\"]', '[]', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 'Active', '2026-11-23 11:51:51', '2026-11-23 11:59:39'),
(25, 'CAT002', 'cat2', NULL, '[]', '[]', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 'Active', '2026-11-23 11:51:59', '2026-11-23 11:59:39'),
(32, 'CAT001', 'Go', NULL, '[\"fgfg\"]', '[]', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 'Active', '2026-11-23 12:02:07', '2026-11-23 12:02:07'),
(33, 'CAT003', 'New', NULL, '[]', '[]', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 'Active', '2026-11-23 12:02:24', '2026-11-23 12:02:24');

-- --------------------------------------------------------

--
-- Table structure for table `dealers`
--

CREATE TABLE `dealers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dealer_code` varchar(32) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL,
  `contact_person` varchar(150) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `phone` varchar(32) NOT NULL,
  `alternate_phone` varchar(32) DEFAULT NULL,
  `gstin` varchar(15) DEFAULT NULL,
  `pan` varchar(10) DEFAULT NULL,
  `billing_address` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`billing_address`)),
  `shipping_address` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`shipping_address`)),
  `opening_balance_side` enum('payable','receivable') NOT NULL DEFAULT 'payable',
  `credit_limit` decimal(16,2) NOT NULL DEFAULT 0.00,
  `payment_terms_days` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `bank_details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`bank_details`)),
  `status` enum('Active','Inactive','On Hold') NOT NULL DEFAULT 'Active',
  `notes` text DEFAULT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_audit_log`
--

CREATE TABLE `dealer_audit_log` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dealer_id` bigint(20) UNSIGNED NOT NULL,
  `actor_id` int(10) UNSIGNED NOT NULL,
  `action` varchar(40) NOT NULL,
  `before_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`before_data`)),
  `after_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`after_data`)),
  `reason` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_categories`
--

CREATE TABLE `dealer_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dealer_categories`
--

INSERT INTO `dealer_categories` (`id`, `name`, `active`, `created_at`) VALUES
(1, 'Gold Supplier', 1, '2026-11-23 05:06:06'),
(2, 'Bullion Dealer', 1, '2026-11-23 05:06:06'),
(3, 'Jewellery Wholesaler', 1, '2026-11-23 05:06:06'),
(4, 'Goldsmith', 1, '2026-11-23 05:06:06'),
(5, 'Job Worker', 1, '2026-11-23 05:06:06'),
(6, 'Old-Gold Dealer', 1, '2026-11-23 05:06:06'),
(7, 'Refiner', 1, '2026-11-23 05:06:06'),
(8, 'Manufacturer', 1, '2026-11-23 05:06:06');

-- --------------------------------------------------------

--
-- Table structure for table `dealer_documents`
--

CREATE TABLE `dealer_documents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dealer_id` bigint(20) UNSIGNED NOT NULL,
  `document_type` varchar(60) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `stored_name` char(36) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `uploaded_by` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_financial_ledger`
--

CREATE TABLE `dealer_financial_ledger` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dealer_id` bigint(20) UNSIGNED NOT NULL,
  `entry_number` varchar(40) NOT NULL,
  `entry_type` varchar(40) NOT NULL,
  `source_type` varchar(40) NOT NULL,
  `source_id` bigint(20) UNSIGNED DEFAULT NULL,
  `payable_delta` decimal(16,2) NOT NULL DEFAULT 0.00,
  `receivable_delta` decimal(16,2) NOT NULL DEFAULT 0.00,
  `description` varchar(500) NOT NULL,
  `posted_by` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_jobs`
--

CREATE TABLE `dealer_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `job_number` varchar(40) NOT NULL,
  `dealer_id` bigint(20) UNSIGNED NOT NULL,
  `description` varchar(500) NOT NULL,
  `due_date` date DEFAULT NULL,
  `labour_charge` decimal(16,2) NOT NULL DEFAULT 0.00,
  `approved_wastage` decimal(14,3) NOT NULL DEFAULT 0.000,
  `status` enum('Open','Issued','Partially Received','Received','Reconciled','Cancelled') NOT NULL DEFAULT 'Open',
  `created_by` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_job_issues`
--

CREATE TABLE `dealer_job_issues` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `job_id` bigint(20) UNSIGNED NOT NULL,
  `metal_type` enum('Gold','Silver') NOT NULL,
  `purity` varchar(12) NOT NULL,
  `weight` decimal(14,3) NOT NULL,
  `fine_gold_weight` decimal(14,3) NOT NULL,
  `issued_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `posted_by` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_job_receipts`
--

CREATE TABLE `dealer_job_receipts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `job_id` bigint(20) UNSIGNED NOT NULL,
  `receipt_number` varchar(40) NOT NULL,
  `receipt_type` enum('finished','scrap','dust') NOT NULL,
  `metal_type` enum('Gold','Silver') NOT NULL,
  `purity` varchar(12) NOT NULL,
  `weight` decimal(14,3) NOT NULL,
  `fine_gold_weight` decimal(14,3) NOT NULL,
  `labour_charge` decimal(16,2) NOT NULL DEFAULT 0.00,
  `received_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `posted_by` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_job_reconciliations`
--

CREATE TABLE `dealer_job_reconciliations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `job_id` bigint(20) UNSIGNED NOT NULL,
  `issued_fine_weight` decimal(14,3) NOT NULL,
  `returned_fine_weight` decimal(14,3) NOT NULL,
  `approved_loss` decimal(14,3) NOT NULL DEFAULT 0.000,
  `variance` decimal(14,3) NOT NULL,
  `status` enum('Pending','Approved') NOT NULL,
  `approval_reason` varchar(500) DEFAULT NULL,
  `approved_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_metal_ledger`
--

CREATE TABLE `dealer_metal_ledger` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dealer_id` bigint(20) UNSIGNED NOT NULL,
  `entry_number` varchar(40) NOT NULL,
  `source_type` varchar(40) NOT NULL,
  `source_id` bigint(20) UNSIGNED DEFAULT NULL,
  `metal_type` enum('Gold','Silver') NOT NULL,
  `purity` varchar(12) NOT NULL,
  `movement` enum('opening','issued','received','adjustment') NOT NULL,
  `weight_delta` decimal(14,3) NOT NULL,
  `fine_gold_delta` decimal(14,3) NOT NULL,
  `reconciliation_status` enum('Not Required','Pending','Approved') NOT NULL DEFAULT 'Not Required',
  `description` varchar(500) NOT NULL,
  `posted_by` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_old_gold_receipts`
--

CREATE TABLE `dealer_old_gold_receipts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `receipt_number` varchar(40) NOT NULL,
  `dealer_id` bigint(20) UNSIGNED NOT NULL,
  `linked_purchase_id` bigint(20) UNSIGNED DEFAULT NULL,
  `gross_weight` decimal(14,3) NOT NULL,
  `stone_weight` decimal(14,3) NOT NULL DEFAULT 0.000,
  `net_weight` decimal(14,3) NOT NULL,
  `tested_purity` varchar(12) NOT NULL,
  `fine_gold_weight` decimal(14,3) NOT NULL,
  `agreed_rate` decimal(16,2) NOT NULL,
  `rate_batch_id` char(36) DEFAULT NULL,
  `gold_rate_date` date DEFAULT NULL,
  `settlement_amount` decimal(16,2) NOT NULL,
  `rate_source` enum('Global','Negotiated') NOT NULL,
  `received_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `received_by` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_payments`
--

CREATE TABLE `dealer_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payment_number` varchar(40) NOT NULL,
  `dealer_id` bigint(20) UNSIGNED NOT NULL,
  `idempotency_key` varchar(100) NOT NULL,
  `payment_date` date NOT NULL,
  `amount` decimal(16,2) NOT NULL,
  `method` enum('Bank','UPI','Cheque','Cash') NOT NULL,
  `reference` varchar(120) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `posted_by` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_payment_allocations`
--

CREATE TABLE `dealer_payment_allocations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payment_id` bigint(20) UNSIGNED NOT NULL,
  `purchase_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(16,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_payment_reversals`
--

CREATE TABLE `dealer_payment_reversals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payment_id` bigint(20) UNSIGNED NOT NULL,
  `reason` varchar(500) NOT NULL,
  `reversed_by` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_purchases`
--

CREATE TABLE `dealer_purchases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `document_number` varchar(40) NOT NULL,
  `dealer_id` bigint(20) UNSIGNED NOT NULL,
  `document_type` enum('invoice','purchase_return','debit_note','credit_note','old_gold') NOT NULL,
  `supplier_invoice_number` varchar(80) DEFAULT NULL,
  `linked_document_id` bigint(20) UNSIGNED DEFAULT NULL,
  `document_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `rate_batch_id` char(36) DEFAULT NULL,
  `gold_rate_date` date DEFAULT NULL,
  `subtotal` decimal(16,2) NOT NULL,
  `tax_total` decimal(16,2) NOT NULL,
  `total` decimal(16,2) NOT NULL,
  `paid_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `notes` varchar(1000) DEFAULT NULL,
  `posted_by` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_purchase_lines`
--

CREATE TABLE `dealer_purchase_lines` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `purchase_id` bigint(20) UNSIGNED NOT NULL,
  `description` varchar(255) NOT NULL,
  `metal_type` enum('Gold','Silver','Other') NOT NULL DEFAULT 'Gold',
  `purity` varchar(12) DEFAULT NULL,
  `quantity` decimal(14,3) NOT NULL DEFAULT 1.000,
  `net_weight` decimal(14,3) NOT NULL DEFAULT 0.000,
  `rate_per_gram` decimal(16,2) NOT NULL DEFAULT 0.00,
  `rate_source` enum('Global','Negotiated','Non-metal') NOT NULL,
  `metal_value` decimal(16,2) NOT NULL,
  `making_charge` decimal(16,2) NOT NULL DEFAULT 0.00,
  `wastage_charge` decimal(16,2) NOT NULL DEFAULT 0.00,
  `stone_charge` decimal(16,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `tax_rate` decimal(7,3) NOT NULL DEFAULT 0.000,
  `tax_type` enum('IGST','CGST_SGST','NONE') NOT NULL DEFAULT 'NONE',
  `tax_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `line_total` decimal(16,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_refining_receipts`
--

CREATE TABLE `dealer_refining_receipts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `refining_number` varchar(40) NOT NULL,
  `dealer_id` bigint(20) UNSIGNED NOT NULL,
  `old_gold_receipt_id` bigint(20) UNSIGNED NOT NULL,
  `recovered_metal_type` enum('Gold','Silver') NOT NULL DEFAULT 'Gold',
  `recovered_purity` varchar(12) NOT NULL,
  `recovered_weight` decimal(14,3) NOT NULL,
  `fine_gold_weight` decimal(14,3) NOT NULL,
  `refining_charges` decimal(16,2) NOT NULL DEFAULT 0.00,
  `recovery_variance` decimal(14,3) NOT NULL,
  `received_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `received_by` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealer_sequences`
--

CREATE TABLE `dealer_sequences` (
  `sequence_name` varchar(32) NOT NULL,
  `next_value` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dealer_sequences`
--

INSERT INTO `dealer_sequences` (`sequence_name`, `next_value`) VALUES
('dealer', 1),
('document', 1),
('job', 1),
('job_receipt', 1),
('metal', 1),
('old_gold', 1),
('payment', 1),
('refining', 1);

-- --------------------------------------------------------

--
-- Table structure for table `enquiries`
--

CREATE TABLE `enquiries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `alternate_phone` varchar(32) DEFAULT NULL,
  `email` varchar(254) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `pincode` varchar(20) DEFAULT NULL,
  `enquiry_type` varchar(50) NOT NULL,
  `product_category` varchar(100) DEFAULT NULL,
  `product_id` int(10) UNSIGNED DEFAULT NULL,
  `product_name` varchar(200) DEFAULT NULL,
  `purity` varchar(20) DEFAULT NULL,
  `quantity` decimal(12,3) DEFAULT NULL,
  `weight` decimal(12,3) DEFAULT NULL,
  `approx_budget` decimal(14,2) DEFAULT NULL,
  `preferred_design` varchar(100) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `status` enum('New Enquiry','In Progress','Quotation Sent','Converted','Closed','Not Interested') NOT NULL DEFAULT 'New Enquiry',
  `follow_up_date` date DEFAULT NULL,
  `follow_up_time` time DEFAULT NULL,
  `assigned_to` varchar(150) DEFAULT NULL,
  `source` varchar(80) DEFAULT NULL,
  `priority` enum('Low','Medium','High') NOT NULL DEFAULT 'Medium',
  `whatsapp_confirmation` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fund_accounts`
--

CREATE TABLE `fund_accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `account_type` enum('Cash','Bank Account','UPI','Other') NOT NULL DEFAULT 'Other',
  `opening_balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `account_number` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fund_accounts`
--

INSERT INTO `fund_accounts` (`id`, `name`, `account_type`, `opening_balance`, `account_number`, `is_active`, `created_at`) VALUES
(1, 'Shop Cash', 'Cash', 0.00, NULL, 1, '2026-11-23 05:06:04'),
(2, 'Main Bank Account', 'Bank Account', 0.00, NULL, 1, '2026-11-23 05:06:04'),
(3, 'Secondary Bank Account', 'Bank Account', 0.00, NULL, 1, '2026-11-23 05:06:04'),
(4, 'UPI Account', 'UPI', 0.00, NULL, 1, '2026-11-23 05:06:04'),
(5, 'Other Business Account', 'Other', 0.00, NULL, 1, '2026-11-23 05:06:04');

-- --------------------------------------------------------

--
-- Table structure for table `fund_transactions`
--

CREATE TABLE `fund_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `account_id` bigint(20) UNSIGNED NOT NULL,
  `transaction_type` enum('FUND_ADDED','DEBIT','CREDIT','TRANSFER_IN','TRANSFER_OUT') NOT NULL,
  `category` varchar(80) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `party_name` varchar(150) DEFAULT NULL,
  `related_reference` varchar(100) DEFAULT NULL,
  `payment_method` varchar(40) NOT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `receipt_url` varchar(255) DEFAULT NULL,
  `transfer_id` char(36) DEFAULT NULL,
  `idempotency_key` varchar(150) DEFAULT NULL,
  `status` enum('POSTED','VOID') NOT NULL DEFAULT 'POSTED',
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gold_rates`
--

CREATE TABLE `gold_rates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` varchar(255) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `batch_id` char(36) NOT NULL,
  `rate_date` date NOT NULL,
  `metal_type` enum('Gold','Silver','Platinum','Diamond') NOT NULL,
  `purity` varchar(20) NOT NULL,
  `rate_per_gram` decimal(14,2) NOT NULL,
  `rate_unit` enum('gram','carat') NOT NULL DEFAULT 'gram',
  `making_charge_type` enum('Percentage','Fixed Amount') NOT NULL DEFAULT 'Percentage',
  `making_charge_value` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `wastage_percentage` decimal(9,4) NOT NULL DEFAULT 0.0000,
  `status` enum('Draft','Active','Archived') NOT NULL DEFAULT 'Draft',
  `effective_from` datetime NOT NULL,
  `created_by` varchar(255) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `updated_by` varchar(255) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gold_rates`
--

INSERT INTO `gold_rates` (`id`, `user_id`, `batch_id`, `rate_date`, `metal_type`, `purity`, `rate_per_gram`, `rate_unit`, `making_charge_type`, `making_charge_value`, `wastage_percentage`, `status`, `effective_from`, `created_by`, `updated_by`, `version`, `created_at`, `updated_at`) VALUES
(29, '5b651783-607e-4733-97d7-bf76871c0286', 'd07100a9-ba1d-42a0-8381-d04280bc3a53', '2026-11-23', 'Gold', '999', 1.00, 'gram', 'Percentage', 2.0000, 2.0000, 'Active', '2026-11-23 11:09:00', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 1, '2026-11-23 11:10:21', '2026-11-23 11:18:23'),
(30, '5b651783-607e-4733-97d7-bf76871c0286', 'd07100a9-ba1d-42a0-8381-d04280bc3a53', '2026-11-23', 'Gold', '916', 2.00, 'gram', 'Percentage', 2.0000, 2.0000, 'Active', '2026-11-23 11:09:00', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 1, '2026-11-23 11:10:21', '2026-11-23 11:18:23'),
(31, '5b651783-607e-4733-97d7-bf76871c0286', 'd07100a9-ba1d-42a0-8381-d04280bc3a53', '2026-11-23', 'Gold', '833', 2.00, 'gram', 'Percentage', 2.0000, 2.0000, 'Active', '2026-11-23 11:09:00', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 1, '2026-11-23 11:10:21', '2026-11-23 11:18:23'),
(32, '5b651783-607e-4733-97d7-bf76871c0286', 'd07100a9-ba1d-42a0-8381-d04280bc3a53', '2026-11-23', 'Gold', '750', 3.00, 'gram', 'Percentage', 2.0000, 2.0000, 'Active', '2026-11-23 11:09:00', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 1, '2026-11-23 11:10:21', '2026-11-23 11:18:23'),
(33, '5b651783-607e-4733-97d7-bf76871c0286', 'd07100a9-ba1d-42a0-8381-d04280bc3a53', '2026-11-23', 'Gold', '585', 4.00, 'gram', 'Percentage', 2.0000, 2.0000, 'Active', '2026-11-23 11:09:00', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 1, '2026-11-23 11:10:21', '2026-11-23 11:18:23'),
(34, '5b651783-607e-4733-97d7-bf76871c0286', 'd07100a9-ba1d-42a0-8381-d04280bc3a53', '2026-11-23', 'Silver', '999', 5.00, 'gram', 'Percentage', 2.0000, 2.0000, 'Active', '2026-11-23 11:09:00', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 1, '2026-11-23 11:10:21', '2026-11-23 11:18:23'),
(35, '5b651783-607e-4733-97d7-bf76871c0286', 'd07100a9-ba1d-42a0-8381-d04280bc3a53', '2026-11-23', 'Platinum', '950', 6.00, 'gram', 'Percentage', 2.0000, 2.0000, 'Active', '2026-11-23 11:09:00', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 1, '2026-11-23 11:10:21', '2026-11-23 11:18:23'),
(36, '5b651783-607e-4733-97d7-bf76871c0286', 'd07100a9-ba1d-42a0-8381-d04280bc3a53', '2026-11-23', 'Platinum', '900', 7.00, 'gram', 'Percentage', 2.0000, 2.0000, 'Active', '2026-11-23 11:09:00', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 1, '2026-11-23 11:10:21', '2026-11-23 11:18:23'),
(37, '5b651783-607e-4733-97d7-bf76871c0286', 'd07100a9-ba1d-42a0-8381-d04280bc3a53', '2026-11-23', 'Diamond', 'D-F / VVS', 8.00, 'carat', 'Percentage', 2.0000, 2.0000, 'Active', '2026-11-23 11:09:00', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 1, '2026-11-23 11:10:21', '2026-11-23 11:18:23'),
(38, '5b651783-607e-4733-97d7-bf76871c0286', 'd07100a9-ba1d-42a0-8381-d04280bc3a53', '2026-11-23', 'Diamond', 'G-H / VS', 9.00, 'carat', 'Percentage', 2.0000, 2.0000, 'Active', '2026-11-23 11:09:00', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 1, '2026-11-23 11:10:21', '2026-11-23 11:18:23'),
(39, '5b651783-607e-4733-97d7-bf76871c0286', 'd07100a9-ba1d-42a0-8381-d04280bc3a53', '2026-11-23', 'Diamond', 'I-J / SI', 10.00, 'carat', 'Percentage', 2.0000, 2.0000, 'Active', '2026-11-23 11:09:00', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', 1, '2026-11-23 11:10:21', '2026-11-23 11:18:23'),
(40, 'c640f180-60e2-4014-afbc-349bf3055289', '4c33cccc-c040-49a5-a742-b918fedf79fc', '2026-11-23', 'Gold', '999', 10.00, 'gram', 'Percentage', 5.0000, 5.0000, 'Active', '2026-11-23 11:19:00', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 1, '2026-11-23 11:19:59', '2026-11-23 11:19:59'),
(41, 'c640f180-60e2-4014-afbc-349bf3055289', '4c33cccc-c040-49a5-a742-b918fedf79fc', '2026-11-23', 'Gold', '916', 9.00, 'gram', 'Percentage', 5.0000, 5.0000, 'Active', '2026-11-23 11:19:00', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 1, '2026-11-23 11:19:59', '2026-11-23 11:19:59'),
(42, 'c640f180-60e2-4014-afbc-349bf3055289', '4c33cccc-c040-49a5-a742-b918fedf79fc', '2026-11-23', 'Gold', '833', 8.00, 'gram', 'Percentage', 5.0000, 5.0000, 'Active', '2026-11-23 11:19:00', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 1, '2026-11-23 11:19:59', '2026-11-23 11:19:59'),
(43, 'c640f180-60e2-4014-afbc-349bf3055289', '4c33cccc-c040-49a5-a742-b918fedf79fc', '2026-11-23', 'Gold', '750', 7.00, 'gram', 'Percentage', 5.0000, 5.0000, 'Active', '2026-11-23 11:19:00', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 1, '2026-11-23 11:19:59', '2026-11-23 11:19:59'),
(44, 'c640f180-60e2-4014-afbc-349bf3055289', '4c33cccc-c040-49a5-a742-b918fedf79fc', '2026-11-23', 'Gold', '585', 6.00, 'gram', 'Percentage', 5.0000, 5.0000, 'Active', '2026-11-23 11:19:00', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 1, '2026-11-23 11:19:59', '2026-11-23 11:19:59'),
(45, 'c640f180-60e2-4014-afbc-349bf3055289', '4c33cccc-c040-49a5-a742-b918fedf79fc', '2026-11-23', 'Silver', '999', 5.00, 'gram', 'Percentage', 5.0000, 5.0000, 'Active', '2026-11-23 11:19:00', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 1, '2026-11-23 11:19:59', '2026-11-23 11:19:59'),
(46, 'c640f180-60e2-4014-afbc-349bf3055289', '4c33cccc-c040-49a5-a742-b918fedf79fc', '2026-11-23', 'Platinum', '950', 4.00, 'gram', 'Percentage', 5.0000, 5.0000, 'Active', '2026-11-23 11:19:00', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 1, '2026-11-23 11:19:59', '2026-11-23 11:19:59'),
(47, 'c640f180-60e2-4014-afbc-349bf3055289', '4c33cccc-c040-49a5-a742-b918fedf79fc', '2026-11-23', 'Platinum', '900', 3.00, 'gram', 'Percentage', 5.0000, 5.0000, 'Active', '2026-11-23 11:19:00', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 1, '2026-11-23 11:19:59', '2026-11-23 11:19:59'),
(48, 'c640f180-60e2-4014-afbc-349bf3055289', '4c33cccc-c040-49a5-a742-b918fedf79fc', '2026-11-23', 'Diamond', 'D-F / VVS', 2.00, 'carat', 'Percentage', 5.0000, 5.0000, 'Active', '2026-11-23 11:19:00', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 1, '2026-11-23 11:19:59', '2026-11-23 11:19:59'),
(49, 'c640f180-60e2-4014-afbc-349bf3055289', '4c33cccc-c040-49a5-a742-b918fedf79fc', '2026-11-23', 'Diamond', 'G-H / VS', 1.00, 'carat', 'Percentage', 5.0000, 5.0000, 'Active', '2026-11-23 11:19:00', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 1, '2026-11-23 11:19:59', '2026-11-23 11:19:59'),
(50, 'c640f180-60e2-4014-afbc-349bf3055289', '4c33cccc-c040-49a5-a742-b918fedf79fc', '2026-11-23', 'Diamond', 'I-J / SI', 0.50, 'carat', 'Percentage', 5.0000, 5.0000, 'Active', '2026-11-23 11:19:00', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', 1, '2026-11-23 11:19:59', '2026-11-23 11:19:59');

-- --------------------------------------------------------

--
-- Table structure for table `gold_rate_history`
--

CREATE TABLE `gold_rate_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `batch_id` char(36) NOT NULL,
  `rate_id` bigint(20) UNSIGNED DEFAULT NULL,
  `metal_type` varchar(20) NOT NULL,
  `purity` varchar(20) NOT NULL,
  `rate_unit` enum('gram','carat') NOT NULL DEFAULT 'gram',
  `previous_rate` decimal(14,2) DEFAULT NULL,
  `new_rate` decimal(14,2) DEFAULT NULL,
  `action` varchar(20) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `changed_by` varchar(255) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gold_rate_history`
--

INSERT INTO `gold_rate_history` (`id`, `batch_id`, `rate_id`, `metal_type`, `purity`, `rate_unit`, `previous_rate`, `new_rate`, `action`, `reason`, `changed_by`, `changed_at`) VALUES
(74, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 29, 'Gold', '999', 'gram', NULL, 1.00, 'Created', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(75, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 30, 'Gold', '916', 'gram', NULL, 2.00, 'Created', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(76, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 31, 'Gold', '833', 'gram', NULL, 2.00, 'Created', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(77, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 32, 'Gold', '750', 'gram', NULL, 3.00, 'Created', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(78, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 33, 'Gold', '585', 'gram', NULL, 4.00, 'Created', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(79, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 34, 'Silver', '999', 'gram', NULL, 5.00, 'Created', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(80, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 35, 'Platinum', '950', 'gram', NULL, 6.00, 'Created', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(81, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 36, 'Platinum', '900', 'gram', NULL, 7.00, 'Created', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(82, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 37, 'Diamond', 'D-F / VVS', 'carat', NULL, 8.00, 'Created', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(83, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 38, 'Diamond', 'G-H / VS', 'carat', NULL, 9.00, 'Created', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(84, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 39, 'Diamond', 'I-J / SI', 'carat', NULL, 10.00, 'Created', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(85, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 29, 'Gold', '999', 'gram', NULL, 1.00, 'Activated', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(86, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 30, 'Gold', '916', 'gram', NULL, 2.00, 'Activated', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(87, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 31, 'Gold', '833', 'gram', NULL, 2.00, 'Activated', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(88, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 32, 'Gold', '750', 'gram', NULL, 3.00, 'Activated', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(89, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 33, 'Gold', '585', 'gram', NULL, 4.00, 'Activated', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(90, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 34, 'Silver', '999', 'gram', NULL, 5.00, 'Activated', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(91, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 35, 'Platinum', '950', 'gram', NULL, 6.00, 'Activated', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(92, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 36, 'Platinum', '900', 'gram', NULL, 7.00, 'Activated', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(93, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 37, 'Diamond', 'D-F / VVS', 'carat', NULL, 8.00, 'Activated', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(94, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 38, 'Diamond', 'G-H / VS', 'carat', NULL, 9.00, 'Activated', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(95, 'd07100a9-ba1d-42a0-8381-d04280bc3a53', 39, 'Diamond', 'I-J / SI', 'carat', NULL, 10.00, 'Activated', 'Daily market price update', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:10:21'),
(96, '4c33cccc-c040-49a5-a742-b918fedf79fc', 40, 'Gold', '999', 'gram', NULL, 10.00, 'Created', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(97, '4c33cccc-c040-49a5-a742-b918fedf79fc', 41, 'Gold', '916', 'gram', NULL, 9.00, 'Created', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(98, '4c33cccc-c040-49a5-a742-b918fedf79fc', 42, 'Gold', '833', 'gram', NULL, 8.00, 'Created', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(99, '4c33cccc-c040-49a5-a742-b918fedf79fc', 43, 'Gold', '750', 'gram', NULL, 7.00, 'Created', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(100, '4c33cccc-c040-49a5-a742-b918fedf79fc', 44, 'Gold', '585', 'gram', NULL, 6.00, 'Created', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(101, '4c33cccc-c040-49a5-a742-b918fedf79fc', 45, 'Silver', '999', 'gram', NULL, 5.00, 'Created', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(102, '4c33cccc-c040-49a5-a742-b918fedf79fc', 46, 'Platinum', '950', 'gram', NULL, 4.00, 'Created', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(103, '4c33cccc-c040-49a5-a742-b918fedf79fc', 47, 'Platinum', '900', 'gram', NULL, 3.00, 'Created', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(104, '4c33cccc-c040-49a5-a742-b918fedf79fc', 48, 'Diamond', 'D-F / VVS', 'carat', NULL, 2.00, 'Created', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(105, '4c33cccc-c040-49a5-a742-b918fedf79fc', 49, 'Diamond', 'G-H / VS', 'carat', NULL, 1.00, 'Created', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(106, '4c33cccc-c040-49a5-a742-b918fedf79fc', 50, 'Diamond', 'I-J / SI', 'carat', NULL, 0.50, 'Created', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(107, '4c33cccc-c040-49a5-a742-b918fedf79fc', 40, 'Gold', '999', 'gram', NULL, 10.00, 'Activated', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(108, '4c33cccc-c040-49a5-a742-b918fedf79fc', 41, 'Gold', '916', 'gram', NULL, 9.00, 'Activated', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(109, '4c33cccc-c040-49a5-a742-b918fedf79fc', 42, 'Gold', '833', 'gram', NULL, 8.00, 'Activated', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(110, '4c33cccc-c040-49a5-a742-b918fedf79fc', 43, 'Gold', '750', 'gram', NULL, 7.00, 'Activated', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(111, '4c33cccc-c040-49a5-a742-b918fedf79fc', 44, 'Gold', '585', 'gram', NULL, 6.00, 'Activated', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(112, '4c33cccc-c040-49a5-a742-b918fedf79fc', 45, 'Silver', '999', 'gram', NULL, 5.00, 'Activated', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(113, '4c33cccc-c040-49a5-a742-b918fedf79fc', 46, 'Platinum', '950', 'gram', NULL, 4.00, 'Activated', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(114, '4c33cccc-c040-49a5-a742-b918fedf79fc', 47, 'Platinum', '900', 'gram', NULL, 3.00, 'Activated', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(115, '4c33cccc-c040-49a5-a742-b918fedf79fc', 48, 'Diamond', 'D-F / VVS', 'carat', NULL, 2.00, 'Activated', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(116, '4c33cccc-c040-49a5-a742-b918fedf79fc', 49, 'Diamond', 'G-H / VS', 'carat', NULL, 1.00, 'Activated', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59'),
(117, '4c33cccc-c040-49a5-a742-b918fedf79fc', 50, 'Diamond', 'I-J / SI', 'carat', NULL, 0.50, 'Activated', 'Daily market price update', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:19:59');

-- --------------------------------------------------------

--
-- Table structure for table `gold_shops`
--

CREATE TABLE `gold_shops` (
  `id` int(10) UNSIGNED NOT NULL,
  `shop_uuid` char(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `owner_user_id` varchar(255) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `shop_code` varchar(50) NOT NULL,
  `shop_name` varchar(150) NOT NULL,
  `owner_name` varchar(150) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gst_number` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `pincode` varchar(20) DEFAULT NULL,
  `status` enum('active','inactive','pending','suspended') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `max_branches` int(10) UNSIGNED NOT NULL,
  `max_staff` int(10) UNSIGNED NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` varchar(255) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `updated_by` varchar(255) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `approval_status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gold_shops`
--

INSERT INTO `gold_shops` (`id`, `shop_uuid`, `owner_user_id`, `shop_code`, `shop_name`, `owner_name`, `mobile`, `email`, `gst_number`, `address`, `city`, `state`, `pincode`, `status`, `notes`, `max_branches`, `max_staff`, `deleted_at`, `created_at`, `updated_at`, `created_by`, `updated_by`, `approved_at`, `approval_status`) VALUES
(3, 'ad05003e-3898-4956-a4cf-d848a0bab339', '9b9dde39-96f9-431f-bd4b-9cc7240bba80', 'GOLD-0003', 'Vel Shop', 'Dhiva', '8940450977', 'dhiva@gmail.com', '919479124991243', 'Tirupattur – Singarapet Road, Tirupattur, Tirupathur, Tirupattur, Tamil Nadu, 635600, India', 'Tirupathur', 'Tamil Nadu', '635801', 'active', NULL, 1, 1, NULL, '2026-11-23 08:33:14', '2026-11-23 10:20:45', '3390ad6c-e700-11f1-8318-51021565bd83', '3390ad6c-e700-11f1-8318-51021565bd83', '2026-11-23 08:37:27', 'approved'),
(4, '771cd7b3-a386-4a30-964f-6a9cc108275a', '5b651783-607e-4733-97d7-bf76871c0286', 'GOLD-0004', 'Sri Gold Shop', 'Thenuga', '6383493433', 'thenuga@gmail.com', '919479124991788', 'Tirupattur – Singarapet Road, Tirupattur, Tirupathur, Tirupattur, Tamil Nadu, 635600, India', 'Tirupathur', 'Tamil Nadu', '635801', 'pending', NULL, 1, 1, NULL, '2026-11-23 09:41:53', '2026-11-23 10:20:45', '3390ad6c-e700-11f1-8318-51021565bd83', '3390ad6c-e700-11f1-8318-51021565bd83', '2026-11-23 09:42:34', 'approved'),
(5, 'a807ed70-d85b-42f7-96e5-75d85d839fdc', 'c640f180-60e2-4014-afbc-349bf3055289', 'GOLD-0005', 'Saravana Shop', 'Nishanth', '6789067890', 'nishanth@gmail.com', '919479124991289', 'Tirupattur – Singarapet Road, Tirupattur, Tirupathur, Tirupattur, Tamil Nadu, 635600, India', 'Tirupathur', 'Tamil Nadu', '635801', 'pending', NULL, 1, 1, NULL, '2026-11-23 10:45:34', '2026-11-23 10:46:22', '3390ad6c-e700-11f1-8318-51021565bd83', '3390ad6c-e700-11f1-8318-51021565bd83', '2026-11-23 10:46:22', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `gold_shop_activity_logs`
--

CREATE TABLE `gold_shop_activity_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `gold_shop_id` int(10) UNSIGNED DEFAULT NULL,
  `actor_id` int(10) UNSIGNED DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gold_shop_activity_logs`
--

INSERT INTO `gold_shop_activity_logs` (`id`, `gold_shop_id`, `actor_id`, `action`, `details`, `created_at`) VALUES
(25, NULL, 6, 'subscription.created', '{\"plan_id\":14,\"duration\":\"monthly\",\"amount\":299,\"end_date\":\"2026-12-23\"}', '2026-11-23 08:13:35'),
(26, NULL, 6, 'subscription.payment_confirmed', '{\"subscription_id\":10,\"payment_id\":10,\"amount\":\"299.00\",\"transaction_id\":\"675675\",\"payment_method\":\"UPI\"}', '2026-11-23 08:13:48'),
(27, NULL, 6, 'shop.deleted', '{}', '2026-11-23 08:14:23'),
(28, NULL, 6, 'subscription.created', '{\"plan_id\":39,\"duration\":\"monthly\",\"amount\":499,\"end_date\":\"2026-12-23\"}', '2026-11-23 08:23:23'),
(29, NULL, 6, 'shop.created', '{\"shop_code\":\"GOLD-0002\",\"documents_uploaded\":4,\"document_consent\":true}', '2026-11-23 08:23:23'),
(30, 3, 6, 'subscription.created', '{\"plan_id\":41,\"duration\":\"monthly\",\"amount\":4999,\"end_date\":\"2026-12-23\"}', '2026-11-23 08:33:14'),
(31, 3, 6, 'shop.created', '{\"shop_code\":\"GOLD-0003\",\"documents_uploaded\":4,\"document_consent\":true}', '2026-11-23 08:33:14'),
(32, 3, 6, 'subscription.payment_confirmed', '{\"subscription_id\":12,\"payment_id\":12,\"amount\":\"4999.00\",\"transaction_id\":\"6865756756\",\"payment_method\":\"UPI\"}', '2026-11-23 08:33:33'),
(33, 3, 6, 'subscription.created', '{\"plan_id\":39,\"duration\":\"monthly\",\"amount\":499,\"end_date\":\"2026-12-23\"}', '2026-11-23 08:35:17'),
(34, 3, 6, 'subscription.payment_confirmed', '{\"subscription_id\":13,\"payment_id\":13,\"amount\":\"499.00\",\"transaction_id\":\"754544454747\",\"payment_method\":\"UPI\"}', '2026-11-23 08:35:31'),
(35, 3, 6, 'shop.approved', '{\"owner_user_id\":13,\"login_created\":false}', '2026-11-23 08:37:27'),
(36, 4, 6, 'subscription.created', '{\"plan_id\":47,\"duration\":\"monthly\",\"amount\":1599,\"end_date\":\"2026-12-23\"}', '2026-11-23 09:41:53'),
(37, 4, 6, 'shop.created', '{\"shop_code\":\"GOLD-0004\",\"documents_uploaded\":4,\"document_consent\":true}', '2026-11-23 09:41:53'),
(38, 4, 6, 'subscription.payment_confirmed', '{\"subscription_id\":14,\"payment_id\":14,\"amount\":\"1599.00\",\"transaction_id\":\"856875474745754\",\"payment_method\":\"UPI\"}', '2026-11-23 09:42:26'),
(39, 4, 6, 'shop.approved', '{\"owner_user_id\":14,\"login_created\":true}', '2026-11-23 09:42:34'),
(40, 3, 6, 'payment.refunded', '{\"payment_id\":12,\"refund_amount\":4999,\"total_refunded\":4999,\"reason\":\"dfdfg\",\"is_full_refund\":true}', '2026-11-23 10:26:44'),
(41, 5, 6, 'subscription.created', '{\"plan_id\":40,\"duration\":\"monthly\",\"amount\":2499,\"end_date\":\"2026-12-23\"}', '2026-11-23 10:45:34'),
(42, 5, 6, 'shop.created', '{\"shop_code\":\"GOLD-0005\",\"documents_uploaded\":4,\"document_consent\":true}', '2026-11-23 10:45:34'),
(43, 5, 6, 'subscription.payment_confirmed', '{\"subscription_id\":15,\"payment_id\":15,\"amount\":\"2499.00\",\"transaction_id\":\"7967969679679679\",\"payment_method\":\"UPI\"}', '2026-11-23 10:46:07'),
(44, 5, 6, 'shop.approved', '{\"owner_user_id\":\"c640f180-60e2-4014-afbc-349bf3055289\",\"login_created\":true}', '2026-11-23 10:46:22');

-- --------------------------------------------------------

--
-- Table structure for table `gold_shop_documents`
--

CREATE TABLE `gold_shop_documents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `gold_shop_id` int(10) UNSIGNED NOT NULL,
  `document_type` varchar(40) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `storage_key` varchar(50) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_size` int(10) UNSIGNED NOT NULL,
  `uploaded_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gold_shop_documents`
--

INSERT INTO `gold_shop_documents` (`id`, `gold_shop_id`, `document_type`, `original_name`, `storage_key`, `mime_type`, `file_size`, `uploaded_by`, `created_at`) VALUES
(5, 3, 'profile_photo', '8.jpg', 'bbc8f734-804c-43d5-8ac0-867e5551cc8e.jpg', 'image/jpeg', 620342, 6, '2026-11-23 08:33:14'),
(6, 3, 'aadhaar_card', '7.jpg', '07749a52-5446-45d3-b5ff-b3977dd02b83.jpg', 'image/jpeg', 728551, 6, '2026-11-23 08:33:14'),
(7, 3, 'gst_certificate', 'QFurn Admin Furniture App UI Mockup.png', '557f0f50-ded6-42aa-aae9-fd1e60466d91.png', 'image/png', 1850250, 6, '2026-11-23 08:33:14'),
(8, 3, 'supporting_document', 'QFurn Admin Furniture App UI Mockup.png', 'c7de4bda-8445-4b73-ba3c-2c8dcc24556d.png', 'image/png', 1850250, 6, '2026-11-23 08:33:14'),
(9, 4, 'profile_photo', '8.jpg', '079c5bc9-fa7c-47a6-a5ab-c940aeb9708d.jpg', 'image/jpeg', 620342, 6, '2026-11-23 09:41:53'),
(10, 4, 'aadhaar_card', '8.jpg', '750ff610-a814-4801-b46c-591f2d6951d3.jpg', 'image/jpeg', 620342, 6, '2026-11-23 09:41:53'),
(11, 4, 'gst_certificate', '7.jpg', '78247473-b0ea-4118-b70f-2ef3e5487a91.jpg', 'image/jpeg', 728551, 6, '2026-11-23 09:41:53'),
(12, 4, 'supporting_document', '7.jpg', '5dc03fa2-def0-4ea8-bb63-854e1dfce9d2.jpg', 'image/jpeg', 728551, 6, '2026-11-23 09:41:53'),
(13, 5, 'profile_photo', 'Warm Mid-Century Living Room Banner.png', '114838e9-f759-45e5-a941-5caad3e0572b.png', 'image/png', 2090883, 6, '2026-11-23 10:45:34'),
(14, 5, 'aadhaar_card', 'Warm Mid-Century Living Room Banner.png', 'f6168444-5134-4606-a134-1273303f797a.png', 'image/png', 2090883, 6, '2026-11-23 10:45:34'),
(15, 5, 'gst_certificate', 'Warm Mid-Century Living Room Banner.png', 'e17d67b4-5645-414b-8d17-73828262b463.png', 'image/png', 2090883, 6, '2026-11-23 10:45:34'),
(16, 5, 'supporting_document', 'Modern Living Room Wave Poster.png', '2d9231a1-ac06-45ea-a6b4-0873d1c60251.png', 'image/png', 1592045, 6, '2026-11-23 10:45:34');

-- --------------------------------------------------------

--
-- Table structure for table `gold_shop_pending_credentials`
--

CREATE TABLE `gold_shop_pending_credentials` (
  `gold_shop_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `home_section_settings`
--

CREATE TABLE `home_section_settings` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `sections_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`sections_json`)),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `interest_types`
--

CREATE TABLE `interest_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `type_key` varchar(30) NOT NULL,
  `label` varchar(80) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `interest_types`
--

INSERT INTO `interest_types` (`id`, `type_key`, `label`, `enabled`, `updated_at`) VALUES
(1, 'simple', 'Simple Interest', 1, '2026-11-23 05:06:06'),
(2, 'compound', 'Compound Interest', 1, '2026-11-23 05:06:06'),
(3, 'flat', 'Flat Rate Interest', 1, '2026-11-23 05:06:06'),
(4, 'reducing_balance', 'Reducing Balance Interest', 1, '2026-11-23 05:06:06'),
(5, 'daily', 'Daily Interest', 1, '2026-11-23 05:06:06'),
(6, 'monthly', 'Monthly Interest', 1, '2026-11-23 05:06:06'),
(7, 'annual', 'Annual Interest', 1, '2026-11-23 05:06:06'),
(8, 'fixed', 'Fixed Interest Amount', 1, '2026-11-23 05:06:06'),
(9, 'slab_based', 'Slab-Based Interest', 1, '2026-11-23 05:06:06'),
(10, 'custom', 'Custom Interest', 1, '2026-11-23 05:06:06');

-- --------------------------------------------------------

--
-- Table structure for table `loans`
--

CREATE TABLE `loans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `loan_number` varchar(40) NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `gold_pledge_number` varchar(60) NOT NULL,
  `jewellery_type` varchar(100) NOT NULL,
  `metal_type` enum('Gold','Silver','Platinum','Diamond') NOT NULL DEFAULT 'Gold',
  `gold_purity` varchar(30) NOT NULL,
  `gross_weight` decimal(12,3) NOT NULL,
  `stone_weight` decimal(12,3) NOT NULL DEFAULT 0.000,
  `net_gold_weight` decimal(12,3) NOT NULL,
  `gold_valuation` decimal(14,2) NOT NULL,
  `gold_rate_per_gram` decimal(14,2) DEFAULT NULL,
  `rate_unit` enum('gram','carat') NOT NULL DEFAULT 'gram',
  `gold_rate_date` date DEFAULT NULL,
  `principal_amount` decimal(14,2) NOT NULL,
  `outstanding_principal` decimal(14,2) DEFAULT NULL,
  `interest_type` varchar(30) NOT NULL,
  `interest_rate` decimal(9,4) NOT NULL DEFAULT 0.0000,
  `fixed_interest_amount` decimal(14,2) DEFAULT NULL,
  `interest_frequency` varchar(20) NOT NULL,
  `custom_period_days` smallint(5) UNSIGNED DEFAULT NULL,
  `interest_calculation_start_date` date NOT NULL,
  `compounding_frequency` varchar(20) DEFAULT NULL,
  `day_count_convention` varchar(20) NOT NULL DEFAULT 'actual_365',
  `grace_period_days` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `late_payment_interest_rate` decimal(9,4) DEFAULT NULL,
  `interest_free_days` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `minimum_interest_amount` decimal(14,2) DEFAULT NULL,
  `maximum_interest_amount` decimal(14,2) DEFAULT NULL,
  `processing_fee` decimal(14,2) NOT NULL DEFAULT 0.00,
  `other_charges` decimal(14,2) NOT NULL DEFAULT 0.00,
  `loan_date` date NOT NULL,
  `maturity_date` date NOT NULL,
  `payment_frequency` varchar(20) NOT NULL,
  `loan_status` varchar(20) NOT NULL DEFAULT 'Active',
  `release_status` varchar(30) NOT NULL DEFAULT 'Not Ready',
  `gold_released_at` datetime DEFAULT NULL,
  `gold_released_to` varchar(150) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `gold_image_url` varchar(255) DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `loan_customers`
--

CREATE TABLE `loan_customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_code` varchar(30) DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `customer_type` varchar(20) NOT NULL DEFAULT 'Individual',
  `full_name` varchar(150) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `alternate_mobile` varchar(15) DEFAULT NULL,
  `email` varchar(254) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(30) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  `guarantor_name` varchar(150) DEFAULT NULL,
  `guarantor_mobile` varchar(15) DEFAULT NULL,
  `guarantor_email` varchar(254) DEFAULT NULL,
  `guarantor_relationship` varchar(100) DEFAULT NULL,
  `guarantor_address` text DEFAULT NULL,
  `kyc_status` varchar(20) NOT NULL DEFAULT 'Pending',
  `photo_url` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `loan_customer_documents`
--

CREATE TABLE `loan_customer_documents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `document_type` varchar(40) NOT NULL,
  `document_side` varchar(10) NOT NULL DEFAULT 'front',
  `file_ref` varchar(120) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_size` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `loan_gold_releases`
--

CREATE TABLE `loan_gold_releases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `loan_id` bigint(20) UNSIGNED NOT NULL,
  `released_at` datetime NOT NULL,
  `released_to` varchar(150) NOT NULL,
  `confirmed_customer_signature` tinyint(1) NOT NULL,
  `signed_document_url` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `released_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `loan_renewals`
--

CREATE TABLE `loan_renewals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `loan_id` bigint(20) UNSIGNED NOT NULL,
  `renewal_date` date NOT NULL,
  `period_start_date` date NOT NULL,
  `previous_maturity_date` date NOT NULL,
  `new_maturity_date` date DEFAULT NULL,
  `payment_amount` decimal(14,2) NOT NULL,
  `interest_paid` decimal(14,2) NOT NULL,
  `late_payment_fee` decimal(14,2) NOT NULL DEFAULT 0.00,
  `principal_paid` decimal(14,2) NOT NULL,
  `principal_before` decimal(14,2) NOT NULL,
  `principal_after` decimal(14,2) NOT NULL,
  `accrued_interest` decimal(14,2) NOT NULL,
  `fund_account_id` bigint(20) UNSIGNED DEFAULT NULL,
  `payment_method` varchar(40) DEFAULT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `idempotency_key` varchar(150) DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `loan_review_actions`
--

CREATE TABLE `loan_review_actions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `loan_id` bigint(20) UNSIGNED NOT NULL,
  `action_type` enum('notice_sent','suspended','reinstated') NOT NULL,
  `notice_method` varchar(20) DEFAULT NULL,
  `customer_message` text DEFAULT NULL,
  `notes` text NOT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `metals`
--

CREATE TABLE `metals` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `purity` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` longtext DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_by` varchar(255) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `updated_by` varchar(255) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `metals`
--

INSERT INTO `metals` (`id`, `name`, `purity`, `description`, `image`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(2, 'Gold', '22k', NULL, NULL, 'Active', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:42:49', '2026-11-23 11:42:55'),
(3, 'Silver', NULL, NULL, NULL, 'Active', 'c640f180-60e2-4014-afbc-349bf3055289', 'c640f180-60e2-4014-afbc-349bf3055289', '2026-11-23 11:46:37', '2026-11-23 11:47:16'),
(4, 'Silver', NULL, NULL, NULL, 'Active', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:49:43', '2026-11-23 11:49:43'),
(5, 'Platinum', NULL, NULL, NULL, 'Active', '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286', '2026-11-23 11:50:05', '2026-11-23 11:50:05');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) UNSIGNED NOT NULL,
  `payment_id` char(36) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `gold_shop_id` int(10) UNSIGNED NOT NULL,
  `subscription_id` int(10) UNSIGNED NOT NULL,
  `transaction_id` varchar(120) DEFAULT NULL,
  `invoice_number` varchar(100) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `refund_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_reference` varchar(150) DEFAULT NULL,
  `payment_status` enum('paid','pending','unpaid','failed','refunded','cancelled') NOT NULL DEFAULT 'pending',
  `payment_date` datetime DEFAULT NULL,
  `refund_date` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `payment_id`, `gold_shop_id`, `subscription_id`, `transaction_id`, `invoice_number`, `amount`, `refund_amount`, `payment_method`, `payment_reference`, `payment_status`, `payment_date`, `refund_date`, `notes`, `rejection_reason`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(12, '28f6682b-b28d-4640-bc6d-45e3ccf92976', 3, 12, '6865756756', 'INV-2026-00012', 4999.00, 4999.00, 'UPI', NULL, 'refunded', '2026-11-23 14:03:33', '2026-11-23 15:56:44', 'Refund of ₹4999.00: dfdfg', NULL, '2026-11-23 08:33:14', '2026-11-23 10:26:44', 6, 6),
(13, '91f4b762-0e5b-40cb-8aa8-e8f15f0845d8', 3, 13, '754544454747', 'INV-2026-00013', 499.00, 0.00, 'UPI', NULL, 'paid', '2026-11-23 14:05:31', NULL, NULL, NULL, '2026-11-23 08:35:17', '2026-11-23 10:09:56', 6, 6),
(14, '756a1934-5d0e-4018-8edd-c6961f02e606', 4, 14, '856875474745754', 'INV-2026-00014', 1599.00, 0.00, 'UPI', NULL, 'paid', '2026-11-23 15:12:26', NULL, NULL, NULL, '2026-11-23 09:41:53', '2026-11-23 10:09:56', 6, 6),
(15, '5cc9e0e4-7cca-41f6-baad-66477c98cce2', 5, 15, '7967969679679679', 'INV-2026-00015', 2499.00, 0.00, 'UPI', NULL, 'paid', '2026-11-23 16:16:07', NULL, NULL, NULL, '2026-11-23 10:45:34', '2026-11-23 10:50:30', 6, 6);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(150) NOT NULL,
  `subcategory` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `mrp` decimal(14,2) NOT NULL DEFAULT 0.00,
  `offer` decimal(7,2) NOT NULL DEFAULT 0.00,
  `offer_price` decimal(14,2) NOT NULL DEFAULT 0.00,
  `rating` decimal(3,2) NOT NULL DEFAULT 0.00,
  `total_stock` int(11) NOT NULL DEFAULT 0,
  `status` varchar(32) NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `brand` varchar(150) DEFAULT NULL,
  `metal_type` varchar(150) DEFAULT NULL,
  `product_type` varchar(100) DEFAULT NULL,
  `full_description` text DEFAULT NULL,
  `purity` varchar(50) DEFAULT NULL,
  `gross_weight` decimal(12,3) DEFAULT NULL,
  `net_gold_weight` decimal(12,3) DEFAULT NULL,
  `gold_rate_per_gram` decimal(14,2) DEFAULT NULL,
  `gold_rate_date` date DEFAULT NULL,
  `making_charge_type` varchar(32) DEFAULT NULL,
  `making_charge` decimal(14,2) DEFAULT NULL,
  `wastage_type` varchar(32) DEFAULT NULL,
  `wastage` decimal(12,3) DEFAULT NULL,
  `stone_weight` decimal(12,3) DEFAULT NULL,
  `stone_charges` decimal(14,2) DEFAULT NULL,
  `stone_type` varchar(100) DEFAULT NULL,
  `huid` varchar(100) DEFAULT NULL,
  `available_sizes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`available_sizes`)),
  `product_size` varchar(100) DEFAULT NULL,
  `length` varchar(50) DEFAULT NULL,
  `width` varchar(50) DEFAULT NULL,
  `height` varchar(50) DEFAULT NULL,
  `ring_size` varchar(50) DEFAULT NULL,
  `bangle_size` varchar(50) DEFAULT NULL,
  `chain_length` varchar(50) DEFAULT NULL,
  `size_guide_chart` varchar(500) DEFAULT NULL,
  `discount` decimal(7,2) DEFAULT NULL,
  `gst_rate` decimal(7,2) DEFAULT NULL,
  `final_selling_price` decimal(14,2) DEFAULT NULL,
  `offer_type` varchar(32) NOT NULL DEFAULT 'None',
  `fixed_discount_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `gold_value` decimal(14,2) DEFAULT NULL,
  `pre_discount_price` decimal(14,2) DEFAULT NULL,
  `tax_amount` decimal(14,2) DEFAULT NULL,
  `applied_discount` decimal(14,2) DEFAULT NULL,
  `price_updated_at` datetime DEFAULT NULL,
  `other_charges` decimal(14,2) NOT NULL DEFAULT 0.00,
  `price_includes_gst` tinyint(1) NOT NULL DEFAULT 0,
  `highlights` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`highlights`)),
  `specifications` text DEFAULT NULL,
  `care_instructions` text DEFAULT NULL,
  `warranty` text DEFAULT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `video` varchar(500) DEFAULT NULL,
  `certificate` varchar(500) DEFAULT NULL,
  `total_reviews` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `stock_status` varchar(32) DEFAULT NULL,
  `sku_barcode` varchar(150) DEFAULT NULL,
  `warehouse` varchar(150) DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `new_arrival` tinyint(1) NOT NULL DEFAULT 0,
  `best_seller` tinyint(1) NOT NULL DEFAULT 0,
  `variants` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`variants`)),
  `material` varchar(150) DEFAULT NULL,
  `wash_care` varchar(255) DEFAULT NULL,
  `saree_length` varchar(100) DEFAULT NULL,
  `blouse_length` varchar(100) DEFAULT NULL,
  `top_length` varchar(100) DEFAULT NULL,
  `bottom_length` varchar(100) DEFAULT NULL,
  `dupatta_length` varchar(100) DEFAULT NULL,
  `gown_length` varchar(100) DEFAULT NULL,
  `sleeve_type` varchar(100) DEFAULT NULL,
  `neck_type` varchar(100) DEFAULT NULL,
  `fit_type` varchar(100) DEFAULT NULL,
  `work_type` varchar(150) DEFAULT NULL,
  `zari_color` varchar(100) DEFAULT NULL,
  `age` varchar(50) DEFAULT NULL,
  `created_by` varchar(255) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `updated_by` varchar(255) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_code`, `name`, `category`, `subcategory`, `description`, `mrp`, `offer`, `offer_price`, `rating`, `total_stock`, `status`, `created_at`, `updated_at`, `brand`, `metal_type`, `product_type`, `full_description`, `purity`, `gross_weight`, `net_gold_weight`, `gold_rate_per_gram`, `gold_rate_date`, `making_charge_type`, `making_charge`, `wastage_type`, `wastage`, `stone_weight`, `stone_charges`, `stone_type`, `huid`, `available_sizes`, `product_size`, `length`, `width`, `height`, `ring_size`, `bangle_size`, `chain_length`, `size_guide_chart`, `discount`, `gst_rate`, `final_selling_price`, `offer_type`, `fixed_discount_amount`, `gold_value`, `pre_discount_price`, `tax_amount`, `applied_discount`, `price_updated_at`, `other_charges`, `price_includes_gst`, `highlights`, `specifications`, `care_instructions`, `warranty`, `images`, `video`, `certificate`, `total_reviews`, `stock_status`, `sku_barcode`, `warehouse`, `featured`, `new_arrival`, `best_seller`, `variants`, `material`, `wash_care`, `saree_length`, `blouse_length`, `top_length`, `bottom_length`, `dupatta_length`, `gown_length`, `sleeve_type`, `neck_type`, `fit_type`, `work_type`, `zari_color`, `age`, `created_by`, `updated_by`) VALUES
(1, 'GOLD-PRD-001', 'Good', 'Hand Harness Jewellery', 'Multi-Finger Hand Harness', '', 4950.00, 0.00, 49.50, 0.00, 10, 'Active', '2026-11-23 10:34:20', '2026-11-23 11:10:21', 'Sri Gold', 'Gold', 'Daily Wear', 'dfhfdhd', '24K / 999', 50.000, 45.000, 1.00, '2026-11-23', 'Percentage', 5.00, 'Percentage', 5.000, 5.000, 0.00, 'None', '', '[\"12\"]', 'Small', '12', '', '', '', '', '', '/uploads/products/6363ca53-75a8-4c89-a605-b31350f46257.png', 0.00, 0.00, 49.50, 'Percentage', 0.00, 45.00, 49.50, 0.00, 0.00, '2026-11-23 16:40:21', 0.00, 1, '[]', '', '', '', '[\"/uploads/products/d3e48e14-9156-447b-8379-67b645150d58.webp\",\"/uploads/products/71ab30f6-9833-4aa2-b1a7-af98e50812c1.webp\",\"/uploads/products/6db2778f-e871-4167-9010-ea0e1984da84.webp\",\"/uploads/products/b1047a60-82f4-460d-b7e1-a780d9c23c6d.webp\"]', '', '', 0, 'In Stock', '', 'Main Shop', 0, 0, 0, '[{\"images\":[\"/uploads/products/d3e48e14-9156-447b-8379-67b645150d58.webp\",\"/uploads/products/71ab30f6-9833-4aa2-b1a7-af98e50812c1.webp\",\"/uploads/products/6db2778f-e871-4167-9010-ea0e1984da84.webp\",\"/uploads/products/b1047a60-82f4-460d-b7e1-a780d9c23c6d.webp\"]}]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5b651783-607e-4733-97d7-bf76871c0286', '5b651783-607e-4733-97d7-bf76871c0286'),
(2, 'GOLD-PRD-002', 'My', 'Rings', 'Wedding Rings', '', 6600.00, 10.00, 59.40, 0.00, 10, 'Active', '2026-11-23 10:42:39', '2026-11-23 11:10:21', 'Sri Gold', 'Gold', 'Traditional', 'tfurutr', '24K / 999', 70.000, 60.000, 1.00, '2026-11-23', 'Percentage', 5.00, 'Percentage', 5.000, 10.000, 0.00, 'None', '', '[\"12\"]', 'Small', '', '12 Inches', '150', '3', '4', '23', '/uploads/products/88b10685-a231-401f-9b75-a9999aa1d232.png', 660.00, 0.00, 59.40, 'Percentage', 0.00, 60.00, 66.00, 0.00, 6.60, '2026-11-23 16:40:21', 0.00, 1, '[]', '', 'rturt', '', '[\"/uploads/products/02f17848-5f40-4fd6-a3f7-4581e742e003.webp\",\"/uploads/products/af1e5f2d-a754-4834-9125-70a3e971896e.webp\"]', '', '', 0, 'In Stock', '', 'Main Shop', 0, 0, 0, '[{\"images\":[\"/uploads/products/02f17848-5f40-4fd6-a3f7-4581e742e003.webp\",\"/uploads/products/af1e5f2d-a754-4834-9125-70a3e971896e.webp\"]}]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5b651783-607e-4733-97d7-bf76871c0286', NULL),
(3, 'GOLD-PRD-001', 'Go', 'Waist Belts', 'Lightweight Waist Belts', '', 17600.00, 0.00, 792.00, 0.00, 20, 'Active', '2026-11-23 10:57:53', '2026-11-23 11:19:59', 'Sri Gold', 'Gold', 'Daily Wear', '', '22K / 916', 100.000, 80.000, 9.00, '2026-11-23', 'Percentage', 5.00, 'Percentage', 5.000, 20.000, 0.00, 'None', '', '[]', '', '', '', '', '', '', '', '', 0.00, 0.00, 792.00, 'Percentage', 0.00, 720.00, 792.00, 0.00, 0.00, '2026-11-23 16:49:59', 0.00, 1, '[]', '', '', '', '[\"/uploads/products/0b787dfb-15dc-4904-8903-2c7c211fa1df.webp\",\"/uploads/products/092cc485-6df3-476d-a391-21dd4995a103.webp\",\"/uploads/products/bc990764-c1b2-413d-9b00-cfd18dda00d5.webp\",\"/uploads/products/24b3fc08-4e03-4795-97ea-cc5815be9777.webp\"]', '', '', 0, 'In Stock', '', 'Main Shop', 0, 0, 0, '[{\"images\":[\"/uploads/products/0b787dfb-15dc-4904-8903-2c7c211fa1df.webp\",\"/uploads/products/092cc485-6df3-476d-a391-21dd4995a103.webp\",\"/uploads/products/bc990764-c1b2-413d-9b00-cfd18dda00d5.webp\",\"/uploads/products/24b3fc08-4e03-4795-97ea-cc5815be9777.webp\"]}]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'c640f180-60e2-4014-afbc-349bf3055289', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_price_history`
--

CREATE TABLE `product_price_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `product_code` varchar(100) DEFAULT NULL,
  `previous_price` decimal(14,2) DEFAULT NULL,
  `new_price` decimal(14,2) NOT NULL,
  `rate_per_gram` decimal(14,2) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `changed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_price_history`
--

INSERT INTO `product_price_history` (`id`, `product_id`, `product_code`, `previous_price`, `new_price`, `rate_per_gram`, `reason`, `changed_by`, `changed_at`) VALUES
(1, 1, 'GOLD-PRD-001', NULL, 4950.00, 100.00, 'Initial product pricing', 14, '2026-11-23 10:34:20'),
(2, 2, 'GOLD-PRD-002', NULL, 5940.00, 100.00, 'Initial product pricing', 14, '2026-11-23 10:42:39'),
(3, 3, 'GOLD-PRD-001', NULL, 17600.00, 200.00, 'Initial product pricing', 15, '2026-11-23 10:57:53'),
(4, 1, 'GOLD-PRD-001', 4950.00, 49.50, 1.00, 'Daily rate activated: Daily market price update', 14, '2026-11-23 11:10:21'),
(5, 2, 'GOLD-PRD-002', 5940.00, 59.40, 1.00, 'Daily rate activated: Daily market price update', 14, '2026-11-23 11:10:21'),
(6, 3, 'GOLD-PRD-001', 17600.00, 176.00, 2.00, 'Daily rate activated: Daily market price update', 14, '2026-11-23 11:10:21'),
(7, 3, 'GOLD-PRD-001', 176.00, 792.00, 9.00, 'Daily rate activated: Daily market price update', 15, '2026-11-23 11:19:59');

-- --------------------------------------------------------

--
-- Table structure for table `receipt_settings`
--

CREATE TABLE `receipt_settings` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `settings_json` longtext NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED DEFAULT NULL,
  `user_name` varchar(150) NOT NULL,
  `user_email` varchar(254) DEFAULT NULL,
  `rating` tinyint(3) UNSIGNED NOT NULL,
  `comment` text NOT NULL,
  `review_image` varchar(500) DEFAULT NULL,
  `status` enum('Pending','Published','Flagged') NOT NULL DEFAULT 'Pending',
  `admin_reply` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` int(10) UNSIGNED NOT NULL,
  `gold_shop_id` int(10) UNSIGNED NOT NULL,
  `plan_id` int(10) UNSIGNED NOT NULL,
  `duration` enum('monthly','quarterly','half_yearly','yearly') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `payment_status` enum('paid','pending','unpaid') NOT NULL DEFAULT 'pending',
  `subscription_status` enum('active','pending','expired','suspended') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `gold_shop_id`, `plan_id`, `duration`, `amount`, `start_date`, `end_date`, `payment_status`, `subscription_status`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(12, 3, 41, 'monthly', 4999.00, '2026-11-23', '2026-12-23', 'paid', 'pending', '2026-11-23 08:33:14', '2026-11-23 08:33:33', 6, 6),
(13, 3, 39, 'monthly', 499.00, '2026-11-23', '2026-12-23', 'paid', 'active', '2026-11-23 08:35:17', '2026-11-23 08:37:27', 6, 6),
(14, 4, 47, 'monthly', 1599.00, '2026-11-23', '2026-12-23', 'paid', 'pending', '2026-11-23 09:41:53', '2026-11-23 09:42:26', 6, 6),
(15, 5, 40, 'monthly', 2499.00, '2026-11-23', '2026-12-23', 'paid', 'pending', '2026-11-23 10:45:34', '2026-11-23 10:46:07', 6, 6);

-- --------------------------------------------------------

--
-- Table structure for table `subscription_plans`
--

CREATE TABLE `subscription_plans` (
  `id` int(10) UNSIGNED NOT NULL,
  `plan_name` varchar(80) NOT NULL,
  `monthly_price` decimal(10,2) NOT NULL,
  `quarterly_price` decimal(10,2) NOT NULL,
  `yearly_price` decimal(10,2) NOT NULL,
  `max_branches` int(10) UNSIGNED DEFAULT NULL,
  `max_staff` int(10) UNSIGNED DEFAULT NULL,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`features`)),
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `plan_uuid` char(36) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `plan_code` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `half_yearly_price` decimal(10,2) DEFAULT NULL,
  `setup_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `free_trial_days` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `max_users` int(10) UNSIGNED DEFAULT NULL,
  `max_products` int(10) UNSIGNED DEFAULT NULL,
  `max_monthly_invoices` int(10) UNSIGNED DEFAULT NULL,
  `grace_period_days` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `display_order` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscription_plans`
--

INSERT INTO `subscription_plans` (`id`, `plan_name`, `monthly_price`, `quarterly_price`, `yearly_price`, `max_branches`, `max_staff`, `features`, `status`, `created_at`, `updated_at`, `created_by`, `updated_by`, `plan_uuid`, `plan_code`, `description`, `half_yearly_price`, `setup_fee`, `free_trial_days`, `max_users`, `max_products`, `max_monthly_invoices`, `grace_period_days`, `is_featured`, `display_order`) VALUES
(39, 'Basic', 499.00, 0.00, 0.00, NULL, NULL, '{\"goldInventory\":false,\"silverInventory\":false,\"purchaseManagement\":false,\"salesBilling\":false,\"customerManagement\":false,\"supplierManagement\":false,\"goldRateManagement\":false,\"stockManagement\":false,\"barcodeManagement\":false,\"invoicePrinting\":false,\"reportsAnalytics\":false,\"backupExport\":false}', 'active', '2026-11-23 08:18:15', '2026-11-23 08:18:15', 6, 6, 'd695b0ab-27f0-432c-97be-f566b3e837e1', 'BASIC-1972', '', 0.00, 0.00, 0, NULL, NULL, NULL, 0, 0, 0),
(40, 'Premium', 2499.00, 0.00, 0.00, NULL, NULL, '{\"goldInventory\":false,\"silverInventory\":false,\"purchaseManagement\":false,\"salesBilling\":false,\"customerManagement\":false,\"supplierManagement\":false,\"goldRateManagement\":false,\"stockManagement\":false,\"barcodeManagement\":false,\"invoicePrinting\":false,\"reportsAnalytics\":false,\"backupExport\":false}', 'active', '2026-11-23 08:18:40', '2026-11-23 08:18:40', 6, 6, '7fb9cb51-861a-40ac-baf1-acd16287ed64', 'PREMIUM-3536', '', 0.00, 0.00, 0, NULL, NULL, NULL, 0, 0, 0),
(41, 'Enterprise', 4999.00, 0.00, 0.00, NULL, NULL, '{\"goldInventory\":false,\"silverInventory\":false,\"purchaseManagement\":false,\"salesBilling\":false,\"customerManagement\":false,\"supplierManagement\":false,\"goldRateManagement\":false,\"stockManagement\":false,\"barcodeManagement\":false,\"invoicePrinting\":false,\"reportsAnalytics\":false,\"backupExport\":false}', 'active', '2026-11-23 08:19:12', '2026-11-23 08:19:12', 6, 6, 'daca315b-95e0-49ff-9381-8a658fadec97', 'ENTERPRISE-3322', '', 0.00, 0.00, 0, NULL, NULL, NULL, 0, 0, 0),
(42, 'Standard', 1499.00, 0.00, 0.00, NULL, NULL, '{\"goldInventory\":false,\"silverInventory\":false,\"purchaseManagement\":false,\"salesBilling\":false,\"customerManagement\":false,\"supplierManagement\":false,\"goldRateManagement\":false,\"stockManagement\":false,\"barcodeManagement\":false,\"invoicePrinting\":false,\"reportsAnalytics\":false,\"backupExport\":false}', 'active', '2026-11-23 08:19:30', '2026-11-23 08:19:30', 6, 6, '847f4969-8b15-4370-a41e-77d1ae306294', 'STANDARD-1782', '', 0.00, 0.00, 0, NULL, NULL, NULL, 0, 0, 0),
(46, 'Growth', 1299.00, 3897.00, 15588.00, NULL, NULL, '[\"Shop profile\",\"Inventory\",\"Reports\",\"Priority support\",\"Multi-branch support\"]', 'active', '2026-11-23 09:29:02', '2026-11-23 09:29:02', NULL, NULL, '12e0072f-cdee-48ea-ad78-b789e1f02d19', 'PLAN-0046', NULL, 7794.00, 0.00, 0, NULL, NULL, NULL, 0, 0, 0),
(47, 'Gold', 1599.00, 4797.00, 19188.00, NULL, NULL, '[\"Shop profile\",\"Inventory\",\"Reports\",\"Priority support\",\"Multi-branch support\",\"Staff management\"]', 'active', '2026-11-23 09:29:02', '2026-11-23 09:29:02', NULL, NULL, 'bc37ada9-34f8-4b88-8817-6af251b95464', 'PLAN-0047', NULL, 9594.00, 0.00, 0, NULL, NULL, NULL, 0, 0, 0),
(48, 'Platinum', 1999.00, 5997.00, 23988.00, NULL, NULL, '[\"Shop profile\",\"Inventory\",\"Reports\",\"Priority support\",\"Multi-branch support\",\"Staff management\",\"Advanced analytics\"]', 'active', '2026-11-23 09:29:02', '2026-11-23 09:29:02', NULL, NULL, '16f9cbc2-e9ec-4865-8bbd-1c8f0d5101d4', 'PLAN-0048', NULL, 11994.00, 0.00, 0, NULL, NULL, NULL, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `subscription_plan_history`
--

CREATE TABLE `subscription_plan_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plan_id` int(10) UNSIGNED DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `changed_by` int(10) UNSIGNED DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` varchar(255) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `username` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `notification_preferences` text DEFAULT NULL,
  `role` varchar(32) NOT NULL DEFAULT 'user',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `gold_shop_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `username`, `name`, `email`, `phone`, `password_hash`, `address`, `profile_image`, `notification_preferences`, `role`, `status`, `created_at`, `updated_at`, `gold_shop_id`) VALUES
(1, '2c9f163f-e700-11f1-8318-51021565bd83', 'Admin', 'Admin', 'admin@gmail.com', '9865359464', '$2a$12$OeWLFCAzXPXLY/61kxjyyeCWR3UQLRSnRW/HnSVCPK9Mg5zbaIF52', NULL, NULL, NULL, 'admin', 'active', '2026-11-23 05:19:17', '2026-11-23 05:38:56', NULL),
(6, '3390ad6c-e700-11f1-8318-51021565bd83', 'SuperAdmin', 'SuperAdmin', 'superadmin@gmail.com', '7894045096', '$2a$12$19OVhk2MU7OgtLoMQJf/XeuH7xAfxCPoFVy5okBF0qRETe/QfU/36', NULL, NULL, NULL, 'superadmin', 'active', '2026-11-23 05:39:07', '2026-11-23 10:14:22', NULL),
(13, '9b9dde39-96f9-431f-bd4b-9cc7240bba80', 'Dhiva', 'Dhiva', 'dhiva@gmail.com', '8940450977', '$2a$12$0nXuNWvkHUkdUMM7cnIe6uY7.mxdkAvYlB/2iA4KB/ey1e1VR1ocS', NULL, NULL, NULL, 'admin', 'active', '2026-11-23 08:33:14', '2026-11-23 10:20:45', 3),
(14, '5b651783-607e-4733-97d7-bf76871c0286', 'Thenuga', 'Thenuga', 'thenuga@gmail.com', '6383493433', '$2a$12$qmR4H09WLxH.lDQCzJXrlOfn7xCAagbKzWIoWHq6/ekrZe4bYUQxW', NULL, NULL, NULL, 'admin', 'active', '2026-11-23 09:42:34', '2026-11-23 09:42:34', 4),
(15, 'c640f180-60e2-4014-afbc-349bf3055289', 'Nishanth', 'Nishanth', 'nishanth@gmail.com', '6789067890', '$2a$12$yR9Dpbl/552ngDhyyWM2MOI65f74DlbDkrWsK.S32kLsz7y2oq5l.', NULL, NULL, NULL, 'admin', 'active', '2026-11-23 10:46:22', '2026-11-23 10:46:22', 5);

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `bi_users_uuid` BEFORE INSERT ON `users` FOR EACH ROW SET NEW.user_id = IF(NEW.user_id IS NULL OR NEW.user_id = '', UUID(), NEW.user_id)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(200) NOT NULL,
  `video_id` varchar(500) NOT NULL,
  `thumbnail` varchar(500) DEFAULT NULL,
  `type` enum('youtube','custom') NOT NULL DEFAULT 'youtube',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wishlist_items`
--

CREATE TABLE `wishlist_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `variant_color` varchar(100) NOT NULL DEFAULT '',
  `variant_size` varchar(100) NOT NULL DEFAULT '',
  `image` varchar(1000) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_banners_type_active` (`type`,`active`),
  ADD KEY `idx_banners_created_at` (`created_at`);

--
-- Indexes for table `billings`
--
ALTER TABLE `billings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_no` (`invoice_no`);

--
-- Indexes for table `billing_payments`
--
ALTER TABLE `billing_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_billing_payment_idempotency` (`idempotency_key`),
  ADD KEY `fk_billing_payments_account` (`account_id`),
  ADD KEY `idx_billing_payments_bill` (`billing_id`,`payment_date`,`id`);

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_cart_user_product_variant` (`user_id`,`product_id`,`variant_color`,`variant_size`),
  ADD KEY `fk_cart_product` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_categories_user_cat_id` (`user_id`,`catId`),
  ADD KEY `fk_categories_created_by_user_id` (`created_by`),
  ADD KEY `fk_categories_updated_by_user_id` (`updated_by`);

--
-- Indexes for table `dealers`
--
ALTER TABLE `dealers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `dealer_code` (`dealer_code`),
  ADD KEY `fk_dealers_category` (`category_id`),
  ADD KEY `idx_dealers_name` (`name`),
  ADD KEY `idx_dealers_status_category` (`status`,`category_id`),
  ADD KEY `idx_dealers_gstin` (`gstin`),
  ADD KEY `fk_dealers_user` (`created_by`);

--
-- Indexes for table `dealer_audit_log`
--
ALTER TABLE `dealer_audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_dealer_audit` (`dealer_id`,`created_at`),
  ADD KEY `fk_dealer_audit_user` (`actor_id`);

--
-- Indexes for table `dealer_categories`
--
ALTER TABLE `dealer_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `dealer_documents`
--
ALTER TABLE `dealer_documents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stored_name` (`stored_name`),
  ADD KEY `idx_dealer_documents` (`dealer_id`,`created_at`),
  ADD KEY `fk_dealer_document_user` (`uploaded_by`);

--
-- Indexes for table `dealer_financial_ledger`
--
ALTER TABLE `dealer_financial_ledger`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `entry_number` (`entry_number`),
  ADD KEY `idx_dealer_financial_ledger` (`dealer_id`,`created_at`,`id`),
  ADD KEY `fk_dealer_ledger_user` (`posted_by`);

--
-- Indexes for table `dealer_jobs`
--
ALTER TABLE `dealer_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `job_number` (`job_number`),
  ADD KEY `idx_dealer_jobs` (`dealer_id`,`status`,`due_date`),
  ADD KEY `fk_dealer_job_user` (`created_by`);

--
-- Indexes for table `dealer_job_issues`
--
ALTER TABLE `dealer_job_issues`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_dealer_job_issues` (`job_id`),
  ADD KEY `fk_dealer_job_issue_user` (`posted_by`);

--
-- Indexes for table `dealer_job_receipts`
--
ALTER TABLE `dealer_job_receipts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `receipt_number` (`receipt_number`),
  ADD KEY `idx_dealer_job_receipts` (`job_id`),
  ADD KEY `fk_dealer_job_receipt_user` (`posted_by`);

--
-- Indexes for table `dealer_job_reconciliations`
--
ALTER TABLE `dealer_job_reconciliations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `job_id` (`job_id`),
  ADD KEY `fk_dealer_job_approver` (`approved_by`);

--
-- Indexes for table `dealer_metal_ledger`
--
ALTER TABLE `dealer_metal_ledger`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `entry_number` (`entry_number`),
  ADD KEY `idx_dealer_metal_ledger` (`dealer_id`,`created_at`,`id`,`metal_type`,`purity`),
  ADD KEY `fk_dealer_metal_user` (`posted_by`);

--
-- Indexes for table `dealer_old_gold_receipts`
--
ALTER TABLE `dealer_old_gold_receipts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `receipt_number` (`receipt_number`),
  ADD KEY `idx_dealer_old_gold` (`dealer_id`,`received_at`),
  ADD KEY `fk_dealer_old_gold_user` (`received_by`);

--
-- Indexes for table `dealer_payments`
--
ALTER TABLE `dealer_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payment_number` (`payment_number`),
  ADD UNIQUE KEY `idempotency_key` (`idempotency_key`),
  ADD KEY `idx_dealer_payment_date` (`dealer_id`,`payment_date`),
  ADD KEY `fk_dealer_payment_user` (`posted_by`);

--
-- Indexes for table `dealer_payment_allocations`
--
ALTER TABLE `dealer_payment_allocations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_dealer_payment_purchase` (`payment_id`,`purchase_id`),
  ADD KEY `fk_dealer_allocation_purchase` (`purchase_id`);

--
-- Indexes for table `dealer_payment_reversals`
--
ALTER TABLE `dealer_payment_reversals`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payment_id` (`payment_id`),
  ADD KEY `fk_dealer_payment_reversal_user` (`reversed_by`);

--
-- Indexes for table `dealer_purchases`
--
ALTER TABLE `dealer_purchases`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `document_number` (`document_number`),
  ADD UNIQUE KEY `uq_dealer_supplier_invoice` (`dealer_id`,`supplier_invoice_number`),
  ADD KEY `idx_dealer_purchase_due` (`dealer_id`,`due_date`,`document_type`),
  ADD KEY `idx_dealer_purchase_date` (`document_date`,`document_type`),
  ADD KEY `fk_dealer_purchase_user` (`posted_by`);

--
-- Indexes for table `dealer_purchase_lines`
--
ALTER TABLE `dealer_purchase_lines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_dealer_purchase_lines` (`purchase_id`);

--
-- Indexes for table `dealer_refining_receipts`
--
ALTER TABLE `dealer_refining_receipts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `refining_number` (`refining_number`),
  ADD KEY `fk_dealer_refining_old_gold` (`old_gold_receipt_id`),
  ADD KEY `idx_dealer_refining` (`dealer_id`,`received_at`),
  ADD KEY `fk_dealer_refining_user` (`received_by`);

--
-- Indexes for table `dealer_sequences`
--
ALTER TABLE `dealer_sequences`
  ADD PRIMARY KEY (`sequence_name`);

--
-- Indexes for table `enquiries`
--
ALTER TABLE `enquiries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_enquiries_status_created` (`status`,`created_at`),
  ADD KEY `idx_enquiries_phone` (`phone`),
  ADD KEY `idx_enquiries_product` (`product_id`);

--
-- Indexes for table `fund_accounts`
--
ALTER TABLE `fund_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_fund_account_name` (`name`);

--
-- Indexes for table `fund_transactions`
--
ALTER TABLE `fund_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_fund_transactions_idempotency` (`idempotency_key`),
  ADD KEY `idx_fund_transactions_date` (`transaction_date`,`id`),
  ADD KEY `idx_fund_transactions_account_date` (`account_id`,`transaction_date`,`id`),
  ADD KEY `idx_fund_transactions_category` (`category`);

--
-- Indexes for table `gold_rates`
--
ALTER TABLE `gold_rates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_gold_rates_batch_metal_purity` (`batch_id`,`metal_type`,`purity`),
  ADD UNIQUE KEY `uq_gold_rates_user_date_metal_purity` (`user_id`,`rate_date`,`metal_type`,`purity`),
  ADD KEY `idx_gold_rates_current` (`status`,`effective_from`),
  ADD KEY `idx_gold_rates_rate_date` (`rate_date`),
  ADD KEY `fk_gold_rates_updated_by_user_id` (`updated_by`),
  ADD KEY `fk_gold_rates_created_by_user_id` (`created_by`),
  ADD KEY `idx_gold_rates_user_current` (`user_id`,`status`,`effective_from`);

--
-- Indexes for table `gold_rate_history`
--
ALTER TABLE `gold_rate_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_gold_rate_history_batch` (`batch_id`,`changed_at`),
  ADD KEY `idx_gold_rate_history_changed_at` (`changed_at`),
  ADD KEY `fk_gold_rate_history_changed_by_user_id` (`changed_by`);

--
-- Indexes for table `gold_shops`
--
ALTER TABLE `gold_shops`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_gold_shops_uuid` (`shop_uuid`),
  ADD UNIQUE KEY `uq_gold_shops_code` (`shop_code`),
  ADD UNIQUE KEY `uq_gold_shops_name_mobile` (`shop_name`,`mobile`),
  ADD UNIQUE KEY `uq_gold_shops_email` (`email`),
  ADD UNIQUE KEY `uq_gold_shops_gst_number` (`gst_number`),
  ADD KEY `idx_gold_shops_status` (`status`),
  ADD KEY `idx_gold_shops_city` (`city`),
  ADD KEY `fk_gold_shops_created_by_user_id` (`created_by`),
  ADD KEY `fk_gold_shops_updated_by_user_id` (`updated_by`),
  ADD KEY `fk_gold_shops_owner_user` (`owner_user_id`);

--
-- Indexes for table `gold_shop_activity_logs`
--
ALTER TABLE `gold_shop_activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_gold_shop_activity` (`gold_shop_id`,`created_at`),
  ADD KEY `fk_gold_shop_activity_actor` (`actor_id`);

--
-- Indexes for table `gold_shop_documents`
--
ALTER TABLE `gold_shop_documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_gold_shop_documents_shop` (`gold_shop_id`,`id`),
  ADD KEY `fk_gold_shop_documents_uploader` (`uploaded_by`);

--
-- Indexes for table `gold_shop_pending_credentials`
--
ALTER TABLE `gold_shop_pending_credentials`
  ADD PRIMARY KEY (`gold_shop_id`),
  ADD UNIQUE KEY `uq_gold_shop_pending_credentials_username` (`username`);

--
-- Indexes for table `home_section_settings`
--
ALTER TABLE `home_section_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `interest_types`
--
ALTER TABLE `interest_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type_key` (`type_key`);

--
-- Indexes for table `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `loan_number` (`loan_number`),
  ADD UNIQUE KEY `uq_loans_gold_pledge_number` (`gold_pledge_number`),
  ADD KEY `idx_loans_customer_status` (`customer_id`,`loan_status`),
  ADD KEY `idx_loans_maturity_status` (`maturity_date`,`loan_status`);

--
-- Indexes for table `loan_customers`
--
ALTER TABLE `loan_customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customer_code` (`customer_code`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `loan_customer_documents`
--
ALTER TABLE `loan_customer_documents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `file_ref` (`file_ref`),
  ADD KEY `fk_loan_customer_documents_customer` (`customer_id`);

--
-- Indexes for table `loan_gold_releases`
--
ALTER TABLE `loan_gold_releases`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `loan_id` (`loan_id`);

--
-- Indexes for table `loan_renewals`
--
ALTER TABLE `loan_renewals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_loan_renewals_loan_date` (`loan_id`,`renewal_date`,`id`);

--
-- Indexes for table `loan_review_actions`
--
ALTER TABLE `loan_review_actions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_loan_review_actions_loan_date` (`loan_id`,`created_at`,`id`);

--
-- Indexes for table `metals`
--
ALTER TABLE `metals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_metals_created_by_user_id` (`created_by`),
  ADD KEY `fk_metals_updated_by_user_id` (`updated_by`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_payments_transaction_id` (`transaction_id`),
  ADD KEY `idx_payments_shop` (`gold_shop_id`,`created_at`),
  ADD KEY `idx_payments_subscription` (`subscription_id`),
  ADD KEY `fk_payments_created_by` (`created_by`),
  ADD KEY `fk_payments_updated_by` (`updated_by`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_products_creator_code` (`created_by`,`product_code`),
  ADD KEY `fk_products_updated_by_user_id` (`updated_by`);

--
-- Indexes for table `product_price_history`
--
ALTER TABLE `product_price_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_product_price_history_product` (`product_id`,`changed_at`),
  ADD KEY `idx_product_price_history_changed` (`changed_at`);

--
-- Indexes for table `receipt_settings`
--
ALTER TABLE `receipt_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_reviews_status_rating` (`status`,`rating`),
  ADD KEY `idx_reviews_product` (`product_id`),
  ADD KEY `idx_reviews_created` (`created_at`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_subscriptions_shop` (`gold_shop_id`,`id`),
  ADD KEY `idx_subscriptions_plan` (`plan_id`),
  ADD KEY `idx_subscriptions_expiry` (`subscription_status`,`end_date`),
  ADD KEY `fk_subscriptions_created_by` (`created_by`),
  ADD KEY `fk_subscriptions_updated_by` (`updated_by`);

--
-- Indexes for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_subscription_plans_name` (`plan_name`),
  ADD UNIQUE KEY `uq_subscription_plans_uuid` (`plan_uuid`),
  ADD UNIQUE KEY `uq_subscription_plans_code` (`plan_code`),
  ADD KEY `fk_subscription_plans_created_by` (`created_by`),
  ADD KEY `fk_subscription_plans_updated_by` (`updated_by`);

--
-- Indexes for table `subscription_plan_history`
--
ALTER TABLE `subscription_plan_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_subscription_plan_history_plan` (`plan_id`),
  ADD KEY `fk_subscription_plan_history_changed_by` (`changed_by`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_user_id` (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `uq_users_gold_shop_id` (`gold_shop_id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_videos_active_created` (`active`,`created_at`),
  ADD KEY `idx_videos_created_at` (`created_at`);

--
-- Indexes for table `wishlist_items`
--
ALTER TABLE `wishlist_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_wishlist_user_product` (`user_id`,`product_id`),
  ADD KEY `fk_wishlist_product` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `billings`
--
ALTER TABLE `billings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `billing_payments`
--
ALTER TABLE `billing_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `dealers`
--
ALTER TABLE `dealers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_audit_log`
--
ALTER TABLE `dealer_audit_log`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_categories`
--
ALTER TABLE `dealer_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=233;

--
-- AUTO_INCREMENT for table `dealer_documents`
--
ALTER TABLE `dealer_documents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_financial_ledger`
--
ALTER TABLE `dealer_financial_ledger`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_jobs`
--
ALTER TABLE `dealer_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_job_issues`
--
ALTER TABLE `dealer_job_issues`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_job_receipts`
--
ALTER TABLE `dealer_job_receipts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_job_reconciliations`
--
ALTER TABLE `dealer_job_reconciliations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_metal_ledger`
--
ALTER TABLE `dealer_metal_ledger`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_old_gold_receipts`
--
ALTER TABLE `dealer_old_gold_receipts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_payments`
--
ALTER TABLE `dealer_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_payment_allocations`
--
ALTER TABLE `dealer_payment_allocations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_payment_reversals`
--
ALTER TABLE `dealer_payment_reversals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_purchases`
--
ALTER TABLE `dealer_purchases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_purchase_lines`
--
ALTER TABLE `dealer_purchase_lines`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealer_refining_receipts`
--
ALTER TABLE `dealer_refining_receipts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `enquiries`
--
ALTER TABLE `enquiries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fund_accounts`
--
ALTER TABLE `fund_accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fund_transactions`
--
ALTER TABLE `fund_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gold_rates`
--
ALTER TABLE `gold_rates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `gold_rate_history`
--
ALTER TABLE `gold_rate_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `gold_shops`
--
ALTER TABLE `gold_shops`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `gold_shop_activity_logs`
--
ALTER TABLE `gold_shop_activity_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `gold_shop_documents`
--
ALTER TABLE `gold_shop_documents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `interest_types`
--
ALTER TABLE `interest_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=291;

--
-- AUTO_INCREMENT for table `loans`
--
ALTER TABLE `loans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loan_customers`
--
ALTER TABLE `loan_customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loan_customer_documents`
--
ALTER TABLE `loan_customer_documents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loan_gold_releases`
--
ALTER TABLE `loan_gold_releases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loan_renewals`
--
ALTER TABLE `loan_renewals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loan_review_actions`
--
ALTER TABLE `loan_review_actions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `metals`
--
ALTER TABLE `metals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product_price_history`
--
ALTER TABLE `product_price_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- AUTO_INCREMENT for table `subscription_plan_history`
--
ALTER TABLE `subscription_plan_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wishlist_items`
--
ALTER TABLE `wishlist_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `billing_payments`
--
ALTER TABLE `billing_payments`
  ADD CONSTRAINT `fk_billing_payments_account` FOREIGN KEY (`account_id`) REFERENCES `fund_accounts` (`id`),
  ADD CONSTRAINT `fk_billing_payments_bill` FOREIGN KEY (`billing_id`) REFERENCES `billings` (`id`);

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `fk_cart_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cart_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `fk_categories_created_by_user_id` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_categories_updated_by_user_id` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_categories_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `dealers`
--
ALTER TABLE `dealers`
  ADD CONSTRAINT `fk_dealers_category` FOREIGN KEY (`category_id`) REFERENCES `dealer_categories` (`id`),
  ADD CONSTRAINT `fk_dealers_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `dealer_audit_log`
--
ALTER TABLE `dealer_audit_log`
  ADD CONSTRAINT `fk_dealer_audit_dealer` FOREIGN KEY (`dealer_id`) REFERENCES `dealers` (`id`),
  ADD CONSTRAINT `fk_dealer_audit_user` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `dealer_documents`
--
ALTER TABLE `dealer_documents`
  ADD CONSTRAINT `fk_dealer_document_dealer` FOREIGN KEY (`dealer_id`) REFERENCES `dealers` (`id`),
  ADD CONSTRAINT `fk_dealer_document_user` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `dealer_financial_ledger`
--
ALTER TABLE `dealer_financial_ledger`
  ADD CONSTRAINT `fk_dealer_ledger_dealer` FOREIGN KEY (`dealer_id`) REFERENCES `dealers` (`id`),
  ADD CONSTRAINT `fk_dealer_ledger_user` FOREIGN KEY (`posted_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `dealer_jobs`
--
ALTER TABLE `dealer_jobs`
  ADD CONSTRAINT `fk_dealer_job_dealer` FOREIGN KEY (`dealer_id`) REFERENCES `dealers` (`id`),
  ADD CONSTRAINT `fk_dealer_job_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `dealer_job_issues`
--
ALTER TABLE `dealer_job_issues`
  ADD CONSTRAINT `fk_dealer_job_issue` FOREIGN KEY (`job_id`) REFERENCES `dealer_jobs` (`id`),
  ADD CONSTRAINT `fk_dealer_job_issue_user` FOREIGN KEY (`posted_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `dealer_job_receipts`
--
ALTER TABLE `dealer_job_receipts`
  ADD CONSTRAINT `fk_dealer_job_receipt` FOREIGN KEY (`job_id`) REFERENCES `dealer_jobs` (`id`),
  ADD CONSTRAINT `fk_dealer_job_receipt_user` FOREIGN KEY (`posted_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `dealer_job_reconciliations`
--
ALTER TABLE `dealer_job_reconciliations`
  ADD CONSTRAINT `fk_dealer_job_approver` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_dealer_job_reconciliation` FOREIGN KEY (`job_id`) REFERENCES `dealer_jobs` (`id`);

--
-- Constraints for table `dealer_metal_ledger`
--
ALTER TABLE `dealer_metal_ledger`
  ADD CONSTRAINT `fk_dealer_metal_dealer` FOREIGN KEY (`dealer_id`) REFERENCES `dealers` (`id`),
  ADD CONSTRAINT `fk_dealer_metal_user` FOREIGN KEY (`posted_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `dealer_old_gold_receipts`
--
ALTER TABLE `dealer_old_gold_receipts`
  ADD CONSTRAINT `fk_dealer_old_gold_dealer` FOREIGN KEY (`dealer_id`) REFERENCES `dealers` (`id`),
  ADD CONSTRAINT `fk_dealer_old_gold_user` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `dealer_payments`
--
ALTER TABLE `dealer_payments`
  ADD CONSTRAINT `fk_dealer_payment_dealer` FOREIGN KEY (`dealer_id`) REFERENCES `dealers` (`id`),
  ADD CONSTRAINT `fk_dealer_payment_user` FOREIGN KEY (`posted_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `dealer_payment_allocations`
--
ALTER TABLE `dealer_payment_allocations`
  ADD CONSTRAINT `fk_dealer_allocation_purchase` FOREIGN KEY (`purchase_id`) REFERENCES `dealer_purchases` (`id`),
  ADD CONSTRAINT `fk_dealer_payment_allocation` FOREIGN KEY (`payment_id`) REFERENCES `dealer_payments` (`id`);

--
-- Constraints for table `dealer_payment_reversals`
--
ALTER TABLE `dealer_payment_reversals`
  ADD CONSTRAINT `fk_dealer_payment_reversal_payment` FOREIGN KEY (`payment_id`) REFERENCES `dealer_payments` (`id`),
  ADD CONSTRAINT `fk_dealer_payment_reversal_user` FOREIGN KEY (`reversed_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `dealer_purchases`
--
ALTER TABLE `dealer_purchases`
  ADD CONSTRAINT `fk_dealer_purchase_dealer` FOREIGN KEY (`dealer_id`) REFERENCES `dealers` (`id`),
  ADD CONSTRAINT `fk_dealer_purchase_user` FOREIGN KEY (`posted_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `dealer_purchase_lines`
--
ALTER TABLE `dealer_purchase_lines`
  ADD CONSTRAINT `fk_dealer_purchase_line` FOREIGN KEY (`purchase_id`) REFERENCES `dealer_purchases` (`id`);

--
-- Constraints for table `dealer_refining_receipts`
--
ALTER TABLE `dealer_refining_receipts`
  ADD CONSTRAINT `fk_dealer_refining_dealer` FOREIGN KEY (`dealer_id`) REFERENCES `dealers` (`id`),
  ADD CONSTRAINT `fk_dealer_refining_old_gold` FOREIGN KEY (`old_gold_receipt_id`) REFERENCES `dealer_old_gold_receipts` (`id`),
  ADD CONSTRAINT `fk_dealer_refining_user` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `fund_transactions`
--
ALTER TABLE `fund_transactions`
  ADD CONSTRAINT `fk_fund_transactions_account` FOREIGN KEY (`account_id`) REFERENCES `fund_accounts` (`id`);

--
-- Constraints for table `gold_rates`
--
ALTER TABLE `gold_rates`
  ADD CONSTRAINT `fk_gold_rates_created_by_user_id` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_gold_rates_updated_by_user_id` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `fk_gold_rates_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `gold_rate_history`
--
ALTER TABLE `gold_rate_history`
  ADD CONSTRAINT `fk_gold_rate_history_changed_by_user_id` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `gold_shops`
--
ALTER TABLE `gold_shops`
  ADD CONSTRAINT `fk_gold_shops_created_by_user_id` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_gold_shops_owner_user` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_gold_shops_updated_by_user_id` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `gold_shop_activity_logs`
--
ALTER TABLE `gold_shop_activity_logs`
  ADD CONSTRAINT `fk_gold_shop_activity_actor` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_gold_shop_activity_shop` FOREIGN KEY (`gold_shop_id`) REFERENCES `gold_shops` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `gold_shop_documents`
--
ALTER TABLE `gold_shop_documents`
  ADD CONSTRAINT `fk_gold_shop_documents_shop` FOREIGN KEY (`gold_shop_id`) REFERENCES `gold_shops` (`id`),
  ADD CONSTRAINT `fk_gold_shop_documents_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `gold_shop_pending_credentials`
--
ALTER TABLE `gold_shop_pending_credentials`
  ADD CONSTRAINT `fk_gold_shop_pending_credentials_shop` FOREIGN KEY (`gold_shop_id`) REFERENCES `gold_shops` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `loans`
--
ALTER TABLE `loans`
  ADD CONSTRAINT `fk_loans_customer` FOREIGN KEY (`customer_id`) REFERENCES `loan_customers` (`id`);

--
-- Constraints for table `loan_customer_documents`
--
ALTER TABLE `loan_customer_documents`
  ADD CONSTRAINT `fk_loan_customer_documents_customer` FOREIGN KEY (`customer_id`) REFERENCES `loan_customers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `loan_gold_releases`
--
ALTER TABLE `loan_gold_releases`
  ADD CONSTRAINT `fk_loan_gold_releases_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`);

--
-- Constraints for table `loan_renewals`
--
ALTER TABLE `loan_renewals`
  ADD CONSTRAINT `fk_loan_renewals_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`);

--
-- Constraints for table `loan_review_actions`
--
ALTER TABLE `loan_review_actions`
  ADD CONSTRAINT `fk_loan_review_actions_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`);

--
-- Constraints for table `metals`
--
ALTER TABLE `metals`
  ADD CONSTRAINT `fk_metals_created_by_user_id` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_metals_updated_by_user_id` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `fk_payments_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_payments_shop` FOREIGN KEY (`gold_shop_id`) REFERENCES `gold_shops` (`id`),
  ADD CONSTRAINT `fk_payments_subscription` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`),
  ADD CONSTRAINT `fk_payments_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_created_by_user_id` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_products_updated_by_user_id` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD CONSTRAINT `fk_subscriptions_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_subscriptions_plan` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`),
  ADD CONSTRAINT `fk_subscriptions_shop` FOREIGN KEY (`gold_shop_id`) REFERENCES `gold_shops` (`id`),
  ADD CONSTRAINT `fk_subscriptions_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  ADD CONSTRAINT `fk_subscription_plans_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_subscription_plans_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `subscription_plan_history`
--
ALTER TABLE `subscription_plan_history`
  ADD CONSTRAINT `fk_subscription_plan_history_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_subscription_plan_history_plan` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_gold_shop` FOREIGN KEY (`gold_shop_id`) REFERENCES `gold_shops` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `wishlist_items`
--
ALTER TABLE `wishlist_items`
  ADD CONSTRAINT `fk_wishlist_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_wishlist_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
