-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 24, 2026 at 12:20 AM
-- Server version: 10.11.19-MariaDB-cll-lve
-- PHP Version: 8.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `life_tracking_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_lock_challenges`
--

CREATE TABLE `app_lock_challenges` (
  `purpose` varchar(20) NOT NULL,
  `challenge` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `user_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `app_lock_sessions`
--

CREATE TABLE `app_lock_sessions` (
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `app_lock_settings`
--

CREATE TABLE `app_lock_settings` (
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `method` varchar(20) NOT NULL DEFAULT 'pin',
  `credential_hash` varchar(255) DEFAULT NULL,
  `lock_on_hidden` tinyint(1) NOT NULL DEFAULT 1,
  `idle_timeout_minutes` smallint(6) NOT NULL DEFAULT 5,
  `biometric_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `webauthn_credential_id` varchar(512) DEFAULT NULL,
  `webauthn_public_key` text DEFAULT NULL,
  `webauthn_counter` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `webauthn_transports` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`webauthn_transports`)),
  `failed_attempts` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `app_lock_settings`
--

INSERT INTO `app_lock_settings` (`enabled`, `method`, `credential_hash`, `lock_on_hidden`, `idle_timeout_minutes`, `biometric_enabled`, `webauthn_credential_id`, `webauthn_public_key`, `webauthn_counter`, `webauthn_transports`, `failed_attempts`, `locked_until`, `updated_at`, `user_id`) VALUES
(0, 'password', '$2b$12$TEKqkJhbSmanfBkwOhTuKuHPnK5Ero70D4axYRIGWeKXvYVeukvbq', 1, 5, 0, NULL, NULL, 0, NULL, 0, NULL, '2026-11-11 10:00:07', 'USR4PO31VQFU');

-- --------------------------------------------------------

--
-- Table structure for table `calendar_events`
--

CREATE TABLE `calendar_events` (
  `id` varchar(64) NOT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `all_day` tinyint(1) DEFAULT 0,
  `location` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `priority` varchar(20) DEFAULT 'Medium',
  `color` varchar(30) DEFAULT '#7C3AED',
  `reminder` varchar(80) DEFAULT '15 minutes before',
  `repeat_option` varchar(20) DEFAULT 'None',
  `attachment` varchar(500) DEFAULT NULL,
  `status` varchar(30) DEFAULT 'Upcoming',
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `calendar_events`
--

INSERT INTO `calendar_events` (`id`, `user_id`, `title`, `category`, `start_date`, `start_time`, `end_date`, `end_time`, `all_day`, `location`, `description`, `priority`, `color`, `reminder`, `repeat_option`, `attachment`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
('evt_08544896', 'USR4PO31VQFU', 'Good', '💳 Payment', '2026-10-09', '09:00:00', '2026-10-09', NULL, 0, 'Ambur', '', 'Medium', '#7C3AED', '15 minutes before', 'Weekly', '', 'Upcoming', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 06:37:02', '2026-10-09 06:37:02'),
('evt_44db75e4', 'USR4PO31VQFU', 'New', 'Personal', '2026-10-07', '21:00:00', '2026-10-07', NULL, 0, '', '', 'Medium', '#7C3AED', '15 minutes before', 'None', '', 'Upcoming', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 13:00:35', '2026-10-06 13:00:35'),
('evt_62a70435', 'USR4PO31VQFU', 'fgjfjfjf', '💊 Medicine', '2026-10-09', '09:00:00', '2026-10-09', '10:00:00', 0, 'gfjgjgf', 'gfjg', 'Medium', '#A50000', '15 minutes before', 'None', '', 'Upcoming', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 06:37:42', '2026-10-09 06:37:42'),
('evt_84218a3c', 'USR4PO31VQFU', 'Birthday Deva', '🎂 Birthday', '2026-09-08', '09:00:00', '2026-09-08', '10:00:00', 1, '', '', 'High', '#8B5CF6', '15 minutes before', 'Yearly', '', 'Upcoming', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-28 10:48:28', '2026-09-28 10:48:28'),
('evt_85b7ce47', 'USR4PO31VQFU', 'Good morning', '💍 Anniversary', '2026-11-11', '09:00:00', '2026-11-11', NULL, 0, '', '', 'Medium', '#7C3AED', '15 minutes before', 'Daily', '', 'Upcoming', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-11 11:53:58', '2026-11-11 11:54:21'),
('evt_8ff80aae', 'USR4PO31VQFU', 'tttttt', '💼 Work', '2026-10-11', '09:00:00', '2026-10-11', '10:00:00', 0, 'fgs', 'rtrt', 'Medium', '#A50000', '15 minutes before', 'None', '', 'Upcoming', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 06:52:36', '2026-10-09 06:52:36'),
('evt_b35ccbac', 'USR4PO31VQFU', 'Gdhdhhs', 'Personal', '2026-10-06', '09:00:00', '2026-10-06', NULL, 0, '', 'Xhxbbxb', 'Medium', '#7C3AED', '15 minutes before', 'None', '', 'Upcoming', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 12:58:24', '2026-10-06 12:58:24'),
('evt_bab1e5be', 'USR4PO31VQFU', 'Djdhxbxb', 'Personal', '2026-10-06', '21:00:00', '2026-10-06', NULL, 0, '', 'Dhdhdbxb', 'High', '#7C3AED', '15 minutes before', 'None', '', 'Upcoming', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 12:59:13', '2026-10-06 12:59:13'),
('evt_c523d2eb', 'USR4PO31VQFU', 'ADS', 'Personal', '2026-10-23', '10:00:00', '2026-10-23', '10:00:00', 0, 'Ambur', '', 'Medium', '#A50000', '15 minutes before', 'Daily', '', 'Upcoming', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 07:13:24', '2026-10-09 07:13:24'),
('evt_c872fc5d', 'USR4PO31VQFU', 'Thbv', 'Personal', '2026-09-29', '09:00:00', '2026-09-29', NULL, 0, '', '', 'High', '#7C3AED', '15 minutes before', 'None', '', 'Upcoming', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-29 10:35:53', '2026-09-29 10:35:53'),
('evt_e709a9ab', 'USR4PO31VQFU', 'tyutrutr', '💼 Work', '2026-10-10', '09:00:00', '2026-10-10', '10:00:00', 0, 'Mdgsdg', 'cfhdhd', 'Medium', '#A50000', '15 minutes before', 'None', '', 'Upcoming', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 06:52:05', '2026-10-09 06:52:05');

-- --------------------------------------------------------

--
-- Table structure for table `calendar_reminders`
--

CREATE TABLE `calendar_reminders` (
  `id` varchar(64) NOT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `reminder_date` date NOT NULL,
  `reminder_time` time DEFAULT NULL,
  `priority` varchar(20) DEFAULT 'Medium',
  `notes` text DEFAULT NULL,
  `related_event` varchar(64) DEFAULT NULL,
  `notification_enabled` tinyint(1) DEFAULT 1,
  `repeat_option` varchar(20) DEFAULT 'None',
  `status` varchar(30) DEFAULT 'Pending',
  `completed_at` timestamp NULL DEFAULT NULL,
  `snoozed_at` timestamp NULL DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `catId` varchar(50) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Active',
  `catType` varchar(50) DEFAULT 'Expensive',
  `subcategory` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`subcategory`)),
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `user_id`, `catId`, `name`, `description`, `status`, `catType`, `subcategory`, `images`, `created_at`, `created_by`, `updated_by`, `updated_at`) VALUES
(2, 'USR4PO31VQFU', 'CAT001', '🍔 Food', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:22:29', NULL, NULL, '2026-09-25 17:22:29'),
(3, 'USR4PO31VQFU', 'CAT002', '🛒 Grocery', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:22:43', NULL, NULL, '2026-09-25 17:22:43'),
(4, 'USR4PO31VQFU', 'CAT055', '🚗Travel ', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:22:55', NULL, NULL, '2026-09-30 05:23:18'),
(5, 'USR4PO31VQFU', 'CAT004', '⛽ Fuel', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:23:06', NULL, NULL, '2026-09-25 17:23:06'),
(6, 'USR4PO31VQFU', 'CAT005', '💡 Bills & Utilities', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:23:18', NULL, NULL, '2026-09-25 17:23:18'),
(7, 'USR4PO31VQFU', 'CAT006', '🛍️ Shopping', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:23:30', NULL, NULL, '2026-09-25 17:23:30'),
(8, 'USR4PO31VQFU', 'CAT007', '💊 Health', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:23:50', NULL, NULL, '2026-09-25 17:23:50'),
(9, 'USR4PO31VQFU', 'CAT008', '📱 Recharge', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:24:07', NULL, NULL, '2026-09-25 17:24:07'),
(10, 'USR4PO31VQFU', 'CAT009', '💳 Transfer', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:24:18', NULL, NULL, '2026-09-25 17:24:18'),
(11, 'USR4PO31VQFU', 'CAT010', '🎬 Entertainment', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:24:37', NULL, NULL, '2026-09-25 17:24:37'),
(12, 'USR4PO31VQFU', 'CAT011', '👕 Clothing', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:24:47', NULL, NULL, '2026-09-25 17:24:47'),
(13, 'USR4PO31VQFU', 'CAT012', '📦 Other', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:25:04', NULL, NULL, '2026-09-25 17:25:04'),
(14, 'USR4PO31VQFU', 'CAT013', '🎁 Gifts', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:25:45', NULL, NULL, '2026-09-25 17:25:45'),
(15, 'USR4PO31VQFU', 'CAT014', '💼 Salary', '', 'Active', 'Income', '[]', '[]', '2026-09-25 17:26:10', NULL, NULL, '2026-09-25 17:26:10'),
(16, 'USR4PO31VQFU', 'CAT015', '💵 Other Income', '', 'Active', 'Income', '[]', '[]', '2026-09-25 17:26:32', NULL, NULL, '2026-09-25 17:26:32'),
(17, 'USR4PO31VQFU', 'CAT016', '🔄 Refund', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:26:54', NULL, NULL, '2026-09-25 17:26:54'),
(18, 'USR4PO31VQFU', 'CAT017', '📝 Daily Life', '', 'Active', 'Diary', '[]', '[]', '2026-09-25 17:27:31', NULL, NULL, '2026-09-25 17:27:31'),
(19, 'USR4PO31VQFU', 'CAT018', '❤️ Love', '', 'Active', 'Diary', '[]', '[]', '2026-09-25 17:27:50', NULL, NULL, '2026-09-25 17:27:50'),
(20, 'USR4PO31VQFU', 'CAT019', '👨‍👩‍👧 Family', '', 'Active', 'Diary', '[]', '[]', '2026-09-25 17:28:05', NULL, NULL, '2026-09-25 17:28:05'),
(21, 'USR4PO31VQFU', 'CAT020', '👥 Friends', '', 'Active', 'Diary', '[]', '[]', '2026-09-25 17:28:22', NULL, NULL, '2026-09-25 17:28:22'),
(22, 'USR4PO31VQFU', 'CAT021', '💼 Work', '', 'Active', 'Diary', '[]', '[]', '2026-09-25 17:28:53', NULL, NULL, '2026-09-25 17:28:53'),
(23, 'USR4PO31VQFU', 'CAT022', '✈️ Travel', '', 'Active', 'Diary', '[]', '[]', '2026-09-25 17:29:07', NULL, NULL, '2026-09-25 17:29:07'),
(24, 'USR4PO31VQFU', 'CAT023', '😊 Happy', '', 'Active', 'Diary', '[]', '[]', '2026-09-25 17:29:42', NULL, NULL, '2026-09-25 17:29:42'),
(25, 'USR4PO31VQFU', 'CAT024', '😔 Sad', '', 'Active', 'Diary', '[]', '[]', '2026-09-25 17:29:56', NULL, NULL, '2026-09-25 17:29:56'),
(26, 'USR4PO31VQFU', 'CAT025', '👨‍👩‍👧 Family', '', 'Active', 'Memories', '[]', '[]', '2026-09-25 17:30:26', NULL, NULL, '2026-09-25 17:30:26'),
(27, 'USR4PO31VQFU', 'CAT026', '❤️ Special Moments', '', 'Active', 'Memories', '[]', '[]', '2026-09-25 17:30:42', NULL, NULL, '2026-09-25 17:30:42'),
(28, 'USR4PO31VQFU', 'CAT027', '🎂 Birthday', '', 'Active', 'Memories', '[]', '[]', '2026-09-25 17:31:05', NULL, NULL, '2026-09-25 17:31:05'),
(29, 'USR4PO31VQFU', 'CAT028', '💍 Wedding', '', 'Active', 'Memories', '[]', '[]', '2026-09-25 17:31:47', NULL, NULL, '2026-09-25 17:31:47'),
(30, 'USR4PO31VQFU', 'CAT029', '✈️ Travel', '', 'Active', 'Memories', '[]', '[]', '2026-09-25 17:32:06', NULL, NULL, '2026-09-25 17:32:06'),
(31, 'USR4PO31VQFU', 'CAT030', '🎉 Celebration', '', 'Active', 'Memories', '[]', '[]', '2026-09-25 17:32:22', NULL, NULL, '2026-09-25 17:32:22'),
(32, 'USR4PO31VQFU', 'CAT031', '👥 Friends', '', 'Active', 'Memories', '[]', '[]', '2026-09-25 17:32:42', NULL, NULL, '2026-09-25 17:32:42'),
(33, 'USR4PO31VQFU', 'CAT032', '📸 Photos', '', 'Active', 'Memories', '[]', '[]', '2026-09-25 17:32:58', NULL, NULL, '2026-09-25 17:32:58'),
(34, 'USR4PO31VQFU', 'CAT033', '🌅 Other', '', 'Active', 'Memories', '[]', '[]', '2026-09-25 17:33:12', NULL, NULL, '2026-09-25 17:33:12'),
(35, 'USR4PO31VQFU', 'CAT034', '📅 Event', '', 'Active', 'CalendarEvent', '[]', '[]', '2026-09-25 17:33:52', NULL, NULL, '2026-09-25 17:33:52'),
(36, 'USR4PO31VQFU', 'CAT035', '⏰ Reminder', '', 'Active', 'CalendarEvent', '[]', '[]', '2026-09-25 17:34:06', NULL, NULL, '2026-09-25 17:34:06'),
(37, 'USR4PO31VQFU', 'CAT036', '🎂 Birthday', '', 'Active', 'CalendarEvent', '[]', '[]', '2026-09-25 17:34:20', NULL, NULL, '2026-09-25 17:34:20'),
(38, 'USR4PO31VQFU', 'CAT037', '💍 Anniversary', '', 'Active', 'CalendarEvent', '[]', '[]', '2026-09-25 17:34:36', NULL, NULL, '2026-09-25 17:34:36'),
(39, 'USR4PO31VQFU', 'CAT038', '💊 Medicine', '', 'Active', 'CalendarEvent', '[]', '[]', '2026-09-25 17:34:49', NULL, NULL, '2026-09-25 17:34:49'),
(40, 'USR4PO31VQFU', 'CAT041', '💳 Payment', '', 'Active', 'CalendarEvent', '[]', '[]', '2026-09-25 17:35:02', NULL, NULL, '2026-09-25 17:35:27'),
(41, 'USR4PO31VQFU', 'CAT040', '💼 Work', '', 'Active', 'CalendarEvent', '[]', '[]', '2026-09-25 17:35:18', NULL, NULL, '2026-09-25 17:35:18'),
(42, 'USR4PO31VQFU', 'CAT042', '💳 EMI / Loan', '', 'Active', 'Expensive', '[]', '[]', '2026-09-25 17:36:27', NULL, NULL, '2026-09-25 17:36:27'),
(43, 'USR4PO31VQFU', 'CAT043', '📱 Mobile Recharge', '', 'Active', 'Transfer', '[]', '[]', '2026-09-25 17:39:23', NULL, NULL, '2026-09-25 17:39:23'),
(44, 'USR4PO31VQFU', 'CAT044', '💳 EMI / Loan', '', 'Active', 'Transfer', '[]', '[]', '2026-09-25 17:39:38', NULL, NULL, '2026-09-25 17:39:38'),
(45, 'USR4PO31VQFU', 'CAT045', '🛒 Groceries', '', 'Active', 'Transfer', '[]', '[]', '2026-09-25 17:39:58', NULL, NULL, '2026-09-25 17:39:58'),
(46, 'USR4PO31VQFU', 'CAT046', '💰 Savings', '', 'Active', 'Transfer', '[]', '[]', '2026-09-25 17:40:15', NULL, NULL, '2026-09-25 17:40:15'),
(47, 'USR4PO31VQFU', 'CAT047', '⛽ Fuel', '', 'Active', 'Transfer', '[]', '[]', '2026-09-25 17:40:51', NULL, NULL, '2026-09-25 17:40:51'),
(48, 'USR4PO31VQFU', 'CAT048', '🍔 Food / Dining', '', 'Active', 'Transfer', '[]', '[]', '2026-09-25 17:41:14', NULL, NULL, '2026-09-25 17:41:14'),
(49, 'USR4PO31VQFU', 'CAT049', '🚌 Travel', '', 'Active', 'Transfer', '[]', '[]', '2026-09-25 17:41:41', NULL, NULL, '2026-09-25 17:41:41'),
(50, 'USR4PO31VQFU', 'CAT050', '👨‍👩‍👧 Family Expenses', '', 'Active', 'Transfer', '[]', '[]', '2026-09-25 17:42:04', NULL, NULL, '2026-09-25 17:42:04'),
(51, 'USR4PO31VQFU', 'CAT051', '💵 Other Expenses', '', 'Active', 'Transfer', '[]', '[]', '2026-09-25 17:42:25', NULL, NULL, '2026-09-25 17:42:25'),
(52, 'USR4PO31VQFU', 'CAT052', '💰 Savings', '', 'Active', 'Transfer', '[]', '[]', '2026-09-28 05:59:13', NULL, NULL, '2026-09-28 05:59:13'),
(54, 'USR4PO31VQFU', 'CAT056', '🏍️ Bike Parking', '', 'Active', 'Expensive', '[]', '[]', '2026-10-02 07:46:05', NULL, NULL, '2026-11-04 05:35:24'),
(56, 'USR4PO31VQFU', 'CAT057', '📈 Investment Chit', '', 'Active', 'Expensive', '[]', '[]', '2026-11-09 04:38:22', NULL, NULL, '2026-11-09 04:38:22'),
(57, 'USR4PO31VQFU', 'CAT058', '📈 Investment Chit', '', 'Active', 'Transfer', '[]', '[]', '2026-11-09 04:38:33', NULL, NULL, '2026-11-09 04:38:33'),
(58, 'USR4PO31VQFU', 'CAT059', '🏍️ Bike Parking', '', 'Active', 'Transfer', '[]', '[]', '2026-11-09 04:44:29', NULL, NULL, '2026-11-09 04:44:29');

-- --------------------------------------------------------

--
-- Table structure for table `diary_entries`
--

CREATE TABLE `diary_entries` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `category_name` varchar(120) DEFAULT NULL,
  `mood` varchar(50) DEFAULT 'Normal',
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags`)),
  `location` varchar(255) DEFAULT NULL,
  `entry_date` date NOT NULL,
  `entry_time` time DEFAULT NULL,
  `status` enum('published','draft') DEFAULT 'published',
  `is_favorite` tinyint(1) DEFAULT 0,
  `is_private` tinyint(1) DEFAULT 0,
  `is_locked` tinyint(1) DEFAULT 0,
  `image_path` varchar(500) DEFAULT NULL,
  `video_path` varchar(500) DEFAULT NULL,
  `audio_path` varchar(500) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `media_files` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`media_files`)),
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diary_entries`
--

INSERT INTO `diary_entries` (`id`, `user_id`, `title`, `content`, `category_id`, `category_name`, `mood`, `tags`, `location`, `entry_date`, `entry_time`, `status`, `is_favorite`, `is_private`, `is_locked`, `image_path`, `video_path`, `audio_path`, `file_path`, `media_files`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'USR4PO31VQFU', 'Good', 'fjgfjygupg', 24, NULL, 'Happy', '[]', NULL, '2026-09-28', '16:10:00', 'published', 0, 0, 0, 'https://lifetracking.qtechx.com/uploads/diary/images/1790592032995-1788938874592.jpg', NULL, NULL, NULL, '[{\"id\":1790592031867,\"file_name\":\"1788915076850.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1790592031863-1788915076850.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":201071},{\"id\":1790592032071,\"file_name\":\"1788915076850.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1790592032068-1788915076850.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":201071},{\"id\":1790592032682,\"file_name\":\"1788914832577.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1790592032674-1788914832577.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":316486},{\"id\":1790592032792,\"file_name\":\"1788938726725.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1790592032786-1788938726725.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":311004},{\"id\":1790592032801,\"file_name\":\"1788914832577.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1790592032794-1788914832577.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":316486},{\"id\":1790592032898,\"file_name\":\"1788938874592.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1790592032893-1788938874592.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":324375},{\"id\":1790592032999,\"file_name\":\"1788938874592.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1790592032995-1788938874592.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":324375}]', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-28 10:40:29', '2026-09-28 10:40:32'),
(2, 'USR4PO31VQFU', 'New', 'hfdhffdgfdg', 24, NULL, 'Happy', '[\"dsfsd\"]', '', '2026-09-29', '12:34:00', 'published', 0, 0, 0, 'https://lifetracking.qtechx.com/uploads/diary/images/1790665518928-ChatGPT_Image_Sep_28__2026__10_34_05_AM.png', 'https://lifetracking.qtechx.com/uploads/diary/videos/1790665537882-Puthusa_____.mp4', NULL, 'https://lifetracking.qtechx.com/uploads/diary/files/1790665626282-ChatGPT_Image_Sep_23__2026__04_08_14_PM.zip', '[{\"id\":1790665518947,\"file_name\":\"ChatGPT Image Sep 28, 2026, 10_34_05 AM.png\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1790665518928-ChatGPT_Image_Sep_28__2026__10_34_05_AM.png\",\"file_type\":\"image/png\",\"file_size\":1967874},{\"id\":1790665537916,\"file_name\":\"Puthusa ð.mp4\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/videos/1790665537882-Puthusa_____.mp4\",\"file_type\":\"video/mp4\",\"file_size\":3493759},{\"id\":1790665538289,\"file_name\":\"voice-note-1790665489046.webm\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/videos/1790665538287-voice-note-1790665489046.webm\",\"file_type\":\"video/webm\",\"file_size\":20268},{\"id\":1790665626411,\"file_name\":\"ChatGPT Image Sep 23, 2026, 04_08_14 PM.zip\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/files/1790665626282-ChatGPT_Image_Sep_23__2026__04_08_14_PM.zip\",\"file_type\":\"application/zip\",\"file_size\":16366710},{\"id\":1790665645237,\"file_name\":\"Puthusa ð.zip\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/files/1790665645219-Puthusa_____.zip\",\"file_type\":\"application/zip\",\"file_size\":3486134}]', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-29 07:05:07', '2026-09-29 07:08:34'),
(3, 'USR4PO31VQFU', 'Good', 'Hdhdhdhdh', 24, NULL, 'Happy', '[]', 'Djdjdj', '2026-10-21', '16:59:00', 'published', 0, 0, 0, 'https://lifetracking.qtechx.com/uploads/diary/images/1790854127435-Screenshot_20260929_165153.jpg', NULL, 'https://lifetracking.qtechx.com/uploads/diary/audio/1790854128102-voice-note-1790854119192.m4a', NULL, '[{\"id\":1790854127441,\"file_name\":\"Screenshot_20260929_165153.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1790854127435-Screenshot_20260929_165153.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":379047},{\"id\":1790854128105,\"file_name\":\"voice-note-1790854119192.m4a\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/audio/1790854128102-voice-note-1790854119192.m4a\",\"file_type\":\"audio/mp4\",\"file_size\":28687}]', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-01 11:28:43', '2026-10-06 12:17:43'),
(4, 'USR4PO31VQFU', 'Goodxbnxnxnxbxnzhxh', 'Hdxbxbxbxbxbxb', NULL, NULL, 'Happy', '[\"Dbxhxbxbxbxbxb b\"]', 'Xjxbxb', '2026-10-05', '10:55:00', 'published', 0, 0, 0, NULL, NULL, NULL, NULL, '[]', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-04 05:24:33', '2026-10-04 05:24:33'),
(5, 'USR4PO31VQFU', 'Ghghnn', 'Hjjghh', 25, NULL, 'Happy', '[]', 'Hhjj', '2026-10-06', '17:44:00', 'published', 0, 0, 0, NULL, NULL, 'https://lifetracking.qtechx.com/uploads/diary/audio/1791288871762-voice-note-1791288865757.m4a', NULL, '[{\"id\":1791288871765,\"file_name\":\"voice-note-1791288865757.m4a\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/audio/1791288871762-voice-note-1791288865757.m4a\",\"file_type\":\"audio/mp4\",\"file_size\":35697}]', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 12:14:30', '2026-10-06 12:14:31'),
(6, 'USR4PO31VQFU', 'As', 'Bsbzbxbx', 25, NULL, 'Happy', '[]', NULL, '2026-10-06', '17:51:00', 'published', 0, 0, 0, NULL, NULL, NULL, NULL, '[]', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 12:21:12', '2026-10-06 12:21:12'),
(7, 'USR4PO31VQFU', 'Good', 'Ffhghvbnnn', 24, NULL, 'Happy', '[]', 'Ffghh', '2026-10-09', '14:46:00', 'published', 0, 0, 0, 'https://lifetracking.qtechx.com/uploads/diary/images/1791537452662-Screenshot_2026-10-09-09-06-57-484_com_instagram_android.jpg', NULL, NULL, NULL, '[{\"id\":1791537444119,\"file_name\":\"Screenshot_2026-10-09-14-46-21-362_com.anonymous.lifeledger.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1791537444112-Screenshot_2026-10-09-14-46-21-362_com_anonymous_lifeledger.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":237419},{\"id\":1791537446061,\"file_name\":\"Screenshot_2026-10-09-12-13-31-926_host.exp.exponent.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1791537446057-Screenshot_2026-10-09-12-13-31-926_host_exp_exponent.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":200723},{\"id\":1791537447956,\"file_name\":\"Screenshot_2026-10-09-12-02-50-804_host.exp.exponent.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1791537447953-Screenshot_2026-10-09-12-02-50-804_host_exp_exponent.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":198537},{\"id\":1791537452666,\"file_name\":\"Screenshot_2026-10-09-09-06-57-484_com.instagram.android.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1791537452662-Screenshot_2026-10-09-09-06-57-484_com_instagram_android.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":549936}]', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 09:17:21', '2026-10-09 09:17:32'),
(12, 'USR4PO31VQFU', 'Good My', 'Good news ', 25, NULL, 'Happy', '[]', 'Tirupathur ', '2026-10-13', '18:22:00', 'published', 0, 0, 0, NULL, NULL, NULL, NULL, '[]', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-13 12:54:55', '2026-10-13 12:54:55'),
(13, 'USR4PO31VQFU', 'Ftvyvyofoogyg', 'Kycicruxurruxtxr', 23, NULL, 'Happy', '[]', 'Cghgh', '2026-10-23', '12:50:00', 'published', 0, 0, 0, 'https://lifetracking.qtechx.com/uploads/diary/images/1792740099139-IMG-20261019-WA0006.jpg', 'https://lifetracking.qtechx.com/uploads/diary/videos/1792740098466-VID-20261019-WA0003.mp4', 'https://lifetracking.qtechx.com/uploads/diary/audio/1792740089768-voice-note-1792740058573.m4a', NULL, '[{\"id\":1792740089771,\"file_name\":\"voice-note-1792740058573.m4a\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/audio/1792740089768-voice-note-1792740058573.m4a\",\"file_type\":\"audio/mp4\",\"file_size\":34932},{\"id\":1792740091959,\"file_name\":\"Screenshot_2026-10-23-12-43-49-157_host.exp.exponent.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1792740091955-Screenshot_2026-10-23-12-43-49-157_host_exp_exponent.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":169324},{\"id\":1792740092665,\"file_name\":\"IMG-20261019-WA0002.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1792740092662-IMG-20261019-WA0002.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":53296},{\"id\":1792740098477,\"file_name\":\"VID-20261019-WA0003.mp4\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/videos/1792740098466-VID-20261019-WA0003.mp4\",\"file_type\":\"video/mp4\",\"file_size\":715011},{\"id\":1792740099148,\"file_name\":\"IMG-20261019-WA0006.jpg\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1792740099139-IMG-20261019-WA0006.jpg\",\"file_type\":\"image/jpeg\",\"file_size\":52965}]', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-23 07:21:27', '2026-10-23 07:21:39'),
(14, 'USR4PO31VQFU', 'Datas', 'fdhfdhfdhfdhfdhfdhdfhfxc', 25, NULL, 'Happy', '[]', NULL, '2026-11-24', '13:44:00', 'published', 0, 0, 0, 'https://lifetracking.qtechx.com/uploads/diary/images/1795504620322-Next-Level_Gym_Digital_Solution.png', NULL, NULL, NULL, '[{\"id\":1795504576220,\"file_name\":\"QTechX Gym Digital Transformation Poster.png\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1795504576180-QTechX_Gym_Digital_Transformation_Poster.png\",\"file_type\":\"image/png\",\"file_size\":1907552},{\"id\":1795504586972,\"file_name\":\"QTechX Gym Digital Solutions Poster.png\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1795504586951-QTechX_Gym_Digital_Solutions_Poster.png\",\"file_type\":\"image/png\",\"file_size\":1986457},{\"id\":1795504598842,\"file_name\":\"Kaviâs Dry Fruits Go Digital.png\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1795504598830-Kavi___s_Dry_Fruits_Go_Digital.png\",\"file_type\":\"image/png\",\"file_size\":2143088},{\"id\":1795504610058,\"file_name\":\"KAVIâS Dry Fruits Digital Solution.png\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1795504610040-KAVI___S_Dry_Fruits_Digital_Solution.png\",\"file_type\":\"image/png\",\"file_size\":1930284},{\"id\":1795504620350,\"file_name\":\"Next-Level Gym Digital Solution.png\",\"file_url\":\"https://lifetracking.qtechx.com/uploads/diary/images/1795504620322-Next-Level_Gym_Digital_Solution.png\",\"file_type\":\"image/png\",\"file_size\":1888896}]', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-24 07:16:04', '2026-11-24 07:17:00');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `expense_amount` decimal(12,2) NOT NULL,
  `transfer_amount` decimal(12,2) DEFAULT NULL,
  `transfer_id` int(11) DEFAULT NULL,
  `remaining_amount` decimal(12,2) DEFAULT NULL,
  `category` varchar(100) NOT NULL,
  `payment_method` varchar(100) DEFAULT 'Cash',
  `expense_date` date NOT NULL,
  `expense_time` time DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `recurring` enum('Yes','No') NOT NULL DEFAULT 'No',
  `attachment` text DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `from` varchar(255) DEFAULT NULL,
  `to` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `travel_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `user_id`, `title`, `expense_amount`, `transfer_amount`, `transfer_id`, `remaining_amount`, `category`, `payment_method`, `expense_date`, `expense_time`, `notes`, `recurring`, `attachment`, `created_by`, `updated_by`, `created_at`, `updated_at`, `from`, `to`, `location`, `travel_time`) VALUES
(9, 'USR4PO31VQFU', 'Bike Parking', 20.00, 500.00, 7, 480.00, '🏍️ Bike Parking ', 'Cash', '2026-10-01', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-01 07:47:25', '2026-10-01 08:03:00', '', '', 'Ambur', NULL),
(10, 'USR4PO31VQFU', 'VDM Bus', 30.00, 1700.00, 5, 1670.00, '🚗Travel ', 'Cash', '2026-10-01', '08:21:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-01 07:52:52', '2026-10-01 07:52:52', 'Ambur', 'Tirupathur', NULL, NULL),
(11, 'USR4PO31VQFU', 'JMS Bus', 10.00, 1670.00, 5, 1660.00, '🚗Travel ', 'Cash', '2026-10-01', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-01 07:54:20', '2026-10-01 07:54:20', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(13, 'USR4PO31VQFU', 'Poori 2 One Plate', 30.00, 500.00, 4, 470.00, '🍔 Food', 'Cash', '2026-10-01', '09:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-01 08:02:43', '2026-10-01 08:02:43', NULL, NULL, 'Vengateshware Nagar', NULL),
(14, 'USR4PO31VQFU', 'VDM Bus', 30.00, 1660.00, 5, 1630.00, '🚗Travel ', 'Cash', '2026-10-01', '18:33:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-01 08:04:17', '2026-10-01 08:04:17', 'Tirupattur', 'Ambur', NULL, NULL),
(15, 'USR4PO31VQFU', 'Bike Parking', 20.00, 480.00, 7, 460.00, '🏍️ Bike Parking ', 'Cash', '2026-10-02', '07:40:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-02 08:09:03', '2026-10-02 08:09:03', NULL, NULL, 'Ambur', NULL),
(16, 'USR4PO31VQFU', 'VDM Bus', 30.00, 1630.00, 5, 1600.00, '🚗Travel ', 'Cash', '2026-10-02', '08:25:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-02 08:09:56', '2026-10-02 08:09:56', 'Ambur', 'Tirupathur', NULL, NULL),
(17, 'USR4PO31VQFU', 'Ravi Bus', 10.00, 1600.00, 5, 1590.00, '🚗Travel ', 'Cash', '2026-10-02', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-02 08:10:52', '2026-10-02 08:10:52', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(18, 'USR4PO31VQFU', 'Dhosai 2 One Plate', 30.00, 470.00, 4, 440.00, '🍔 Food', 'Cash', '2026-10-02', '08:52:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-02 08:11:49', '2026-10-02 08:11:49', NULL, NULL, 'Tirupattur', NULL),
(19, 'USR4PO31VQFU', 'Petrole', 220.00, 1350.00, 6, 1130.00, '⛽ Fuel', 'UPI', '2026-10-01', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-01 08:15:11', '2026-10-01 08:15:11', NULL, NULL, 'Ambur', NULL),
(20, 'USR4PO31VQFU', 'Cooked Food Items', 40.00, 200.00, 20, 160.00, '🛍️ Shopping', 'Cash', '2026-10-02', '06:10:00', 'Macaroni ,\r\nInji Paste ,\r\nKarpuram ,\r\nThakkali (Tomato) ,', 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-02 08:21:06', '2026-10-02 08:21:06', NULL, NULL, 'Sollaikkolaimedu', NULL),
(21, 'USR4PO31VQFU', 'Government Bus', 36.00, 1590.00, 5, 1554.00, '🚗Travel ', 'Cash', '2026-10-02', '18:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-02 13:06:54', '2026-10-02 13:06:54', 'Tirupathur', 'Ambur', NULL, NULL),
(22, 'USR4PO31VQFU', 'Parking Ticket', 20.00, 160.00, 20, 140.00, '💡 Bills & Utilities', 'Cash', '2026-10-03', '15:06:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-03 09:37:39', '2026-10-03 09:38:39', '', '', 'Kavalur', NULL),
(23, 'USR4PO31VQFU', 'Vainu Bappu Observatory Entry  Ticket', 100.00, 140.00, 20, 40.00, '🎬 Entertainment', 'Cash', '2026-10-03', '15:08:00', 'Visited Vainu Bappu Observatory, Kavalur with 2 members. The ticket cost was ₹50 per person, so the total ticket amount was ₹100.', 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-03 09:42:21', '2026-10-03 09:43:28', '', '', 'Kavalur', NULL),
(24, 'USR4PO31VQFU', 'Bike Parking', 20.00, 460.00, 7, 440.00, '🏍️ Bike Parking ', 'Cash', '2026-10-05', '06:47:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-05 09:43:13', '2026-10-05 09:43:13', NULL, NULL, 'Ambur', NULL),
(25, 'USR4PO31VQFU', 'VDM Bus', 30.00, 1554.00, 5, 1524.00, '🚗Travel ', 'Cash', '2026-10-05', '08:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-05 09:44:28', '2026-10-05 09:44:28', 'Ambur', 'Tirupathur', NULL, NULL),
(26, 'USR4PO31VQFU', 'JMS Bus', 10.00, 1524.00, 5, 1514.00, '🚗Travel ', 'Cash', '2026-10-05', '09:14:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-05 09:45:08', '2026-10-05 09:45:08', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(27, 'USR4PO31VQFU', 'Sakthivel Battery Charging', 20.00, 40.00, 20, 20.00, '💡 Bills & Utilities', 'UPI', '2026-10-02', '19:52:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-02 10:23:33', '2026-10-02 10:23:33', NULL, NULL, 'Ambur', NULL),
(28, 'USR4PO31VQFU', 'Government Bus', 36.00, 1514.00, 5, 1478.00, '🚗Travel ', 'UPI', '2026-10-05', '18:53:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-05 13:24:06', '2026-10-05 13:24:06', 'Tirupathur', 'Ambur', NULL, NULL),
(29, 'USR4PO31VQFU', 'Government Bus', 4.00, 1478.00, 5, 1474.00, '🚗Travel', 'Cash', '2026-10-05', '18:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-05 13:26:33', '2026-10-05 13:26:33', 'Vengateahvara Nagar', 'Tirupathur', NULL, NULL),
(30, 'USR4PO31VQFU', 'Bike Parking', 20.00, 440.00, 7, 420.00, '🏍️ Bike Parking ', 'Cash', '2026-10-06', '07:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 03:58:33', '2026-10-06 03:58:33', NULL, NULL, 'Ambur', NULL),
(31, 'USR4PO31VQFU', 'VDM Bus', 30.00, 1474.00, 5, 1444.00, '🚗Travel ', 'Cash', '2026-10-06', '08:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 03:59:31', '2026-10-06 03:59:31', 'Ambur', 'Tirupathur', NULL, NULL),
(32, 'USR4PO31VQFU', 'Ravi Bus', 10.00, 1444.00, 5, 1434.00, '🚗Travel ', 'Cash', '2026-10-06', '09:05:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 04:00:15', '2026-10-06 04:00:15', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(33, 'USR4PO31VQFU', 'Government Bus', 10.00, 1434.00, 5, 1424.00, '🚗Travel', 'Cash', '2026-10-06', '18:09:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 12:40:26', '2026-10-06 12:40:26', 'Vengateahvara Nagar', 'Tirupathur', NULL, NULL),
(34, 'USR4PO31VQFU', 'Government Bus', 25.00, 1424.00, 5, 1399.00, '🚗Travel', 'Cash', '2026-10-06', '18:25:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 12:56:56', '2026-10-06 12:56:56', 'Tirupathur', 'Ambur', NULL, NULL),
(35, 'USR4PO31VQFU', 'Kalan Pani Poori Shop', 35.00, 440.00, 4, 405.00, '🍔 Food', 'UPI', '2026-10-06', '19:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 16:07:57', '2026-10-06 16:07:57', NULL, NULL, 'Ambur', NULL),
(36, 'USR4PO31VQFU', 'Bike Parking', 20.00, 420.00, 7, 400.00, '🏍️ Bike Parking ', 'Cash', '2026-10-07', '11:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 05:59:08', '2026-10-09 05:59:17', '', '', 'Ambur', NULL),
(37, 'USR4PO31VQFU', 'Vegetable', 45.00, 120.00, 20, 75.00, '🛒 Grocery', 'Cash', '2026-10-07', '16:31:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-08 06:02:10', '2026-10-08 06:02:10', NULL, NULL, 'Ambur', NULL),
(38, 'USR4PO31VQFU', 'Ice Creem 2 Cup', 20.00, 405.00, 4, 385.00, '🍔 Food', 'Cash', '2026-10-07', '16:32:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-08 06:03:03', '2026-10-08 06:03:03', NULL, NULL, 'Ambur', NULL),
(39, 'USR4PO31VQFU', 'Ravi Shop Juice Seven Up', 10.00, 385.00, 4, 375.00, '🍔 Food', 'Cash', '2026-10-08', '15:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 06:08:07', '2026-10-09 06:08:07', NULL, NULL, 'Sollaikkolaimedu', NULL),
(40, 'USR4PO31VQFU', 'Bike Parking', 20.00, 400.00, 7, 380.00, '🏍️ Bike Parking ', 'Cash', '2026-10-09', '07:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-10 06:08:56', '2026-10-10 06:08:56', NULL, NULL, 'Ambur', NULL),
(41, 'USR4PO31VQFU', 'VDM Bus', 30.00, 1399.00, 5, 1369.00, '🚗Travel ', 'Cash', '2026-10-09', '08:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-10 06:09:35', '2026-10-10 06:09:35', 'Ambur', 'Tirupathur', NULL, NULL),
(42, 'USR4PO31VQFU', '4 Idli + 2 Vadai', 40.00, 375.00, 4, 335.00, '🍔 Food', 'Cash', '2026-10-09', '07:40:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-10 06:10:56', '2026-10-10 06:10:56', NULL, NULL, 'Ambur', NULL),
(43, 'USR4PO31VQFU', 'JMS Bus', 10.00, 1369.00, 5, 1359.00, '🚗Travel ', 'Cash', '2026-10-09', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 06:17:43', '2026-10-09 06:17:43', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(44, 'USR4PO31VQFU', 'Alangayam 1 EMI', 4500.00, 4710.00, 2, 210.00, '💳 EMI / Loan', 'Cash', '2026-10-08', '15:21:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 08:14:15', '2026-10-09 08:14:15', NULL, NULL, 'Sollaikkolaimedu', NULL),
(45, 'USR4PO31VQFU', 'Government Bus', 25.00, 1359.00, 5, 1334.00, '🚗Travel ', 'UPI', '2026-10-09', '18:41:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 13:12:03', '2026-10-09 13:12:03', 'Tirupathur', 'Ambur', NULL, NULL),
(46, 'USR4PO31VQFU', 'Makacholam', 10.00, 335.00, 4, 325.00, '🍔 Food', 'Cash', '2026-10-09', '07:55:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 13:13:13', '2026-10-09 13:13:13', NULL, NULL, 'Ambur', NULL),
(47, 'USR4PO31VQFU', 'Government Bus', 15.00, 1334.00, 5, 1319.00, '🚗Travel ', 'Cash', '2026-10-09', '18:05:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 13:14:04', '2026-10-09 13:14:04', 'Vengateahvara Nagar', 'Tirupathur', NULL, NULL),
(48, 'USR4PO31VQFU', 'Bike Parking', 20.00, 380.00, 7, 360.00, '🏍️ Bike Parking ', 'Cash', '2026-10-10', '07:44:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-10 06:13:24', '2026-10-10 06:13:24', NULL, NULL, 'Ambur', NULL),
(49, 'USR4PO31VQFU', 'VDM Bus', 30.00, 1319.00, 5, 1289.00, '🚗Travel ', 'Cash', '2026-10-10', '08:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-10 06:14:13', '2026-10-10 06:14:13', 'Ambur', 'Tirupathur', NULL, NULL),
(50, 'USR4PO31VQFU', 'Petrol', 330.00, 1130.00, 6, 800.00, '⛽ Fuel', 'Cash', '2026-10-10', '19:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-11 10:19:38', '2026-10-11 10:19:38', NULL, NULL, NULL, NULL),
(51, 'USR4PO31VQFU', 'Government Bus', 36.00, 1289.00, 5, 1253.00, '🚗Travel ', 'Cash', '2026-10-10', '18:40:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-11 10:21:05', '2026-10-11 10:21:05', 'Tirupathur', 'Ambur', NULL, NULL),
(52, 'USR4PO31VQFU', 'Government Bus', 7.00, 1253.00, 5, 1246.00, '🚗Travel ', 'UPI', '2026-10-10', '18:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-11 10:22:25', '2026-10-11 10:22:25', 'Vengateahvara Nagar', 'Tirupathur', NULL, NULL),
(53, 'USR4PO31VQFU', 'VDM BUS', 30.00, 1246.00, 5, 1216.00, '🚗Travel ', 'UPI', '2026-10-12', '08:12:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-12 02:43:35', '2026-10-12 02:43:35', 'Ambur', 'Tirupathur', NULL, NULL),
(54, 'USR4PO31VQFU', 'Ponni Bus', 10.00, 1216.00, 5, 1206.00, '🚗Travel ', 'Cash', '2026-10-12', '09:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-12 08:29:39', '2026-10-12 08:29:39', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(55, 'USR4PO31VQFU', 'Government Bus', 36.00, 1206.00, 5, 1170.00, '🚗Travel', 'Cash', '2026-10-12', '18:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-12 13:05:05', '2026-10-12 13:05:05', 'Tirupathur', 'Ambur', NULL, NULL),
(56, 'USR4PO31VQFU', 'Bike Parking', 20.00, 360.00, 7, 340.00, '🏍️ Bike Parking', 'Cash', '2026-10-12', '19:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-13 02:33:33', '2026-10-13 02:33:33', NULL, NULL, 'Ambur', NULL),
(57, 'USR4PO31VQFU', 'VDM BUS', 30.00, 1170.00, 5, 1140.00, '🚗Travel ', 'Cash', '2026-10-13', '08:08:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-13 02:39:28', '2026-10-13 02:39:28', 'Ambur', 'Tirupathur', NULL, NULL),
(58, 'USR4PO31VQFU', 'Ponni Bus', 10.00, 1140.00, 5, 1130.00, '🚗Travel ', 'Cash', '2026-10-13', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-13 09:16:05', '2026-10-13 09:16:05', 'Tirupattur', 'Vengateahvara Nagar', NULL, NULL),
(59, 'USR4PO31VQFU', 'Government Bus', 25.00, 1130.00, 5, 1105.00, '🚗Travel', 'UPI', '2026-10-13', '18:37:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-13 13:08:40', '2026-10-13 13:08:40', 'Tirupathur', 'Ambur', NULL, NULL),
(60, 'USR4PO31VQFU', 'Ravi Shop', 5.00, 75.00, 20, 70.00, '📦 Other', 'Cash', '2026-10-14', '06:55:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-14 03:43:32', '2026-10-14 03:43:32', NULL, NULL, 'Sollaikkolaimedu', NULL),
(61, 'USR4PO31VQFU', 'Bike Parking', 20.00, 340.00, 7, 320.00, '🏍️ Bike Parking', 'Cash', '2026-10-13', '19:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-14 03:45:03', '2026-10-14 03:45:03', NULL, NULL, 'Ambur', NULL),
(62, 'USR4PO31VQFU', 'Government Bus', 25.00, 1105.00, 5, 1080.00, '🚗Travel', 'UPI', '2026-10-14', '08:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-14 03:46:10', '2026-10-14 03:46:10', 'Ambur', 'Tirupathur', NULL, NULL),
(63, 'USR4PO31VQFU', 'Ponni Bus', 10.00, 1080.00, 5, 1070.00, '🚗Travel', 'Cash', '2026-10-14', '09:16:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-14 03:47:04', '2026-10-14 03:47:04', 'Tirupathur', 'Vengateahvara Nagar', NULL, NULL),
(64, 'USR4PO31VQFU', 'Vadai', 10.00, 325.00, 4, 315.00, '🍔 Food', 'Cash', '2026-10-13', '09:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-14 03:48:39', '2026-10-14 03:48:39', NULL, NULL, NULL, NULL),
(65, 'USR4PO31VQFU', 'Government Bus', 25.00, 1070.00, 5, 1045.00, '🚗Travel', 'UPI', '2026-10-14', '18:36:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-14 13:07:00', '2026-10-14 13:07:00', 'Tirupathur', 'Ambur', NULL, NULL),
(66, 'USR4PO31VQFU', 'Bike Parking', 20.00, 320.00, 7, 300.00, '🏍️ Bike Parking', 'Cash', '2026-10-14', '19:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-15 02:29:29', '2026-10-15 02:29:29', NULL, NULL, NULL, NULL),
(67, 'USR4PO31VQFU', 'Bike Parking', 20.00, 300.00, 7, 280.00, '🏍️ Bike Parking', 'Cash', '2026-10-15', '07:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-15 02:30:33', '2026-10-15 02:30:33', NULL, NULL, 'Ambur', NULL),
(68, 'USR4PO31VQFU', 'VDM BUS', 30.00, 1045.00, 5, 1015.00, '🚗Travel', 'UPI', '2026-10-15', '08:09:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-15 02:40:14', '2026-10-15 02:40:14', 'Ambur', 'Tirupathur', NULL, NULL),
(69, 'USR4PO31VQFU', 'Chits Kandiyappans', 3000.00, 3000.00, 3, 0.00, '💳 EMI / Loan', 'Cash', '2026-10-15', '08:11:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-15 02:45:58', '2026-10-15 06:42:11', '', '', NULL, NULL),
(70, 'USR4PO31VQFU', 'PVK Bus', 10.00, 1015.00, 5, 1005.00, '🚗Travel', 'Cash', '2026-10-15', '09:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-15 12:30:47', '2026-10-15 12:30:47', 'Tirupathur', 'Vengateahvara Nagar', NULL, NULL),
(71, 'USR4PO31VQFU', 'Government Bus', 7.00, 1005.00, 5, 998.00, '🚗Travel', 'UPI', '2026-10-15', '18:56:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-15 12:32:03', '2026-10-15 12:32:03', 'Vengateahvara Nagar', 'Tirupathur', NULL, NULL),
(72, 'USR4PO31VQFU', 'Government Bus', 25.00, 998.00, 5, 973.00, '🚗Travel', 'UPI', '2026-10-15', '18:39:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-15 13:10:28', '2026-10-15 13:10:28', 'Tirupathur', 'Ambur', NULL, NULL),
(73, 'USR4PO31VQFU', 'VDM Bus', 30.00, 973.00, 5, 943.00, '🚗Travel', 'UPI', '2026-10-16', '08:03:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-16 02:33:52', '2026-10-16 02:33:52', 'Ambur', 'Tirupathur', NULL, NULL),
(74, 'USR4PO31VQFU', 'Bike Parking', 20.00, 280.00, 7, 260.00, '🏍️ Bike Parking', 'Cash', '2026-10-16', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-16 02:34:49', '2026-10-16 02:34:49', NULL, NULL, 'Ambur', NULL),
(75, 'USR4PO31VQFU', 'Dhosai 2 One Plate', 30.00, 315.00, 4, 285.00, '🍔 Food', 'Cash', '2026-10-16', '21:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-16 12:48:36', '2026-10-16 12:48:36', NULL, NULL, 'Tirupathur', NULL),
(76, 'USR4PO31VQFU', 'Ponni Bus', 10.00, 943.00, 5, 933.00, '🚗Travel', 'Cash', '2026-10-16', '09:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-16 12:49:59', '2026-10-16 12:49:59', 'Tirupathur', 'Vengateahvara Nagar', NULL, NULL),
(77, 'USR4PO31VQFU', 'Government Bus', 20.00, 933.00, 5, 913.00, '🚗Travel', 'UPI', '2026-10-16', '18:53:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-16 13:24:49', '2026-10-16 13:24:49', 'Tirupathur', 'Ambur', NULL, NULL),
(78, 'USR4PO31VQFU', 'VDM Bus', 30.00, 913.00, 5, 883.00, '🚗Travel', 'UPI', '2026-10-17', '08:06:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-17 02:40:06', '2026-10-17 02:40:06', 'Ambur', 'Tirupathur', NULL, NULL),
(79, 'USR4PO31VQFU', 'Dhosai 2 One Plate', 30.00, 285.00, 4, 255.00, '🍔 Food', 'UPI', '2026-10-17', '09:00:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-17 03:39:30', '2026-10-17 03:39:30', NULL, NULL, 'Tirupathur', NULL),
(80, 'USR4PO31VQFU', 'JMS BUS', 10.00, 883.00, 5, 873.00, '🚗Travel', 'Cash', '2026-10-17', '09:07:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-17 03:40:45', '2026-10-17 03:40:45', 'Tirupathur', 'Vengateahvara Nagar', NULL, NULL),
(81, 'USR4PO31VQFU', 'Men\'s Formal Dress 2  Shirts  Tamil Nadu Cloths Shop', 850.00, 850.00, 20, 0.00, '👕 Clothing', 'UPI', '2026-10-03', '16:26:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-17 04:58:35', '2026-10-17 04:58:35', NULL, NULL, 'Alangayam', NULL),
(82, 'USR4PO31VQFU', 'Government Bus', 36.00, 873.00, 5, 837.00, '🚗Travel', 'UPI', '2026-10-17', '18:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-17 13:25:16', '2026-10-17 13:25:16', 'Tirupathur', 'Ambur', NULL, NULL),
(83, 'USR4PO31VQFU', 'Bike Parking', 20.00, 260.00, 7, 240.00, '🏍️ Bike Parking', 'Cash', '2026-10-17', '07:40:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-19 02:37:15', '2026-10-19 02:37:15', NULL, NULL, NULL, NULL),
(84, 'USR4PO31VQFU', 'Bike Parking', 20.00, 240.00, 7, 220.00, '🏍️ Bike Parking', 'Cash', '2026-10-19', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-19 02:39:17', '2026-10-19 02:39:17', NULL, NULL, 'Ambur', NULL),
(85, 'USR4PO31VQFU', 'VDM BUS', 30.00, 837.00, 5, 807.00, '🚗Travel', 'Cash', '2026-10-19', '08:09:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-19 02:40:20', '2026-10-19 02:40:20', 'Ambur', 'Tirupathur', NULL, NULL),
(86, 'USR4PO31VQFU', 'Electrical items MS Electronic Shop', 150.00, 150.00, 20, 0.00, '💡 Bills & Utilities', 'UPI', '2026-10-18', '14:43:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-19 07:15:51', '2026-10-19 07:15:51', NULL, NULL, 'Ambur', NULL),
(87, 'USR4PO31VQFU', 'JMS', 10.00, 807.00, 5, 797.00, '🚗Travel ', 'Cash', '2026-10-19', '09:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-19 07:16:31', '2026-10-19 07:16:31', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(88, 'USR4PO31VQFU', 'Government Bus', 25.00, 797.00, 5, 772.00, '🚗Travel', 'UPI', '2026-10-19', '18:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-19 17:47:26', '2026-10-19 17:47:26', 'Tirupathur', 'Ambur', NULL, NULL),
(89, 'USR4PO31VQFU', 'Petrol   HP', 220.00, 800.00, 6, 580.00, '⛽ Fuel', 'Cash', '2026-10-19', '19:40:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-19 17:48:51', '2026-10-19 17:48:51', NULL, NULL, 'Ambur', NULL),
(90, 'USR4PO31VQFU', 'Chappathi  Role 1', 20.00, 255.00, 4, 235.00, '🍔 Food', 'Cash', '2026-10-19', '19:41:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-19 17:50:20', '2026-10-19 17:50:20', NULL, NULL, 'Ambur', NULL),
(91, 'USR4PO31VQFU', 'VDM BUS', 30.00, 772.00, 5, 742.00, '🚗Travel', 'UPI', '2026-10-20', '08:03:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-20 02:33:56', '2026-10-20 02:33:56', 'Ambur', 'Tirupathur', NULL, NULL),
(92, 'USR4PO31VQFU', 'Bike Parking', 20.00, 220.00, 7, 200.00, '🏍️ Bike Parking', 'Cash', '2026-10-20', '07:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-20 02:37:17', '2026-10-20 02:37:17', NULL, NULL, 'Ambur', NULL),
(93, 'USR4PO31VQFU', 'Ravi BUS', 10.00, 742.00, 5, 732.00, '🚗Travel', 'Cash', '2026-10-20', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-20 03:23:44', '2026-10-20 03:23:44', 'Tirupathur', 'Vengateahvara Nagar', NULL, NULL),
(94, 'USR4PO31VQFU', 'Government Bus', 25.00, 732.00, 5, 707.00, '🚗Travel ', 'Cash', '2026-10-20', '17:35:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-21 08:18:35', '2026-10-21 08:18:35', 'Tirupattur', 'Ambur', NULL, NULL),
(95, 'USR4PO31VQFU', 'Bike Parking', 20.00, 200.00, 7, 180.00, '🏍️ Bike Parking ', 'Cash', '2026-10-21', '07:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-21 08:19:22', '2026-10-21 08:19:22', NULL, NULL, 'Ambur', NULL),
(96, 'USR4PO31VQFU', 'VDM Bus', 30.00, 707.00, 5, 677.00, '🚗Travel ', 'Cash', '2026-10-21', '08:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-21 08:20:07', '2026-10-21 08:20:07', 'Ambur', 'Tirupattur', NULL, NULL),
(97, 'USR4PO31VQFU', 'JMS Bus', 10.00, 677.00, 5, 667.00, '🚗Travel ', 'Cash', '2026-10-21', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-21 08:20:44', '2026-10-21 08:20:44', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(98, 'USR4PO31VQFU', 'Dhosai 2 One Plate', 30.00, 235.00, 4, 205.00, '🍔 Food', 'Cash', '2026-10-21', '08:57:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-21 08:21:43', '2026-10-21 08:21:43', NULL, NULL, 'Tirupattur', NULL),
(99, 'USR4PO31VQFU', 'Government Bus', 25.00, 667.00, 5, 642.00, '🚗Travel ', 'Cash', '2026-10-21', '12:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-23 06:50:54', '2026-10-23 06:50:54', 'Tirupattur', 'Ambur', NULL, NULL),
(100, 'USR4PO31VQFU', 'Ravi Shop Biscuits', 10.00, 205.00, 4, 195.00, '🍔 Food', 'Cash', '2026-10-22', '14:00:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-23 06:54:06', '2026-10-23 06:54:06', NULL, NULL, 'Sollaikkolaimedu', NULL),
(101, 'USR4PO31VQFU', 'VDM Bus', 30.00, 642.00, 5, 612.00, '🚗Travel ', 'Cash', '2026-10-23', '08:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-23 06:54:50', '2026-10-23 06:54:50', 'Ambur', 'Tirupattur', NULL, NULL),
(102, 'USR4PO31VQFU', 'PVK Bus', 10.00, 612.00, 5, 602.00, '🚗Travel ', 'Cash', '2026-10-23', '09:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-23 06:55:24', '2026-10-23 06:55:24', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(103, 'USR4PO31VQFU', 'Dhosai 2 One Plate', 30.00, 195.00, 4, 165.00, '🍔 Food', 'Cash', '2026-10-23', '08:56:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-23 06:56:20', '2026-10-23 06:56:20', NULL, NULL, 'Tirupattur', NULL),
(104, 'USR4PO31VQFU', 'Mobile Recharge', 300.00, 300.00, 1, 0.00, '📱 Recharge', 'Cash', '2026-10-23', '22:12:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-23 16:44:19', '2026-10-23 16:44:19', NULL, NULL, 'Sollaikkolaimedu', NULL),
(105, 'USR4PO31VQFU', 'Government Bus', 7.00, 602.00, 5, 595.00, '🚗Travel', 'Cash', '2026-10-23', '18:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-23 16:49:31', '2026-10-23 16:49:31', 'Vengateahwara Nagar', 'Tirupathur', NULL, NULL),
(106, 'USR4PO31VQFU', 'PVK', 10.00, 602.00, 5, 592.00, '🚗Travel ', 'Cash', '2026-10-24', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-23 16:49:34', '2026-10-24 05:16:18', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(107, 'USR4PO31VQFU', 'Government Bus', 25.00, 588.00, 5, 563.00, '🚗Travel', 'Cash', '2026-10-23', '06:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-24 02:28:08', '2026-10-24 02:28:08', 'Tirupathur', 'Ambur', NULL, NULL),
(108, 'USR4PO31VQFU', 'Bike Parking', 20.00, 180.00, 7, 160.00, '🏍️ Bike Parking', 'Cash', '2026-10-23', '07:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-24 02:31:35', '2026-10-24 02:31:35', NULL, NULL, 'Ambur', NULL),
(109, 'USR4PO31VQFU', 'Bike Parking', 20.00, 160.00, 7, 140.00, '🏍️ Bike Parking', 'Cash', '2026-10-24', '07:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-24 02:32:27', '2026-10-24 02:32:27', NULL, NULL, NULL, NULL),
(110, 'USR4PO31VQFU', 'VDM BUS', 30.00, 563.00, 5, 533.00, '🚗Travel', 'UPI', '2026-10-24', '08:04:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-24 02:35:05', '2026-10-24 02:35:05', 'Ambur', 'Tirupathur', NULL, NULL),
(111, 'USR4PO31VQFU', 'Dhosai  2 One Plate', 30.00, 165.00, 4, 135.00, '🍔 Food', 'Cash', '2026-10-24', '09:05:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-24 03:41:08', '2026-10-24 03:41:08', NULL, NULL, 'Tirupathur', NULL),
(112, 'USR4PO31VQFU', 'Parota 3 And  1Amblet', 75.00, 135.00, 4, 60.00, '🍔 Food', 'Cash', '2026-10-24', '13:25:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-24 12:14:40', '2026-10-24 12:14:40', NULL, NULL, NULL, NULL),
(113, 'USR4PO31VQFU', 'Government Bus', 7.00, 530.00, 5, 523.00, '🚗Travel', 'Cash', '2026-10-24', '17:40:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-24 12:15:40', '2026-10-24 12:15:40', 'Vengateahwara Nagar', 'Tirupathur', NULL, NULL),
(114, 'USR4PO31VQFU', 'Government Bus', 36.00, 523.00, 5, 487.00, '🚗Travel', 'UPI', '2026-10-24', '18:08:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-24 12:39:17', '2026-10-24 12:39:17', 'Tirupathur', 'Ambur', NULL, NULL),
(115, 'USR4PO31VQFU', 'Ravi Shop Cooking items', 20.00, 60.00, 4, 40.00, '💡 Bills & Utilities', 'Cash', '2026-10-25', '10:02:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-25 04:33:34', '2026-10-29 08:07:06', '', '', 'Sollaikkolaimedu', NULL),
(116, 'USR4PO31VQFU', 'Bike Parking', 20.00, 140.00, 7, 120.00, '🏍️ Bike Parking', 'Cash', '2026-10-26', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-26 02:24:50', '2026-10-26 02:24:50', NULL, NULL, 'Ambur', NULL),
(117, 'USR4PO31VQFU', 'VDM BUS', 30.00, 487.00, 5, 457.00, '🚗Travel', 'UPI', '2026-10-26', '07:58:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-26 02:26:44', '2026-10-26 02:26:44', 'Ambur', 'Tirupathur', NULL, NULL),
(118, 'USR4PO31VQFU', 'Petrol', 330.00, 580.00, 6, 250.00, '⛽ Fuel', 'UPI', '2026-10-24', '06:57:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-26 02:32:57', '2026-10-26 04:09:40', '', '', 'Ambur', NULL),
(119, 'USR4PO31VQFU', 'Ravi Bus', 10.00, 457.00, 5, 447.00, '🚗Travel', 'Cash', '2026-10-26', '09:00:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-26 06:30:23', '2026-10-26 06:30:23', 'Tirupathur', 'Ambur', NULL, NULL),
(120, 'USR4PO31VQFU', 'Government Bus', 36.00, 447.00, 5, 411.00, '🚗Travel', 'UPI', '2026-10-26', '18:43:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-26 13:14:39', '2026-10-26 13:14:39', 'Tirupathur', 'Ambur', NULL, NULL),
(121, 'USR4PO31VQFU', 'Bike Parking', 20.00, 120.00, 7, 100.00, '🏍️ Bike Parking', 'Cash', '2026-10-27', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-27 02:35:39', '2026-10-27 02:35:39', NULL, NULL, 'Ambur', NULL),
(122, 'USR4PO31VQFU', 'VDM Bus', 30.00, 411.00, 5, 381.00, '🚗Travel', 'Cash', '2026-10-27', '08:05:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-27 02:36:31', '2026-10-27 02:36:31', 'Ambur', 'Tirupathur', NULL, NULL),
(123, 'USR4PO31VQFU', 'Government Bus', 36.00, 381.00, 5, 345.00, '🚗Travel', 'UPI', '2026-10-27', '18:39:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-27 13:10:24', '2026-10-27 13:10:24', 'Tirupathur', 'Ambur', NULL, NULL),
(124, 'USR4PO31VQFU', 'JMS Bus', 10.00, 345.00, 5, 335.00, '🚗Travel', 'Cash', '2026-10-27', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-27 13:11:32', '2026-10-27 13:11:32', 'Tirupathur', 'Vengateahwara Nagar', NULL, NULL),
(125, 'USR4PO31VQFU', 'Time pass Shop', 10.00, 40.00, 4, 30.00, '🍔 Food', 'Cash', '2026-10-27', '09:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-27 13:12:26', '2026-10-27 13:12:26', NULL, NULL, 'Vengateahwara Nagar', NULL),
(126, 'USR4PO31VQFU', 'VDM Bus', 30.00, 335.00, 5, 305.00, '🚗Travel', 'UPI', '2026-10-28', '08:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-28 03:02:07', '2026-10-28 03:02:07', 'Ambur', 'Tirupathur', NULL, NULL),
(127, 'USR4PO31VQFU', 'Pasta Cooking Items  Ravi Shop', 40.00, 40.00, 4, 0.00, '🍔 Food', 'Cash', '2026-10-28', '06:25:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-28 05:17:53', '2026-10-28 05:17:53', NULL, NULL, 'Sollaikkolaimedu', NULL),
(128, 'USR4PO31VQFU', 'Ravi Bus', 10.00, 305.00, 5, 295.00, '🚗Travel ', 'Cash', '2026-10-28', '09:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-28 05:18:45', '2026-10-28 05:19:57', 'Tirupattur', 'Ambur', NULL, NULL),
(129, 'USR4PO31VQFU', 'Government Bus', 25.00, 295.00, 5, 270.00, '🚗Travel', 'UPI', '2026-10-28', '18:35:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-28 13:05:57', '2026-10-28 13:05:57', 'Tirupathur', 'Ambur', NULL, NULL),
(130, 'USR4PO31VQFU', 'Government Bus', 14.00, 270.00, 5, 256.00, '🚗Travel', 'Cash', '2026-10-28', '18:05:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-28 13:07:19', '2026-10-28 13:07:19', 'Vengateahwara Nagar', 'Tirupathur', NULL, NULL),
(131, 'USR4PO31VQFU', 'Bike Parking', 20.00, 100.00, 7, 80.00, '🏍️ Bike Parking', 'Cash', '2026-10-29', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-29 02:27:30', '2026-10-29 02:27:30', NULL, NULL, 'Ambur', NULL),
(132, 'USR4PO31VQFU', 'Bike Parking', 20.00, 80.00, 7, 60.00, '🏍️ Bike Parking', 'UPI', '2026-10-28', '19:25:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-29 02:28:21', '2026-10-29 02:28:21', NULL, NULL, 'Ambur', NULL),
(133, 'USR4PO31VQFU', 'Samiya Cooking And 4 Idly  2 Vadai', 45.00, 100.00, 4, 55.00, '🍔 Food', 'Cash', '2026-10-29', '06:14:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-29 06:31:18', '2026-10-29 06:31:18', NULL, NULL, 'Sollaikkolaimedu', NULL),
(134, 'USR4PO31VQFU', 'VDM Bus', 30.00, 256.00, 5, 226.00, '🚗Travel ', 'Cash', '2026-10-29', '08:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-29 06:32:23', '2026-10-29 06:32:23', 'Ambur', 'Tirupattur', NULL, NULL),
(135, 'USR4PO31VQFU', 'JMS Bus', 10.00, 226.00, 5, 216.00, '🚗Travel ', 'Cash', '2026-10-29', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-29 06:32:58', '2026-10-29 06:32:58', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(136, 'USR4PO31VQFU', 'Government Bus', 7.00, 216.00, 5, 209.00, '🚗Travel', 'Cash', '2026-10-29', '18:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-29 13:03:52', '2026-10-29 13:03:52', 'Vengateahwara Nagar', 'Tirupathur', NULL, NULL),
(137, 'USR4PO31VQFU', 'Government Bus', 36.00, 209.00, 5, 173.00, '🚗Travel', 'UPI', '2026-10-29', '18:32:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-29 13:04:47', '2026-10-29 13:04:47', 'Tirupathur', 'Ambur', NULL, NULL),
(138, 'USR4PO31VQFU', 'Bike Parking', 20.00, 60.00, 7, 40.00, '🏍️ Bike Parking', 'Cash', '2026-10-30', '07:43:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-30 13:13:50', '2026-10-30 13:13:50', NULL, NULL, 'Ambur', NULL),
(139, 'USR4PO31VQFU', 'VDM Bus', 30.00, 173.00, 5, 143.00, '🚗Travel', 'UPI', '2026-10-30', '08:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-30 13:15:41', '2026-10-30 13:15:41', 'Ambur', 'Tirupathur', NULL, NULL),
(140, 'USR4PO31VQFU', 'JMS Bus', 10.00, 143.00, 5, 133.00, '🚗Travel', 'Cash', '2026-10-30', '09:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-30 13:16:43', '2026-10-30 13:16:43', 'Tirupathur', 'Vengateahwara Nagar', NULL, NULL),
(141, 'USR4PO31VQFU', 'Government Bus', 25.00, 133.00, 5, 108.00, '🚗Travel', 'UPI', '2026-10-30', '18:40:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-30 13:17:44', '2026-10-30 13:17:44', 'Tirupathur', 'Ambur', NULL, NULL),
(142, 'USR4PO31VQFU', 'Tablet Sakthivel', 50.00, 50.00, 20, 0.00, '💊 Health', 'Cash', '2026-10-29', '19:40:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-30 13:22:46', '2026-10-30 13:22:46', NULL, NULL, 'Ambur', NULL),
(143, 'USR4PO31VQFU', 'Bike Parking', 20.00, 40.00, 7, 20.00, '🏍️ Bike Parking ', 'Cash', '2026-10-31', '07:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-31 03:37:49', '2026-10-31 03:37:49', NULL, NULL, 'Ambur', NULL),
(144, 'USR4PO31VQFU', 'VDM Bus', 30.00, 108.00, 5, 78.00, '🚗Travel ', 'Cash', '2026-10-31', '08:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-31 11:19:54', '2026-10-31 11:19:54', 'Ambur', 'Tirupathur', NULL, NULL),
(145, 'USR4PO31VQFU', 'Government Bus', 32.00, 78.00, 5, 46.00, '🚗Travel', 'UPI', '2026-10-31', '17:35:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-31 12:06:15', '2026-10-31 12:06:15', 'Tirupathur', 'Ambur', NULL, NULL),
(146, 'USR4PO31VQFU', 'JMS Bus', 10.00, 46.00, 5, 36.00, '🚗Travel', 'Cash', '2026-10-31', '09:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-31 12:08:34', '2026-10-31 12:08:34', 'Tirupathur', 'Vengateahwara Nagar', NULL, NULL),
(147, 'USR4PO31VQFU', 'Bike Parking', 20.00, 20.00, 7, 0.00, '🏍️ Bike Parking ', 'Cash', '2026-11-02', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-02 05:07:47', '2026-11-02 05:07:47', NULL, NULL, 'Ambur', NULL),
(148, 'USR4PO31VQFU', 'VDM Bus', 30.00, 36.00, 5, 6.00, '🚗Travel ', 'Cash', '2026-11-02', '08:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-02 05:08:27', '2026-11-02 05:08:27', 'Ambur', 'Tirupathur', NULL, NULL),
(149, 'USR4PO31VQFU', 'JMS Bus', 10.00, 106.00, 5, 96.00, '🚗Travel ', 'Cash', '2026-11-02', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-02 05:09:53', '2026-11-02 05:09:53', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(150, 'USR4PO31VQFU', 'My Snacks Food', 15.00, 20.00, 20, 5.00, '🍔 Food', 'Cash', '2026-11-01', '15:01:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-02 05:19:40', '2026-11-02 05:20:01', '', '', 'Sollaikkolaimedu', NULL),
(151, 'USR4PO31VQFU', 'Petrol', 330.00, 530.00, 6, 200.00, '⛽ Fuel', 'UPI', '2026-10-31', '19:37:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-02 09:29:48', '2026-11-02 09:29:48', NULL, NULL, 'Ambur', NULL),
(152, 'USR4PO31VQFU', 'Sanmuga Bus', 10.00, 96.00, 5, 86.00, '🚗Travel', 'Cash', '2026-11-02', '18:05:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-02 12:36:06', '2026-11-02 12:36:06', 'Vengateahwara Nagar', 'Tirupathur', NULL, NULL),
(153, 'USR4PO31VQFU', 'Government Bus', 25.00, 86.00, 5, 61.00, '🚗Travel', 'UPI', '2026-11-02', '18:37:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-02 13:07:44', '2026-11-02 13:07:44', 'Tirupathur', 'Ambur', NULL, NULL),
(154, 'USR4PO31VQFU', 'VDM Bus', 30.00, 61.00, 5, 31.00, '🚗Travel', 'UPI', '2026-11-03', '08:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-03 03:10:33', '2026-11-03 03:10:33', 'Ambur', 'Tirupathur', NULL, NULL),
(155, 'USR4PO31VQFU', 'Dhosai 2 One Plate', 30.00, 55.00, 4, 25.00, '🍔 Food', 'UPI', '2026-11-03', '09:05:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-03 03:38:08', '2026-11-03 03:38:08', NULL, NULL, 'Tirupathur', NULL),
(156, 'USR4PO31VQFU', 'Ravi Shop Karpooram', 5.00, 5.00, 20, 0.00, '📦 Other', 'Cash', '2026-11-04', '06:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 08:18:17', '2026-11-04 08:18:17', NULL, NULL, 'Sollaikkolaimedu', NULL),
(157, 'USR4PO31VQFU', 'VDM Bus', 30.00, 300.99, 5, 270.99, '🚗Travel ', 'Cash', '2026-11-04', '13:48:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 08:19:35', '2026-11-04 08:19:35', 'Ambur', 'Tirupathur', NULL, NULL),
(158, 'USR4PO31VQFU', 'Bike Parking', 20.00, 100.00, 7, 80.00, '🏍️ Bike Parking', 'Cash', '2026-11-04', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 08:20:15', '2026-11-04 08:20:15', NULL, NULL, 'Ambur', NULL),
(159, 'USR4PO31VQFU', 'JMS', 10.00, 270.99, 5, 260.99, '🚗Travel ', 'Cash', '2026-11-04', '09:05:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 08:20:55', '2026-11-04 08:20:55', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(160, 'USR4PO31VQFU', 'Government  Bus', 7.00, 260.99, 5, 253.99, '🚗Travel ', 'Cash', '2026-11-03', '18:08:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 08:22:29', '2026-11-04 08:22:29', 'Vengateshware Nagar', 'Tirupathur', NULL, NULL),
(161, 'USR4PO31VQFU', 'Government Bus', 36.00, 253.99, 5, 217.99, '🚗Travel ', 'UPI', '2026-11-03', '18:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 08:23:35', '2026-11-04 08:23:35', 'Tirupattur', 'Ambur', NULL, NULL),
(162, 'USR4PO31VQFU', 'Tablet My Dhiva', 40.00, 190.00, 20, 150.00, '💊 Health', 'UPI', '2026-11-03', '18:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 08:25:03', '2026-11-04 08:25:03', NULL, NULL, 'Ambur', NULL),
(163, 'USR4PO31VQFU', 'Hair Cutting', 150.00, 150.00, 20, 0.00, '💡 Bills & Utilities', 'UPI', '2026-11-03', '18:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 08:28:26', '2026-11-04 08:28:26', NULL, NULL, 'Ambur', NULL),
(164, 'USR4PO31VQFU', 'Bike Parking', 20.00, 80.00, 7, 60.00, '🏍️ Bike Parking', 'Cash', '2026-11-03', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 08:30:19', '2026-11-04 08:30:19', NULL, NULL, 'Ambur', NULL),
(165, 'USR4PO31VQFU', 'Bike Hair Checking', 10.00, 50.00, 20, 40.00, '💡 Bills & Utilities', 'Cash', '2026-10-31', '19:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 10:24:19', '2026-11-04 10:24:19', NULL, NULL, 'Ambur', NULL),
(166, 'USR4PO31VQFU', 'Government Bus', 25.00, 217.99, 5, 192.99, '🚗Travel', 'UPI', '2026-11-04', '18:36:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 13:15:09', '2026-11-04 13:15:09', 'Tirupathur', 'Ambur', NULL, NULL),
(167, 'USR4PO31VQFU', 'Bike Parking', 20.00, 60.00, 7, 40.00, '🏍️ Bike Parking', 'Cash', '2026-11-05', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-05 02:42:49', '2026-11-05 02:42:49', NULL, NULL, 'Ambur', NULL),
(168, 'USR4PO31VQFU', 'VDm Bus', 30.00, 192.99, 5, 162.99, '🚗Travel', 'UPI', '2026-11-05', '08:12:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-05 02:43:49', '2026-11-05 02:43:49', 'Ambur', 'Tirupathur', NULL, NULL),
(169, 'USR4PO31VQFU', 'Ravi Bus', 10.00, 162.99, 5, 152.99, '🚗Travel ', 'Cash', '2026-11-05', '09:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-05 04:18:47', '2026-11-05 04:18:47', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(170, 'USR4PO31VQFU', 'Government Bus', 36.00, 152.99, 5, 116.99, '🚗Travel', 'Cash', '2026-11-05', '18:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-05 13:15:53', '2026-11-05 13:15:53', 'Tirupathur', 'Ambur', NULL, NULL),
(171, 'USR4PO31VQFU', 'JMS Bus', 10.00, 116.99, 5, 106.99, '🚗Travel', 'Cash', '2026-11-06', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-06 06:18:07', '2026-11-06 06:18:07', 'Tirupathur', 'Vengateahwara', NULL, NULL),
(172, 'USR4PO31VQFU', 'Government Bus', 36.00, 106.99, 5, 70.99, '🚗Travel', 'UPI', '2026-11-06', '11:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-06 06:21:26', '2026-11-06 06:21:26', 'Tirupathur', 'Ambur', NULL, NULL),
(173, 'USR4PO31VQFU', 'VDM Bus', 30.00, 70.99, 5, 40.99, '🚗Travel', 'Cash', '2026-11-06', '08:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-06 06:22:19', '2026-11-06 06:22:19', 'Ambur', 'Tirupathur', NULL, NULL),
(174, 'USR4PO31VQFU', 'Government Bus', 7.00, 40.99, 5, 33.99, '🚗Travel', 'Cash', '2026-11-06', '11:40:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-06 06:23:31', '2026-11-06 06:23:31', 'Vengateahwara Nagar', 'Tirupathur', NULL, NULL),
(175, 'USR4PO31VQFU', 'Briyani', 130.00, 130.00, 4, 0.00, '🍔 Food', 'UPI', '2026-11-06', '12:57:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-06 07:31:30', '2026-11-06 07:31:30', NULL, NULL, 'Ambur', NULL),
(176, 'USR4PO31VQFU', 'Bike Parking', 20.00, 40.00, 7, 20.00, '🏍️ Bike Parking', 'Cash', '2026-11-06', '00:45:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-06 08:33:27', '2026-11-06 08:33:27', NULL, NULL, 'Ambur', NULL),
(177, 'USR4PO31VQFU', 'Bike Parking', 20.00, 20.00, 7, 0.00, '🏍️ Bike Parking', 'Cash', '2026-11-09', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 04:15:39', '2026-11-09 04:15:39', NULL, NULL, 'Ambur', NULL),
(178, 'USR4PO31VQFU', 'Government Bus', 25.00, 33.99, 5, 8.99, '🚗Travel ', 'UPI', '2026-11-09', '08:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 04:51:09', '2026-11-09 04:51:09', 'Ambur', 'Tirupathur', NULL, NULL),
(179, 'USR4PO31VQFU', 'Dhosai 2 One Plate', 30.00, 30.00, 4, 0.00, '🍔 Food', 'UPI', '2026-11-09', '09:58:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 06:58:14', '2026-11-09 06:58:14', NULL, NULL, 'Tirupattur', NULL),
(180, 'USR4PO31VQFU', 'JMS', 10.00, 54.00, 5, 44.00, '🚗Travel ', 'Cash', '2026-11-09', '09:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 06:58:59', '2026-11-09 06:58:59', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(181, 'USR4PO31VQFU', 'Loan / EMI', 4500.00, 4500.00, 22, 0.00, '💳 EMI / Loan', 'Cash', '2026-11-07', '11:00:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 07:02:16', '2026-11-09 07:02:16', NULL, NULL, 'Sollaikkolaimedu', NULL),
(182, 'USR4PO31VQFU', 'Government Bus', 36.00, 44.00, 5, 8.00, '🚗Travel', 'UPI', '2026-11-09', '18:42:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 13:13:15', '2026-11-09 13:13:15', 'Tirupathur', 'Ambur', NULL, NULL),
(183, 'USR4PO31VQFU', 'Government Bus', 25.00, 2850.00, 28, 2825.00, '🚗Travel ', 'UPI', '2026-11-10', '08:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-10 04:08:51', '2026-11-10 04:08:51', 'Ambur', 'Tirupathur', NULL, NULL),
(184, 'USR4PO31VQFU', 'JMS Bus', 10.00, 2825.00, 28, 2815.00, '🚗Travel ', 'Cash', '2026-11-10', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-10 04:09:36', '2026-11-10 04:09:36', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(185, 'USR4PO31VQFU', 'Pineapple', 20.00, 300.00, 24, 280.00, '🍔 Food', 'Cash', '2026-11-10', '08:58:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-10 04:11:18', '2026-11-10 04:11:18', NULL, NULL, 'Tirupattur', NULL),
(186, 'USR4PO31VQFU', 'Bike Parking', 20.00, 620.00, 26, 600.00, '🏍️ Bike Parking', 'Cash', '2026-11-10', '19:55:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-10 08:39:26', '2026-11-10 08:39:26', NULL, NULL, 'Ambur', NULL),
(187, 'USR4PO31VQFU', 'Bike Parking', 20.00, 600.00, 26, 580.00, '🏍️ Bike Parking', 'Cash', '2026-11-11', '07:55:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-11 02:39:32', '2026-11-11 02:39:32', NULL, NULL, 'Ambur', NULL),
(188, 'USR4PO31VQFU', 'Petrol', 330.00, 1500.00, 27, 1170.00, '⛽ Fuel', 'UPI', '2026-11-10', '07:40:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-11 02:40:28', '2026-11-11 02:40:28', NULL, NULL, 'Ambur', NULL),
(189, 'USR4PO31VQFU', 'Nithya Snacks', 20.00, 280.00, 24, 260.00, '💡 Bills & Utilities', 'Cash', '2026-11-10', '20:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-11 02:41:38', '2026-11-11 02:41:38', NULL, NULL, 'Sollaikkolaimedu', NULL),
(190, 'USR4PO31VQFU', 'Government Bus', 25.00, 2815.00, 28, 2790.00, '🚗Travel', 'UPI', '2026-11-11', '08:11:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-11 02:42:23', '2026-11-11 02:42:23', 'Ambur', 'Tirupathur', NULL, NULL),
(191, 'USR4PO31VQFU', 'Government Bus', 25.00, 2790.00, 28, 2765.00, '🚗Travel', 'Cash', '2026-11-10', '18:35:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-11 02:44:46', '2026-11-11 02:44:46', 'Tirupathur', 'Ambur', NULL, NULL),
(192, 'USR4PO31VQFU', 'Ponni  Bus', 10.00, 2765.00, 28, 2755.00, '🚗Travel ', 'Cash', '2026-11-11', '09:19:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-11 05:50:19', '2026-11-11 05:50:19', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(193, 'USR4PO31VQFU', 'Government Bus', 25.00, 2755.00, 28, 2730.00, '🚗Travel', 'UPI', '2026-11-11', '18:36:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-11 13:07:30', '2026-11-11 13:07:30', 'Tirupathur', 'Ambur', NULL, NULL),
(194, 'USR4PO31VQFU', 'Bike Parking', 20.00, 580.00, 26, 560.00, '🏍️ Bike Parking', 'Cash', '2026-11-12', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-12 02:32:45', '2026-11-12 02:32:45', NULL, NULL, 'Ambur', NULL),
(195, 'USR4PO31VQFU', 'Government Bus', 25.00, 2730.00, 28, 2705.00, '🚗Travel', 'UPI', '2026-11-12', '08:03:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-12 02:33:37', '2026-11-12 02:33:37', 'Ambur', 'Tirupathur', NULL, NULL),
(196, 'USR4PO31VQFU', 'Cooking  things', 20.00, 260.00, 24, 240.00, '🛍️ Shopping', 'Cash', '2026-11-12', '06:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-12 02:35:23', '2026-11-12 02:35:23', NULL, NULL, 'Sollaikkolaimedu', NULL),
(197, 'USR4PO31VQFU', 'JMS Bus', 10.00, 2705.00, 28, 2695.00, '🚗Travel ', 'Cash', '2026-11-12', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-12 11:09:23', '2026-11-12 11:09:23', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(198, 'USR4PO31VQFU', 'Dhosai 2 One Plate', 30.00, 300.00, 25, 270.00, '🍔 Food', 'UPI', '2026-11-12', '08:59:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-12 11:10:10', '2026-11-12 11:10:10', NULL, NULL, 'Tirupattur', NULL),
(199, 'USR4PO31VQFU', 'Government Bus', 36.00, 2695.00, 28, 2659.00, '🚗Travel', 'UPI', '2026-11-12', '18:36:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-12 13:07:31', '2026-11-12 13:07:31', 'Tirupathur', 'Ambur', NULL, NULL),
(200, 'USR4PO31VQFU', 'Government Bus', 10.00, 2659.00, 28, 2649.00, '🚗Travel', 'Cash', '2026-11-12', '18:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-12 13:08:25', '2026-11-12 13:08:25', 'Vengateahwara Nagar', 'Tirupathur', NULL, NULL),
(201, 'USR4PO31VQFU', 'Bike Parking', 20.00, 560.00, 26, 540.00, '🏍️ Bike Parking', 'Cash', '2026-11-13', '07:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-13 03:29:46', '2026-11-13 03:29:46', NULL, NULL, 'Ambur', NULL),
(202, 'USR4PO31VQFU', 'Government Bus', 25.00, 2649.00, 28, 2624.00, '🚗Travel', 'UPI', '2026-11-13', '08:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-13 03:30:39', '2026-11-13 04:18:54', 'Ambur', 'Tirupathur', NULL, NULL),
(203, 'USR4PO31VQFU', 'PVK Bus', 10.00, 2624.00, 28, 2614.00, '🚗Travel ', 'Cash', '2026-11-13', '09:22:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-13 04:22:42', '2026-11-13 04:22:42', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(204, 'USR4PO31VQFU', 'Government Bus', 36.00, 2614.00, 28, 2578.00, '🚗Travel', 'UPI', '2026-11-13', '18:33:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-13 13:03:45', '2026-11-14 06:07:05', 'Tirupathur', 'Ambur', NULL, NULL),
(205, 'USR4PO31VQFU', 'Chicken Noodles Chicken Role', 100.00, 270.00, 25, 170.00, '🍔 Food', 'UPI', '2026-11-13', '19:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-14 06:08:22', '2026-11-14 06:08:22', NULL, NULL, 'Ambur', NULL),
(206, 'USR4PO31VQFU', 'Bike Parking', 20.00, 540.00, 26, 520.00, '🏍️ Bike Parking', 'Cash', '2026-11-16', '07:55:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-16 02:37:21', '2026-11-16 02:37:21', NULL, NULL, 'Ambur', NULL),
(207, 'USR4PO31VQFU', 'Government Bus', 25.00, 2578.00, 28, 2553.00, '🚗Travel', 'UPI', '2026-11-16', '08:07:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-16 02:38:06', '2026-11-16 02:38:06', 'Ambur', 'Tirupathur', NULL, NULL),
(208, 'USR4PO31VQFU', 'Dhosai 2 One Plate', 30.00, 170.00, 25, 140.00, '🍔 Food', 'Cash', '2026-11-16', '09:00:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-16 13:06:30', '2026-11-16 13:06:30', NULL, NULL, 'Tirupathur', NULL),
(209, 'USR4PO31VQFU', 'Government Bus', 25.00, 2553.00, 28, 2528.00, '🚗Travel', 'UPI', '2026-11-16', '18:38:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-16 13:09:05', '2026-11-16 13:09:05', 'Tirupathur', 'Ambur', NULL, NULL),
(210, 'USR4PO31VQFU', 'Bike Parking', 20.00, 520.00, 26, 500.00, '🏍️ Bike Parking', 'Cash', '2026-11-17', '07:55:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-17 03:21:45', '2026-11-17 03:21:45', NULL, NULL, 'Ambur', NULL),
(211, 'USR4PO31VQFU', 'Government Bus', 25.00, 2528.00, 28, 2503.00, '🚗Travel', 'UPI', '2026-11-17', '08:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-17 03:22:40', '2026-11-17 03:22:40', 'Ambur', 'Tirupathur', NULL, NULL),
(212, 'USR4PO31VQFU', 'Kandiyapan Chit Fund', 3000.00, 3000.00, 23, 0.00, '📈 Investment Chit', 'Cash', '2026-11-15', '03:53:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-17 03:26:42', '2026-11-17 03:26:42', NULL, NULL, 'Sollaikkolaimedu', NULL),
(213, 'USR4PO31VQFU', 'Ravi Bus', 10.00, 2503.00, 28, 2493.00, '🚗Travel ', 'Cash', '2026-11-17', '09:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-17 04:01:57', '2026-11-17 04:01:57', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL);
INSERT INTO `expenses` (`id`, `user_id`, `title`, `expense_amount`, `transfer_amount`, `transfer_id`, `remaining_amount`, `category`, `payment_method`, `expense_date`, `expense_time`, `notes`, `recurring`, `attachment`, `created_by`, `updated_by`, `created_at`, `updated_at`, `from`, `to`, `location`, `travel_time`) VALUES
(214, 'USR4PO31VQFU', 'Biscuit  2  Time Pass Shop', 10.00, 140.00, 25, 130.00, '🍔 Food', 'Cash', '2026-11-17', '09:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-17 04:02:47', '2026-11-17 04:02:47', NULL, NULL, 'Vengateshware Nagar', NULL),
(215, 'USR4PO31VQFU', 'Government Bus', 36.00, 2493.00, 28, 2457.00, '🚗Travel', 'UPI', '2026-11-17', '18:33:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-17 13:03:58', '2026-11-17 13:03:58', 'Tirupathur', 'Ambur', NULL, NULL),
(216, 'USR4PO31VQFU', 'Bike Parking', 20.00, 500.00, 26, 480.00, '🏍️ Bike Parking', 'Cash', '2026-11-18', '07:55:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-18 02:47:40', '2026-11-18 02:47:40', NULL, NULL, 'Ambur', NULL),
(217, 'USR4PO31VQFU', 'Government Bus', 25.00, 2457.00, 28, 2432.00, '🚗Travel', 'UPI', '2026-11-18', '08:17:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-18 02:48:43', '2026-11-18 02:48:43', 'Ambur', 'Tirupathur', NULL, NULL),
(218, 'USR4PO31VQFU', 'Ravi Shop', 5.00, 240.00, 24, 235.00, '💡 Bills & Utilities', 'Cash', '2026-11-18', '06:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-18 03:28:50', '2026-11-18 03:28:50', NULL, NULL, 'Sollaikkolaimedu', NULL),
(219, 'USR4PO31VQFU', 'PVK Bus', 10.00, 2432.00, 28, 2422.00, '🚗Travel', 'Cash', '2026-11-18', '21:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-18 12:47:30', '2026-11-18 12:47:30', 'Tirupathur', 'Vengateahwara Nagar', NULL, NULL),
(220, 'USR4PO31VQFU', 'Government Bus', 25.00, 2422.00, 28, 2397.00, '🚗Travel', 'UPI', '2026-11-18', '18:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-18 12:48:50', '2026-11-18 12:48:50', 'Tirupathur', 'Ambur', NULL, NULL),
(221, 'USR4PO31VQFU', 'Bike Parking', 20.00, 480.00, 26, 460.00, '🏍️ Bike Parking', 'Cash', '2026-11-19', '07:55:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-19 02:40:37', '2026-11-19 02:40:37', NULL, NULL, 'Ambur', NULL),
(222, 'USR4PO31VQFU', 'Government Bus', 25.00, 2397.00, 28, 2372.00, '🚗Travel', 'UPI', '2026-11-19', '08:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-19 02:41:21', '2026-11-19 02:41:21', 'Ambur', 'Tirupathur', NULL, NULL),
(223, 'USR4PO31VQFU', 'Vadai', 10.00, 130.00, 25, 120.00, '🍔 Food', 'Cash', '2026-11-19', '09:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-19 04:21:01', '2026-11-19 04:21:01', NULL, NULL, 'Vengateshware Nagar', NULL),
(224, 'USR4PO31VQFU', 'Ravi Bus', 10.00, 2372.00, 28, 2362.00, '🚗Travel ', 'Cash', '2026-11-19', '09:00:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-19 04:22:24', '2026-11-19 04:22:24', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(225, 'USR4PO31VQFU', 'Government Bus', 7.00, 2362.00, 28, 2355.00, '🚗Travel', 'UPI', '2026-11-19', '18:18:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-19 12:49:20', '2026-11-19 12:49:20', 'Vengateahwara Nagar', 'Tirupathur', NULL, NULL),
(226, 'USR4PO31VQFU', 'Government Bus', 36.00, 2355.00, 28, 2319.00, '🚗Travel', 'UPI', '2026-11-19', '18:54:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-19 13:25:38', '2026-11-19 13:25:38', 'Tirupathur', 'Ambur', NULL, NULL),
(227, 'USR4PO31VQFU', 'Bike Parking', 20.00, 460.00, 26, 440.00, '🏍️ Bike Parking', 'Cash', '2026-11-20', '08:07:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-20 02:37:42', '2026-11-20 02:37:42', NULL, NULL, 'Ambur', NULL),
(228, 'USR4PO31VQFU', 'Government Bus', 25.00, 2319.00, 28, 2294.00, '🚗Travel', 'UPI', '2026-11-20', '08:07:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-20 02:38:16', '2026-11-20 02:38:16', 'Ambur', 'Tirupathur', NULL, NULL),
(229, 'USR4PO31VQFU', 'Dhosai 2 One Plate', 30.00, 120.00, 25, 90.00, '🍔 Food', 'UPI', '2026-11-20', '09:19:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-20 03:49:47', '2026-11-20 03:49:47', NULL, NULL, 'Tirupathur', NULL),
(230, 'USR4PO31VQFU', 'Ponni Bus', 10.00, 2294.00, 28, 2284.00, '🚗Travel ', 'Cash', '2026-11-20', '10:44:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-20 05:15:57', '2026-11-20 05:15:57', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(231, 'USR4PO31VQFU', 'Government Bus', 8.00, 2284.00, 28, 2276.00, '🚗Travel', 'Cash', '2026-11-20', '18:05:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-20 12:47:07', '2026-11-20 12:47:07', 'Vengateahwara Nagar', 'Tirupathur', NULL, NULL),
(232, 'USR4PO31VQFU', 'Government Bus', 25.00, 2276.00, 28, 2251.00, '🚗Travel', 'UPI', '2026-11-20', '18:42:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-20 13:13:44', '2026-11-20 13:13:44', 'Tirupathur', 'Ambur', NULL, NULL),
(233, 'USR4PO31VQFU', 'Government Bus', 25.00, 2251.00, 28, 2226.00, '🚗Travel ', 'Cash', '2026-11-23', '08:10:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-23 04:11:41', '2026-11-23 04:11:41', 'Ambur', 'Tirupathur', NULL, NULL),
(234, 'USR4PO31VQFU', 'Ponni Bus', 10.00, 2226.00, 28, 2216.00, '🚗Travel ', 'Cash', '2026-11-23', '09:20:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-23 04:12:10', '2026-11-23 04:12:10', 'Tirupattur', 'Vengateshware Nagar', NULL, NULL),
(235, 'USR4PO31VQFU', 'Petrol', 330.00, 1170.00, 27, 840.00, '⛽ Fuel', 'UPI', '2026-11-20', '19:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-23 04:19:03', '2026-11-23 04:19:03', NULL, NULL, 'Ambur', NULL),
(236, 'USR4PO31VQFU', 'Hire Check', 10.00, 235.00, 24, 225.00, '💡 Bills & Utilities', 'Cash', '2026-11-20', '20:00:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-23 04:20:10', '2026-11-23 04:20:10', NULL, NULL, 'Ambur', NULL),
(237, 'USR4PO31VQFU', 'Bike Parking', 20.00, 440.00, 26, 420.00, '🏍️ Bike Parking', 'Cash', '2026-11-23', '07:57:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-23 04:21:54', '2026-11-23 04:21:54', NULL, NULL, 'Ambur', NULL),
(238, 'USR4PO31VQFU', 'Tablet Soap', 360.00, 1225.00, 24, 865.00, '💊 Health', 'UPI', '2026-11-21', '12:44:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-23 06:16:01', '2026-11-23 06:16:01', NULL, NULL, 'Ambur', NULL),
(239, 'USR4PO31VQFU', 'Ice Cream', 10.00, 90.00, 25, 80.00, '🍔 Food', 'Cash', '2026-11-21', '12:55:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-23 06:16:49', '2026-11-23 06:16:49', NULL, NULL, 'Ambur', NULL),
(240, 'USR4PO31VQFU', 'Baji Ponda', 20.00, 80.00, 25, 60.00, '🍔 Food', 'Cash', '2026-11-21', '13:00:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-23 06:17:46', '2026-11-23 06:17:46', NULL, NULL, 'Ambur', NULL),
(241, 'USR4PO31VQFU', 'Egg', 20.00, 60.00, 25, 40.00, '🍔 Food', 'Cash', '2026-11-22', '14:30:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-23 06:18:32', '2026-11-23 06:18:32', NULL, NULL, 'Sollaikkolaimedu', NULL),
(242, 'USR4PO31VQFU', 'Sanmuga Bus', 10.00, 2216.00, 28, 2206.00, '🚗Travel', 'Cash', '2026-11-23', '17:50:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-24 04:22:54', '2026-11-24 04:22:54', 'Vengateahwara Nagar', 'Tirupathur', NULL, NULL),
(243, 'USR4PO31VQFU', 'Government Bus', 36.00, 2206.00, 28, 2170.00, '🚗Travel', 'Cash', '2026-11-23', '18:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-24 04:23:57', '2026-11-24 04:23:57', 'Tirupathur', 'Ambur', NULL, NULL),
(244, 'USR4PO31VQFU', 'Role', 20.00, 40.00, 25, 20.00, '🍔 Food', 'Cash', '2026-11-23', '19:05:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-24 04:24:40', '2026-11-24 04:24:40', NULL, NULL, 'Ambur', NULL),
(245, 'USR4PO31VQFU', 'Bike Parking', 20.00, 420.00, 26, 400.00, '🏍️ Bike Parking', 'Cash', '2026-11-24', '07:55:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-24 04:26:21', '2026-11-24 04:26:21', NULL, NULL, 'Ambur', NULL),
(246, 'USR4PO31VQFU', 'Government Bus', 25.00, 2170.00, 28, 2145.00, '🚗Travel', 'Cash', '2026-11-24', '08:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-24 04:27:21', '2026-11-24 04:27:21', 'Ambur', 'Tirupathur', NULL, NULL),
(247, 'USR4PO31VQFU', 'JMS Bus', 10.00, 2145.00, 28, 2135.00, '🚗Travel', 'Cash', '2026-11-24', '09:15:00', NULL, 'No', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-24 04:28:11', '2026-11-24 04:28:11', 'Tirupathur', 'Vengateahwara Nagar', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `income`
--

CREATE TABLE `income` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `remaining_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `monthly_budget` decimal(12,2) NOT NULL DEFAULT 0.00,
  `category` varchar(100) NOT NULL,
  `income_date` date NOT NULL,
  `payment_method` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `recurring` enum('Yes','No') NOT NULL DEFAULT 'No',
  `attachment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `income`
--

INSERT INTO `income` (`id`, `user_id`, `title`, `amount`, `remaining_amount`, `monthly_budget`, `category`, `income_date`, `payment_method`, `notes`, `recurring`, `attachment`, `created_at`, `created_by`, `updated_by`, `updated_at`) VALUES
(1, 'USR4PO31VQFU', 'Salary', 14500.00, 318.00, 14500.00, '💼 Salary', '2026-10-10', 'UPI', NULL, 'No', '/uploads/income-receipts/1790573093626-467490825.png', '2026-09-28 05:24:53', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-10 04:07:10'),
(9, 'USR4PO31VQFU', 'November Salary', 15000.00, 630.00, 15000.00, '💼 Salary', '2026-11-10', 'UPI', NULL, 'No', NULL, '2026-11-05 11:17:15', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-23 05:06:36');

-- --------------------------------------------------------

--
-- Table structure for table `memories`
--

CREATE TABLE `memories` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `category_name` varchar(120) DEFAULT NULL,
  `category_color` varchar(30) DEFAULT '#8B5CF6',
  `memory_date` date NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `mood` varchar(80) DEFAULT 'Happy',
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags`)),
  `status` enum('published','draft') DEFAULT 'published',
  `is_favorite` tinyint(1) DEFAULT 0,
  `media_url` varchar(500) DEFAULT NULL,
  `media_gallery` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`media_gallery`)),
  `media_type` varchar(50) DEFAULT 'image',
  `voice_note` text DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `memories`
--

INSERT INTO `memories` (`id`, `user_id`, `title`, `description`, `category_id`, `category_name`, `category_color`, `memory_date`, `location`, `mood`, `tags`, `status`, `is_favorite`, `media_url`, `media_gallery`, `media_type`, `voice_note`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'USR4PO31VQFU', 'Birthday', '', 33, '📸 Photos', '#8B5CF6', '2026-09-28', 'Chennai ', 'Happy', '[]', 'published', 1, '/uploads/memories/images/1790592062417-IMG-20260919-WA0006.jpg', '[\"/uploads/memories/images/1790592062417-IMG-20260919-WA0006.jpg\",\"/uploads/memories/images/1790592062417-IMG-20260917-WA0037.jpg\",\"/uploads/memories/images/1790592062417-IMG-20260917-WA0038.jpg\",\"/uploads/memories/images/1790592062428-IMG-20260913-WA0006.jpg\",\"/uploads/memories/images/1790592062428-IMG-20260913-WA0005.jpg\",\"/uploads/memories/images/1790592062429-1788938874592.jpg\",\"/uploads/memories/images/1790592062435-1788938726725.jpg\",\"/uploads/memories/images/1790592062439-1788915076850.jpg\",\"/uploads/memories/images/1790592062440-1788914832577.jpg\",\"/uploads/memories/images/1790592062442-IMG-20260908-WA0012.jpg\"]', 'image', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-28 10:41:02', '2026-09-28 10:42:36'),
(2, 'USR4PO31VQFU', 'gjgjgkuk', '', 34, '🌅 Other', '#8B5CF6', '2026-09-28', '', 'Happy', '[\"hkjjk\"]', 'published', 1, '/uploads/memories/videos/1790592354472-InShot_20260830_132815867.mp4', '[\"/uploads/memories/videos/1790592354472-InShot_20260830_132815867.mp4\"]', 'video', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-28 10:45:54', '2026-09-29 06:55:10'),
(3, 'USR4PO31VQFU', 'Food', '', 34, '🌅 Other', '#8B5CF6', '2026-09-29', '', 'Happy', '[]', 'published', 1, '/uploads/memories/videos/1790651382635-VID_28350415_092302_626.mp4', '[\"/uploads/memories/videos/1790651382635-VID_28350415_092302_626.mp4\",\"/uploads/memories/videos/1790651382684-MBit_Music-270325-061535.mp4\",\"/uploads/memories/videos/1790651382760-MBit_Music-241024-122231.mp4\",\"/uploads/memories/audio/1790651382805-AUD-20250607-WA0070.mp3\",\"/uploads/memories/audio/1790651382816-AUD-20250607-WA0071.mp3\",\"/uploads/memories/videos/1790651382819-voice-note-1790651036584.webm\"]', 'video', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-29 03:04:12', '2026-09-29 06:55:11'),
(4, 'USR4PO31VQFU', 'By', 'fdgdgdf', 33, '📸 Photos', '#8B5CF6', '2026-09-30', 'Tirupattur', 'Happy', '[]', 'published', 0, '/uploads/memories/images/1790757767522-Screenshot_2026-09-28_114537.png', '[\"/uploads/memories/images/1790757767522-Screenshot_2026-09-28_114537.png\",\"/uploads/memories/images/1790757767523-Screenshot_2026-09-28_115153.png\",\"/uploads/memories/images/1790757767523-Screenshot_2026-09-28_115220.png\",\"/uploads/memories/images/1790757767523-Screenshot_2026-09-28_115228.png\",\"/uploads/memories/videos/1790757767523-voice-note-1790757725121.webm\",\"/uploads/memories/files/1790757767524-Backend.zip\"]', 'image', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-30 08:42:22', '2026-09-30 08:42:54'),
(6, 'USR4PO31VQFU', 'Xhdhdh', 'Shdhhd', 34, '🌅 Other', '#8B5CF6', '2026-10-01', 'Xhdhhd', 'Happy', '[]', 'published', 0, '', '[]', 'image', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-01 10:21:44', '2026-10-01 10:21:44'),
(8, 'USR4PO31VQFU', 'Dhxbxb', 'Xbxbxbbz', 34, '🌅 Other', '#8B5CF6', '2026-10-06', 'Bsbzbx', 'Happy', '[\"Zbxbxb\"]', 'published', 0, '/uploads/memories/images/1791288760797-IMG-20261005-WA0000.jpg', '[\"/uploads/memories/images/1791288760797-IMG-20261005-WA0000.jpg\"]', 'image', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 12:12:35', '2026-10-06 12:12:40'),
(9, 'USR4PO31VQFU', 'Xnxbxbxb', 'Bzbxbxb', 34, '🌅 Other', '#8B5CF6', '2026-10-06', 'Bdbzbxb', 'Happy', '[\"Dbxbxb\"]', 'published', 1, '/uploads/memories/images/1791289307096-IMG-20261005-WA0000.jpg', '[\"/uploads/memories/images/1791289307096-IMG-20261005-WA0000.jpg\"]', 'image', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-06 12:21:41', '2026-10-07 03:32:25'),
(12, 'USR4PO31VQFU', 'Food', 'Cvbvvbbbb', 34, '🌅 Other', '#8B5CF6', '2026-10-07', 'Sollitu ', 'Happy', '[]', 'published', 1, '', '[]', 'image', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-07 03:29:52', '2026-10-24 02:36:36'),
(18, 'USR4PO31VQFU', 'Go', 'Fhjhh', 34, '🌅 Other', '#8B5CF6', '2026-10-09', '', 'Happy', '[]', 'published', 1, '/uploads/memories/images/1791537735612-Screenshot_2026-10-09-14-46-21-362_com_anonymous_lifeledger.jpg', '[\"/uploads/memories/images/1791537735612-Screenshot_2026-10-09-14-46-21-362_com_anonymous_lifeledger.jpg\",\"/uploads/memories/images/1791537735614-Screenshot_2026-10-09-12-13-31-926_host_exp_exponent.jpg\",\"/uploads/memories/images/1791537735615-Screenshot_2026-10-09-12-02-50-804_host_exp_exponent.jpg\",\"/uploads/memories/images/1791537735617-Screenshot_2026-10-09-09-06-57-484_com_instagram_android.jpg\",\"/uploads/memories/videos/1791537735620-kalyana_virunthu_________illayaraja_lyrics_shorts_youtubeshorts_trending_whatsappstatus_fyp_viral_like_1080p.mp4\"]', 'image', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 09:20:48', '2026-10-24 02:36:34'),
(19, 'USR4PO31VQFU', 'Thenuga', 'Hxhxhxhx', 34, '🌅 Other', '#8B5CF6', '2026-10-13', 'Ambur ', 'Happy', '[]', 'published', 1, '/uploads/memories/images/1791887634507-Screenshot_2026-10-13-15-49-10-661_host_exp_exponent.jpg', '[\"/uploads/memories/images/1791887634507-Screenshot_2026-10-13-15-49-10-661_host_exp_exponent.jpg\",\"/uploads/memories/images/1791887634509-IMG-20261013-WA0003.jpg\",\"/uploads/memories/images/1791887634510-IMG-20261013-WA0002.jpg\",\"/uploads/memories/images/1791887634513-IMG-20261013-WA0001.jpg\",\"/uploads/memories/images/1791887634514-Screenshot_2026-10-13-08-03-37-715_com_anonymous_lifeledger.jpg\",\"/uploads/memories/images/1791887634516-Screenshot_2026-10-12-22-34-13-188_com_instagram_android.jpg\"]', 'image', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-13 10:33:41', '2026-10-24 02:36:31'),
(20, 'USR4PO31VQFU', 'Xbxbxbbx', 'Bzbxbxbz', 32, '👥 Friends', '#8B5CF6', '2026-10-23', '', 'Happy', '[]', 'published', 1, '/uploads/memories/audio/1792740014463-voice-note-1792740001585.m4a', '[\"/uploads/memories/audio/1792740014463-voice-note-1792740001585.m4a\",\"/uploads/memories/images/1792740014464-Screenshot_2026-10-23-12-43-49-157_host_exp_exponent.jpg\"]', 'audio', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-23 07:20:12', '2026-11-11 12:52:53'),
(21, 'USR4PO31VQFU', 'Good morning 🌞', 'Bdbxbxb', 34, '🌅 Other', '#8B5CF6', '2026-11-11', 'Ambur ', 'Happy', '[]', 'published', 0, '', '[]', 'image', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-11 12:54:21', '2026-11-11 12:54:21'),
(22, 'USR4PO31VQFU', 'Djjxbxbx', 'Djxhxb', 31, '🎉 Celebration', '#8B5CF6', '2026-11-13', 'Djxbbxbxb', 'Happy', '[\"Xnxbxb\"]', 'published', 0, '', '[]', 'image', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-13 05:16:10', '2026-11-13 05:16:11'),
(23, 'USR4PO31VQFU', 'Dhiva', 'gjgfjfj', 34, '🌅 Other', '#8B5CF6', '2026-11-24', 'fgjfgj', 'Happy', '[\"gjfgj\"]', 'published', 1, '/uploads/memories/images/1795504424283-WhatsApp_Image_2026-11-24_at_11_50_00_AM.jpeg', '[\"/uploads/memories/images/1795504424283-WhatsApp_Image_2026-11-24_at_11_50_00_AM.jpeg\",\"/uploads/memories/images/1795504424285-Modern_Portrait_with_Orange_Desk_Glow.png\",\"/uploads/memories/images/1795504424303-Thoughtful_Workspace_with_Orange_Halo.png\",\"/uploads/memories/images/1795504424318-Focused_Professional_at_Laptop.png\",\"/uploads/memories/videos/1795504424326-2.mp4\",\"/uploads/memories/videos/1795504424400-voice-note-1795504274742.webm\",\"/uploads/memories/videos/1795504424405-voice-note-1795504285319.webm\"]', 'image', '', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-24 07:12:16', '2026-11-24 07:13:55');

-- --------------------------------------------------------

--
-- Table structure for table `todo_tasks`
--

CREATE TABLE `todo_tasks` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('Pending','In Progress','Completed') NOT NULL DEFAULT 'Pending',
  `priority` enum('High','Medium','Low') NOT NULL DEFAULT 'Medium',
  `due_date` date DEFAULT NULL,
  `reminder_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `amount` decimal(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `todo_tasks`
--

INSERT INTO `todo_tasks` (`id`, `user_id`, `title`, `description`, `status`, `priority`, `due_date`, `reminder_at`, `created_at`, `updated_at`, `amount`) VALUES
(5, 'USR4PO31VQFU', 'Salary', NULL, 'Completed', 'High', '2026-10-12', '2026-10-12 18:37:00', '2026-10-12 13:07:13', '2026-11-04 02:49:39', NULL),
(6, 'USR4PO31VQFU', 'ATM WITHDRAWAL', '3200', 'Completed', 'Medium', '2026-10-13', '2026-10-13 06:45:00', '2026-10-13 02:41:02', '2026-11-04 02:49:41', NULL),
(7, 'USR4PO31VQFU', 'My Account Balance', '23644', 'Completed', 'High', '2026-10-12', '2026-10-12 18:30:00', '2026-10-13 13:00:30', '2026-11-16 02:35:00', NULL),
(8, 'USR4PO31VQFU', 'ATM Withdrawal', '500', 'Completed', 'Medium', '2026-10-19', '2026-10-19 07:45:00', '2026-10-19 02:35:57', '2026-11-04 02:49:43', NULL),
(9, 'USR4PO31VQFU', 'ATM WITHDRAWAL', '500', 'Completed', 'Medium', '2026-10-23', '2026-10-23 19:50:00', '2026-10-23 07:51:53', '2026-11-04 02:49:43', NULL),
(10, 'USR4PO31VQFU', 'My father Give', '100', 'Completed', 'Medium', '2026-10-24', '2026-10-24 18:46:00', '2026-10-24 13:16:32', '2026-11-04 02:49:45', NULL),
(12, 'USR4PO31VQFU', 'ATM WITHDRAWAL', NULL, 'Completed', 'Medium', '2026-10-31', '2026-10-31 09:05:00', '2026-10-31 03:35:54', '2026-11-16 02:35:03', 200.00),
(13, 'USR4PO31VQFU', 'ATM WITHDRAWAL', '300', 'Completed', 'Medium', '2026-11-04', '2026-11-04 07:40:00', '2026-11-04 02:49:05', '2026-11-16 02:34:39', NULL),
(15, 'USR4PO31VQFU', 'Nishanth bro', NULL, 'Pending', 'High', '2026-11-04', '2026-11-04 17:50:00', '2026-11-04 13:03:57', '2026-11-05 11:15:41', 500.00),
(16, 'USR4PO31VQFU', 'Nishanth bro', NULL, 'Pending', 'Medium', '2026-11-06', '2026-11-06 17:19:00', '2026-11-06 11:49:31', '2026-11-06 11:49:31', 1500.00),
(17, 'USR4PO31VQFU', 'Bike Parking 20  and 32 days', NULL, 'Pending', 'Medium', '2026-11-01', '2026-11-01 20:30:00', '2026-11-15 07:01:22', '2026-11-15 07:01:22', 640.00),
(18, 'USR4PO31VQFU', 'Tirupathur To Vengateahwara Nagar', NULL, 'Pending', 'Medium', '2026-11-01', '2026-11-01 12:32:00', '2026-11-15 07:02:29', '2026-11-15 07:02:29', 640.00),
(19, 'USR4PO31VQFU', 'Ambur to Tirupathur', NULL, 'Pending', 'Medium', '2026-11-01', '2026-11-01 12:34:00', '2026-11-15 07:04:06', '2026-11-15 07:04:06', 2304.00),
(20, 'USR4PO31VQFU', 'Petrol', NULL, 'Pending', 'Medium', '2026-11-01', '2026-11-01 12:35:00', '2026-11-15 07:05:53', '2026-11-15 07:05:53', 1520.00),
(21, 'USR4PO31VQFU', 'EMI Loan', NULL, 'Completed', 'Medium', NULL, NULL, '2026-11-15 07:07:01', '2026-11-15 07:11:26', 4710.00),
(22, 'USR4PO31VQFU', 'Chittu', NULL, 'Completed', 'Medium', NULL, NULL, '2026-11-15 07:07:38', '2026-11-15 07:11:25', 3000.00),
(23, 'USR4PO31VQFU', 'Mobile Recharge', NULL, 'Pending', 'Medium', '2026-11-01', '2026-11-01 12:38:00', '2026-11-15 07:08:37', '2026-11-15 07:08:37', 300.00),
(24, 'USR4PO31VQFU', 'Food', NULL, 'Pending', 'Medium', '2026-11-01', '2026-11-01 12:39:00', '2026-11-15 07:09:26', '2026-11-15 07:09:26', 300.00),
(25, 'USR4PO31VQFU', 'Personal', NULL, 'Pending', 'Medium', NULL, NULL, '2026-11-15 07:09:40', '2026-11-15 07:09:40', 300.00),
(26, 'USR4PO31VQFU', 'Nishanth Bro', NULL, 'Pending', 'Medium', '2026-11-15', '2026-11-15 08:04:00', '2026-11-16 02:34:27', '2026-11-16 02:34:27', 10000.00);

-- --------------------------------------------------------

--
-- Table structure for table `transfers`
--

CREATE TABLE `transfers` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `remaining_amount` decimal(12,2) DEFAULT NULL,
  `source_income_id` int(11) DEFAULT NULL,
  `category` varchar(100) NOT NULL,
  `transfer_from` varchar(100) NOT NULL,
  `transfer_to` varchar(100) NOT NULL,
  `transfer_date` date NOT NULL,
  `payment_method` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `receipt` varchar(500) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `parent_transfer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transfers`
--

INSERT INTO `transfers` (`id`, `user_id`, `title`, `amount`, `remaining_amount`, `source_income_id`, `category`, `transfer_from`, `transfer_to`, `transfer_date`, `payment_method`, `notes`, `receipt`, `created_by`, `updated_by`, `created_at`, `updated_at`, `parent_transfer_id`) VALUES
(1, 'USR4PO31VQFU', '📱 Mobile Recharge', 310.00, 0.00, 1, '📱 Mobile Recharge', 'Account', 'Account', '2026-10-21', 'UPI', NULL, '/uploads/transfer-receipts/1790573156757-ChatGPT_Image_Sep_24__2026__10_38_27_AM.png', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-28 05:25:56', '2026-11-04 06:46:36', NULL),
(2, 'USR4PO31VQFU', '💳 EMI / Loan', 4730.00, 0.00, 1, '💳 EMI / Loan', 'Account', 'Account', '2026-09-28', 'Cash', NULL, NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-28 05:27:36', '2026-11-04 07:00:06', NULL),
(3, 'USR4PO31VQFU', '📈 Investment Chit Amount', 3000.00, 0.00, 1, '💵 Other Expenses', 'Account', 'Account', '2026-10-15', 'Cash', NULL, NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-28 05:29:00', '2026-10-15 02:45:58', NULL),
(4, 'USR4PO31VQFU', '🍔 Food & Dining', 745.00, 0.00, 1, '🍔 Food / Dining', 'Account', 'Account', '2026-10-01', 'UPI', '', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-28 05:50:10', '2026-11-09 06:58:14', NULL),
(5, 'USR4PO31VQFU', '🚗 Transport', 2115.00, 0.00, 1, '🚌 Travel', 'Account', 'Account', '2026-09-30', 'UPI', '', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-28 05:53:04', '2026-11-10 04:07:10', NULL),
(6, 'USR4PO31VQFU', '⛽ Fuel', 1630.00, 0.00, 1, '⛽ Fuel', 'Account', 'Account', '2026-10-01', 'Cash', NULL, NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-28 05:54:05', '2026-11-09 07:05:52', NULL),
(7, 'USR4PO31VQFU', '🅿️ BNS Bike Parking / Bike Stand', 600.00, 0.00, 1, '💵 Other Expenses', 'Account', 'Account', '2026-10-01', 'UPI', '', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-28 05:55:08', '2026-11-09 04:15:39', NULL),
(8, 'USR4PO31VQFU', '🥜 Dry Fruits', 500.00, 0.00, 1, '💵 Other Expenses', 'Account', 'Account', '2026-10-01', 'UPI', NULL, NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-09-28 06:05:41', '2026-11-02 09:26:06', NULL),
(20, 'USR4PO31VQFU', '👤 Personal Expense', 1540.00, 0.00, 1, '👨‍👩‍👧 Family Expenses', 'Account', 'Account', '2026-10-02', 'Cash', NULL, NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-02 08:18:37', '2026-11-09 07:05:41', NULL),
(21, 'USR4PO31VQFU', '📱 Mobile Recharge', 300.00, 300.00, 9, '📱 Mobile Recharge', 'Account', 'Account', '2026-11-10', 'UPI', NULL, NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-05 11:20:54', '2026-11-05 11:20:54', NULL),
(22, 'USR4PO31VQFU', '💳 EMI / Loan', 4500.00, 0.00, 9, '💳 EMI / Loan', 'Account', 'Account', '2026-11-05', 'Cash', NULL, NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 04:07:48', '2026-11-09 07:02:16', NULL),
(23, 'USR4PO31VQFU', '📈 Investment Chit Amount', 3000.00, 0.00, 9, '📈 Investment Chit', 'Account', 'Account', '2026-11-15', 'Cash', NULL, NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 04:39:23', '2026-11-17 03:26:42', NULL),
(24, 'USR4PO31VQFU', '👤 Personal Expense', 1300.00, 865.00, 9, '👨‍👩‍👧 Family Expenses', 'Account', 'Account', '2026-11-09', 'UPI', NULL, NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 04:40:03', '2026-11-23 06:16:01', NULL),
(25, 'USR4PO31VQFU', '🍔 Food', 300.00, 20.00, 9, '🍔 Food / Dining', 'Account', 'Account', '2026-11-09', 'UPI', NULL, NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 04:40:35', '2026-11-24 04:24:40', NULL),
(26, 'USR4PO31VQFU', '🅿️ BNS Bike Parking / Bike Stand', 620.00, 400.00, 9, '🏍️ Bike Parking', 'Account', 'Account', '2026-11-09', 'Cash', '', NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 04:44:51', '2026-11-24 04:26:21', NULL),
(27, 'USR4PO31VQFU', '⛽ Fuel', 1500.00, 840.00, 9, '⛽ Fuel', 'Account', 'Account', '2026-11-09', 'Cash', NULL, NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 04:46:26', '2026-11-23 04:19:03', NULL),
(28, 'USR4PO31VQFU', '🚗 Transport', 2850.00, 2135.00, 9, '🚌 Travel', 'Account', 'Account', '2026-11-09', 'Cash', NULL, NULL, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 04:48:58', '2026-11-24 04:28:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transfer_adjustments`
--

CREATE TABLE `transfer_adjustments` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `transfer_id` int(11) NOT NULL,
  `income_id` int(11) NOT NULL,
  `previous_amount` decimal(12,2) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `purpose` varchar(120) NOT NULL,
  `reason` text DEFAULT NULL,
  `transfer_date` date NOT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transfer_adjustments`
--

INSERT INTO `transfer_adjustments` (`id`, `user_id`, `transfer_id`, `income_id`, `previous_amount`, `amount`, `total_amount`, `purpose`, `reason`, `transfer_date`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(6, 'USR4PO31VQFU', 20, 1, 200.00, 100.00, 300.00, 'No Reason', NULL, '2026-10-09', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-09 06:01:16', '2026-10-09 06:01:16'),
(7, 'USR4PO31VQFU', 20, 1, 300.00, 550.00, 850.00, 'Expense', NULL, '2026-10-17', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-17 04:32:46', '2026-10-17 04:32:46'),
(8, 'USR4PO31VQFU', 20, 1, 850.00, 230.00, 1080.00, 'Expense', NULL, '2026-10-17', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-17 04:56:34', '2026-10-17 04:56:34'),
(9, 'USR4PO31VQFU', 20, 1, 1080.00, 150.00, 1230.00, 'Expense', NULL, '2026-10-19', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-19 07:13:00', '2026-10-19 07:13:00'),
(10, 'USR4PO31VQFU', 4, 1, 500.00, 10.00, 510.00, 'Expense', NULL, '2026-10-28', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-28 05:16:08', '2026-10-28 05:16:08'),
(11, 'USR4PO31VQFU', 4, 1, 510.00, 100.00, 610.00, 'Expense', NULL, '2026-10-29', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-29 06:29:36', '2026-10-29 06:29:36'),
(12, 'USR4PO31VQFU', 20, 1, 1230.00, 50.00, 1280.00, 'Expense', NULL, '2026-10-30', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-30 13:21:31', '2026-10-30 13:21:31'),
(13, 'USR4PO31VQFU', 5, 1, 1700.00, 100.00, 1800.00, 'Expense', NULL, '2026-11-02', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-02 05:09:12', '2026-11-02 05:09:12'),
(14, 'USR4PO31VQFU', 6, 1, 1350.00, 80.00, 1430.00, 'Expense', NULL, '2026-11-02', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-02 05:10:43', '2026-11-02 05:10:43'),
(15, 'USR4PO31VQFU', 20, 1, 1280.00, 20.00, 1300.00, 'Expense', NULL, '2026-11-02', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-02 05:18:38', '2026-11-02 05:18:38'),
(16, 'USR4PO31VQFU', 6, 1, 1430.00, 200.00, 1630.00, 'Expense', NULL, '2026-11-02', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-02 09:25:24', '2026-11-02 09:25:24'),
(17, 'USR4PO31VQFU', 5, 1, 1800.00, 10.00, 1810.00, 'Expense', NULL, '2026-11-04', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 05:51:47', '2026-11-04 05:51:47'),
(18, 'USR4PO31VQFU', 5, 1, 1810.00, 9.99, 1819.99, 'Expense', NULL, '2026-11-04', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 06:26:03', '2026-11-04 06:26:03'),
(19, 'USR4PO31VQFU', 1, 1, 300.00, 10.00, 310.00, '📱 Mobile Recharge', 'Goo', '2026-10-22', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 06:45:17', '2026-11-04 06:45:17'),
(20, 'USR4PO31VQFU', 5, 1, 1819.99, 100.00, 1919.99, '🚌 Travel', 'Travel', '2026-09-30', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 06:50:19', '2026-11-04 06:50:19'),
(21, 'USR4PO31VQFU', 2, 1, 4710.00, 10.00, 4720.00, '💳 EMI / Loan', 'Good', '2026-09-28', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 06:54:14', '2026-11-04 06:54:14'),
(22, 'USR4PO31VQFU', 2, 1, 4720.00, 10.00, 4730.00, '💳 EMI / Loan', 'G', '2026-09-28', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 06:58:39', '2026-11-04 06:58:39'),
(23, 'USR4PO31VQFU', 7, 1, 500.00, 100.00, 600.00, 'Expense', NULL, '2026-11-04', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 08:15:02', '2026-11-04 08:15:02'),
(24, 'USR4PO31VQFU', 5, 1, 1919.99, 150.00, 2069.99, 'Expense', NULL, '2026-11-04', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 08:17:00', '2026-11-04 08:17:00'),
(25, 'USR4PO31VQFU', 20, 1, 1300.00, 190.00, 1490.00, 'Expense', NULL, '2026-11-04', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 08:24:09', '2026-11-04 08:24:09'),
(26, 'USR4PO31VQFU', 20, 1, 1490.00, 50.00, 1540.00, 'Expense', NULL, '2026-11-04', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 10:22:17', '2026-11-04 10:22:17'),
(27, 'USR4PO31VQFU', 4, 1, 610.00, 105.00, 715.00, 'Expense', NULL, '2026-11-06', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-06 07:29:51', '2026-11-06 07:29:51'),
(28, 'USR4PO31VQFU', 5, 1, 2069.99, 2.00, 2071.99, 'Expense', NULL, '2026-11-09', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 04:52:29', '2026-11-09 04:52:29'),
(29, 'USR4PO31VQFU', 5, 1, 2071.99, 43.01, 2115.00, 'Expense', NULL, '2026-11-09', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 06:56:20', '2026-11-09 06:56:20'),
(30, 'USR4PO31VQFU', 4, 1, 715.00, 30.00, 745.00, 'Expense', NULL, '2026-11-09', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 06:57:26', '2026-11-09 06:57:26'),
(31, 'USR4PO31VQFU', 24, 9, 300.00, 1000.00, 1300.00, 'Expense', NULL, '2026-11-23', 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-23 05:06:36', '2026-11-23 05:06:36');

-- --------------------------------------------------------

--
-- Table structure for table `transfer_allocations`
--

CREATE TABLE `transfer_allocations` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `transfer_id` int(11) NOT NULL,
  `previous_amount` decimal(12,2) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `remaining_amount` decimal(12,2) NOT NULL,
  `purpose` varchar(120) NOT NULL,
  `reason` text DEFAULT NULL,
  `transfer_date` date NOT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transfer_fundings`
--

CREATE TABLE `transfer_fundings` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `transfer_id` int(11) NOT NULL,
  `income_id` int(11) NOT NULL,
  `previous_amount` decimal(12,2) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `remaining_amount` decimal(12,2) NOT NULL,
  `purpose` varchar(120) NOT NULL,
  `reason` text DEFAULT NULL,
  `transfer_date` date NOT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transfer_returns`
--

CREATE TABLE `transfer_returns` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `transfer_id` int(11) NOT NULL,
  `income_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transfer_returns`
--

INSERT INTO `transfer_returns` (`id`, `user_id`, `transfer_id`, `income_id`, `amount`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(2, 'USR4PO31VQFU', 2, 1, 210.00, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-10-29 06:28:19', '2026-10-29 06:28:19'),
(3, 'USR4PO31VQFU', 8, 1, 500.00, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-02 09:26:06', '2026-11-02 09:26:06'),
(4, 'USR4PO31VQFU', 1, 1, 10.00, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 06:46:36', '2026-11-04 06:46:36'),
(5, 'USR4PO31VQFU', 2, 1, 20.00, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-04 07:00:06', '2026-11-04 07:00:06'),
(6, 'USR4PO31VQFU', 20, 1, 40.00, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 07:05:41', '2026-11-09 07:05:41'),
(7, 'USR4PO31VQFU', 6, 1, 200.00, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-09 07:05:52', '2026-11-09 07:05:52'),
(8, 'USR4PO31VQFU', 5, 1, 8.00, 'USR4PO31VQFU', 'USR4PO31VQFU', '2026-11-10 04:07:10', '2026-11-10 04:07:10');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `role` varchar(50) DEFAULT 'Customer',
  `status` varchar(20) DEFAULT 'Active',
  `password` varchar(255) DEFAULT NULL,
  `street_address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'India',
  `zip_code` varchar(50) DEFAULT NULL,
  `monthly_budget` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `username`, `name`, `email`, `phone`, `role`, `status`, `password`, `street_address`, `city`, `district`, `state`, `country`, `zip_code`, `monthly_budget`, `created_at`, `created_by`, `updated_by`, `updated_at`) VALUES
(2, 'USRA28T0MBY3', 'Sathya', 'Sathya', 'sathyamoorthymcse2022@ksrce.ac.in', '8986598989', 'admin', 'Active', '$2b$10$g7ZvXRWUZkBI6WDbTcKs5eZqx5svkCkNCJCHoBiWVE1up1HYuwbyO', NULL, NULL, NULL, NULL, 'India', NULL, 0.00, '2026-09-25 11:24:44', NULL, NULL, '2026-09-25 11:24:44'),
(7, 'USRIQDBL4UDQ', 'Rajesh P', 'Rajesh P', 'rajesh@gmail.com', '6383741331', 'user', 'Active', '$2b$10$I8FXMgfgcntz.SPfwMewRenLaCRQEW4zAhWuChGafl2JTvbiQmnYW', NULL, NULL, NULL, NULL, 'India', NULL, 0.00, '2026-09-25 12:56:05', NULL, NULL, '2026-09-25 12:56:05'),
(8, 'USR5DD9F0M5Z', 'Deva ', 'Deva ', 'deva@gmail.com', '8940450960', 'admin', 'Active', '$2b$10$GJH/4IHz8Lus86qVpa/YS.g9NuGzaq8OF/C3Ho..hjOEhgC01A3n6', NULL, NULL, NULL, NULL, 'India', NULL, 0.00, '2026-09-25 12:57:52', NULL, NULL, '2026-09-25 12:57:52'),
(10, 'USR4PO31VQFU', 'Dhivakar P', 'Dhivakar P', 'dhivakarp305@gmail.com', '8940450960', 'admin', 'Active', '$2b$10$mweQAG1HP9/o.j7vhQl80Oy6pnlkpatPEWSuTs6GeizZph0XigH36', NULL, NULL, NULL, NULL, 'India', NULL, 15000.00, '2026-09-25 17:21:44', NULL, NULL, '2026-11-09 06:28:03'),
(11, 'USR1793880621206', 'nishanthqtechx', 'Nishanth', 'nishanthqtechx@gmail.com', '', 'admin', 'Active', NULL, NULL, NULL, NULL, NULL, 'India', NULL, 0.00, '2026-11-05 12:10:21', NULL, NULL, '2026-11-05 12:10:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_lock_challenges`
--
ALTER TABLE `app_lock_challenges`
  ADD PRIMARY KEY (`user_id`,`purpose`);

--
-- Indexes for table `app_lock_sessions`
--
ALTER TABLE `app_lock_sessions`
  ADD PRIMARY KEY (`token_hash`),
  ADD KEY `idx_app_lock_session_owner` (`user_id`,`expires_at`);

--
-- Indexes for table `app_lock_settings`
--
ALTER TABLE `app_lock_settings`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `idx_app_lock_enabled` (`user_id`,`enabled`);

--
-- Indexes for table `calendar_events`
--
ALTER TABLE `calendar_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_calendar_event_user` (`user_id`);

--
-- Indexes for table `calendar_reminders`
--
ALTER TABLE `calendar_reminders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_calendar_reminder_user_date` (`user_id`,`reminder_date`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `diary_entries`
--
ALTER TABLE `diary_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_diary_user_date` (`user_id`,`entry_date`),
  ADD KEY `idx_diary_category` (`category_id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `income`
--
ALTER TABLE `income`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `memories`
--
ALTER TABLE `memories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_memory_user_date` (`user_id`,`memory_date`),
  ADD KEY `idx_memory_category` (`category_id`);

--
-- Indexes for table `todo_tasks`
--
ALTER TABLE `todo_tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_todo_user_status_due_date` (`user_id`,`status`,`due_date`);

--
-- Indexes for table `transfers`
--
ALTER TABLE `transfers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transfer_adjustments`
--
ALTER TABLE `transfer_adjustments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_transfer_adjustment_owner` (`transfer_id`,`income_id`,`user_id`,`transfer_date`);

--
-- Indexes for table `transfer_allocations`
--
ALTER TABLE `transfer_allocations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_transfer_allocation_owner` (`transfer_id`,`user_id`,`transfer_date`);

--
-- Indexes for table `transfer_fundings`
--
ALTER TABLE `transfer_fundings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_transfer_funding_owner` (`transfer_id`,`income_id`,`user_id`,`transfer_date`);

--
-- Indexes for table `transfer_returns`
--
ALTER TABLE `transfer_returns`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_transfer_return_owner` (`transfer_id`,`income_id`,`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `diary_entries`
--
ALTER TABLE `diary_entries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=248;

--
-- AUTO_INCREMENT for table `income`
--
ALTER TABLE `income`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `memories`
--
ALTER TABLE `memories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `todo_tasks`
--
ALTER TABLE `todo_tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `transfers`
--
ALTER TABLE `transfers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `transfer_adjustments`
--
ALTER TABLE `transfer_adjustments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `transfer_allocations`
--
ALTER TABLE `transfer_allocations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transfer_fundings`
--
ALTER TABLE `transfer_fundings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transfer_returns`
--
ALTER TABLE `transfer_returns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `diary_entries`
--
ALTER TABLE `diary_entries`
  ADD CONSTRAINT `fk_diary_entry_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_diary_entry_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `memories`
--
ALTER TABLE `memories`
  ADD CONSTRAINT `fk_memory_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_memory_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `todo_tasks`
--
ALTER TABLE `todo_tasks`
  ADD CONSTRAINT `fk_todo_task_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
